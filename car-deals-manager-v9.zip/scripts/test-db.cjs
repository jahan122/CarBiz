// Headless test of the SQLite & ZIP layer (runs under plain Node, no Electron needed).
// Usage: CARDEALS_DB_DRIVER=node-sqlite node scripts/test-db.cjs
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { CarDealsDb, DEFAULT_BUSINESS_PROFILE } = require('../dist-electron/db.js');
const { buildZipBuffer, readZipBuffer } = require('../dist-electron/zip.js');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'cardeals-'));
const file = path.join(tmp, 'sub', 'test.db');
let db = new CarDealsDb(file);

// --- default profile must be clean (no hardcoded personal PII) ---
assert.equal(DEFAULT_BUSINESS_PROFILE.owner_name, '');
assert.equal(DEFAULT_BUSINESS_PROFILE.cnic, '');
assert.equal(DEFAULT_BUSINESS_PROFILE.phone, '');

// --- seed ---
let deals = db.listDeals();
assert.equal(deals.length, 2, 'seeds exactly 2 records');
const active = deals.find((d) => d.status === 'ACTIVE');
const sold = deals.find((d) => d.status === 'SOLD');
assert.ok(active && sold, 'one active + one sold');
assert.equal(db.listExpenses(active.id).length, 2, 'active car has 2 expenses');
assert.equal(active.total_expenses, 50000);
const soldProfit = sold.sale_price - (sold.purchase_price + sold.total_expenses + sold.transfer_cost);
assert.equal(soldProfit, 2300000 - (2050000 + 15000 + 22000));
assert.ok(soldProfit > 0, 'sold car shows a net profit');

// --- reopen must NOT reseed or wipe data ---
db.close();
db = new CarDealsDb(file);
assert.equal(db.listDeals().length, 2, 'data persists, no re-seed');

// --- create with initial seller payment / update / checklist / due dates ---
const created = db.createDeal(
  {
    make: 'Honda',
    model: 'Civic',
    variant: '',
    year: 2016,
    color: 'Black',
    registration_number: ' abc-123 ',
    chassis_number: '',
    mileage: null,
    bought_from_location: 'Islamabad',
    purchase_date: '2026-11-01',
    purchase_price: 4000000,
    seller_name: 'Test Seller',
    seller_contact: '0300-0000000',
    seller_cnic: '',
    seller_due_date: '2026-11-15',
    token_tax_paid_till: 'Jun 2027',
    checklist_json: JSON.stringify({ original_file: true, smart_card_book: true }),
    notes: '',
    created_by: 'Owner',
  },
  null,
  {
    sellerPayment: { amount: 1500000, payment_type: 'Advance', method: 'Bank Transfer', date: '2026-11-01', notes: 'Initial wire' },
  },
);
assert.equal(created.status, 'ACTIVE');
assert.equal(created.registration_number, 'ABC-123', 'reg # trimmed + uppercased');
assert.equal(created.variant, null, 'empty optional -> NULL');
assert.equal(created.paid_to_seller, 1500000, 'initial seller payment recorded on create');
assert.equal(created.seller_due_date, '2026-11-15');
assert.equal(created.token_tax_paid_till, 'Jun 2027');
assert.equal(created.created_by, 'Owner');

const upd = db.updateDeal(created.id, { ...created, color: 'Red' });
assert.equal(upd.color, 'Red');

// --- due dates & checklist update ---
const afterChecklist = db.updateChecklist(created.id, JSON.stringify({ original_file: true, number_plates: true }), 'Dec 2027');
assert.equal(afterChecklist.token_tax_paid_till, 'Dec 2027');
const afterDue = db.updateDueDates(created.id, { seller_due_date: '2026-11-20' });
assert.equal(afterDue.seller_due_date, '2026-11-20');

// --- expenses ---
const e1 = db.addExpense(created.id, { category: 'Parts', description: 'Alternator', amount: 25000, date: '2026-11-03' });
db.addExpense(created.id, { category: 'Commission', description: 'Broker', amount: 10000, date: '2026-11-04' });
assert.equal(db.listDeals().find((d) => d.id === created.id).total_expenses, 35000);
db.updateExpense(e1.id, { category: 'Parts', description: 'Alternator + belt', amount: 27000, date: '2026-11-03' });
assert.equal(db.listDeals().find((d) => d.id === created.id).total_expenses, 37000);
db.deleteExpense(e1.id);
assert.equal(db.listDeals().find((d) => d.id === created.id).total_expenses, 10000);
const odd = db.addExpense(created.id, { category: 'Bogus', description: '', amount: '', date: '' });
assert.equal(odd.category, 'Other', 'unknown category falls back to Other');
assert.equal(odd.amount, 0, 'blank amount saves as 0');
db.deleteExpense(odd.id);
assert.throws(() => db.addExpense(99999, { category: 'Parts', description: '', amount: 1, date: '2026-11-01' }), 'FK enforced');

// --- reserve / cancel (refund & forfeit) / convert to sold ---
const resv = db.reserveDeal(created.id, {
  reserved_date: '2026-11-05',
  reserved_expiry_date: '2026-11-08',
  reserved_token_amount: 100000,
  reserved_buyer_name: 'Token Buyer',
  reserved_buyer_contact: '0321-1234567',
  reserved_notes: '3-day bayana hold',
  payment_method: 'Cash',
});
assert.equal(resv.status, 'RESERVED');
assert.equal(resv.received_from_buyer, 100000, 'token automatically logged in payments');

// Cancel with refund -> removes token payment
const cancelledRefund = db.cancelReservation(created.id, true);
assert.equal(cancelledRefund.status, 'ACTIVE');
assert.equal(cancelledRefund.received_from_buyer, 0, 'refund removed token payment');

// Re-reserve and cancel with forfeit -> keeps token payment
db.reserveDeal(created.id, {
  reserved_date: '2026-11-06',
  reserved_expiry_date: '2026-11-09',
  reserved_token_amount: 75000,
  reserved_buyer_name: 'Buyer 2',
  payment_method: 'Cash',
});
const cancelledForfeit = db.cancelReservation(created.id, false);
assert.equal(cancelledForfeit.status, 'ACTIVE');
assert.equal(cancelledForfeit.received_from_buyer, 75000, 'forfeit retained token payment');

// Clear forfeit payment cleanly and reserve again, then markSold with initial buyer payment
for (const p of db.listPayments(created.id).filter((x) => x.direction === 'IN_FROM_BUYER')) {
  db.deletePayment(p.id);
}
db.reserveDeal(created.id, {
  reserved_date: '2026-11-07',
  reserved_expiry_date: '2026-11-10',
  reserved_token_amount: 200000,
  reserved_buyer_name: 'Final Buyer',
  reserved_buyer_contact: '0311-1111111',
  payment_method: 'Cash',
});
const s = db.markSold(
  created.id,
  {
    sale_price: 4300000,
    sale_date: '2026-11-10',
    purchaser_name: 'Final Buyer',
    purchaser_contact: '0311-1111111',
    purchaser_cnic: null,
    buyer_due_date: '2026-11-25',
  },
  { amount: 4100000, payment_type: 'Final Balance', method: 'Bank Transfer', date: '2026-11-10' },
);
assert.equal(s.status, 'SOLD');
assert.equal(s.reserved_buyer_name, null, 'reservation cleared on sale');
assert.equal(s.received_from_buyer, 4300000, 'token + initial buyer balance = full 4,300,000');
assert.equal(s.sale_price - (s.purchase_price + s.total_expenses), 4300000 - 4010000);

// --- revert sale (keep vs delete buyer payments) ---
const kept = db.revertSale(created.id, false);
assert.equal(kept.status, 'ACTIVE');
assert.equal(kept.sale_price, null);
assert.equal(kept.received_from_buyer, 4300000, 'kept buyer payments when requested');

db.markSold(created.id, { sale_price: 4300000, sale_date: '2026-11-10', purchaser_name: 'Final Buyer' });
const wiped = db.revertSale(created.id, true);
assert.equal(wiped.status, 'ACTIVE');
assert.equal(wiped.received_from_buyer, 0, 'deleted buyer payments when requested');

// --- CSV ---
const csv = db.exportCsv();
assert.ok(csv.startsWith('\uFEFF'), 'CSV has BOM for Excel');
assert.equal(csv.trim().split('\r\n').length, 1 + 3, 'header + 3 rows');
assert.ok(csv.includes('Corolla') && csv.includes('Alto'));

// --- ZIP archive round-trip & path traversal rejection ---
const zipBuf = buildZipBuffer([
  { name: 'database.db', data: Buffer.from('sqlite-mock-bytes') },
  { name: 'attachments/1/doc.txt', data: Buffer.from('hello attachment') },
]);
const zipEntries = readZipBuffer(zipBuf);
assert.equal(zipEntries.size, 2);
assert.equal(zipEntries.get('database.db').toString('utf8'), 'sqlite-mock-bytes');
assert.equal(zipEntries.get('attachments/1/doc.txt').toString('utf8'), 'hello attachment');
const evilZip = buildZipBuffer([{ name: '../evil.txt', data: Buffer.from('x') }]);
assert.throws(() => readZipBuffer(evilZip), /Unsafe path inside backup archive/);

// --- attachment path remapping ---
const attRow = db.addAttachment(created.id, {
  category: 'CNIC_FRONT',
  label: 'Seller CNIC',
  file_name: 'cnic.jpg',
  file_path: `C:\\old\\attachments\\deal-${created.id}\\cnic.jpg`,
});
assert.equal(db.listAttachments(created.id).length, 1);
const newAttRoot = path.join(tmp, 'restored-attachments');
const restoredDealAttDir = path.join(newAttRoot, `deal-${created.id}`);
fs.mkdirSync(restoredDealAttDir, { recursive: true });
fs.writeFileSync(path.join(restoredDealAttDir, 'cnic.jpg'), 'img');
db.remapAttachmentPaths(newAttRoot);
const remapped = db.listAttachments(created.id)[0];
assert.equal(remapped.id, attRow.id);
assert.equal(remapped.file_path, path.join(newAttRoot, `deal-${created.id}`, 'cnic.jpg'));

// --- v7: expense payee_name, listAllExpenses, cheque tracking, audit logs, trade-in, auto-lock, cloud settings ---
const ePayee = db.addExpense(created.id, {
  category: 'Commission',
  description: 'Broker commission',
  payee_name: 'Salman Broker',
  amount: 15000,
  date: '2026-11-05',
  created_by: 'Owner',
});
assert.equal(ePayee.payee_name, 'Salman Broker');
assert.ok(db.listAllExpenses().some((x) => x.id === ePayee.id && x.payee_name === 'Salman Broker'));
db.deleteExpense(ePayee.id);

const chqPay = db.addPayment(created.id, {
  direction: 'IN_FROM_BUYER',
  payment_type: 'Installment',
  method: 'Cheque',
  amount: 250000,
  date: '2026-11-06',
  notes: 'Meezan cheque',
  cheque_number: 'CHQ-9988',
  cheque_date: '2026-11-15',
  cheque_status: 'PENDING',
  created_by: 'Owner',
});
assert.equal(chqPay.cheque_number, 'CHQ-9988');
assert.equal(chqPay.cheque_status, 'PENDING');
const chqCleared = db.updateChequeStatus(chqPay.id, 'CLEARED', 'Owner');
assert.equal(chqCleared.cheque_status, 'CLEARED');
assert.ok(db.listAllPayments().some((p) => p.id === chqPay.id && p.cheque_status === 'CLEARED'));
db.deletePayment(chqPay.id);

// Trade-In Exchange linking via markSold
const soldWithExchange = db.markSold(
  created.id,
  {
    sale_price: 4500000,
    sale_date: '2026-11-12',
    purchaser_name: 'Exchange Buyer',
    purchaser_contact: '0322-7778899',
    tradeIn: {
      valuation: 1800000,
      make: 'Suzuki',
      model: 'Cultus',
      year: 2019,
      registration_number: 'ex-555',
      notes: 'Clean trade-in car',
    },
  },
  { amount: 2700000, payment_type: 'Final Balance', method: 'Bank Transfer', date: '2026-11-12' },
);
assert.equal(soldWithExchange.status, 'SOLD');
assert.ok(soldWithExchange.trade_in_deal_id, 'sold car links to incoming trade-in car');
assert.equal(soldWithExchange.received_from_buyer, 4500000, 'trade-in valuation + cash balance = full 4,500,000');

const incomingTradeIn = db.getDealById(soldWithExchange.trade_in_deal_id);
assert.equal(incomingTradeIn.status, 'ACTIVE');
assert.equal(incomingTradeIn.registration_number, 'EX-555');
assert.equal(incomingTradeIn.purchase_price, 1800000);
assert.equal(incomingTradeIn.paid_to_seller, 1800000, 'incoming trade-in marked settled with seller');
assert.equal(incomingTradeIn.trade_in_for_deal_id, created.id, 'bidirectional trade-in link stored');

// Reverting sale unlinks trade-in cleanly
const revertedExchange = db.revertSale(created.id, true);
assert.equal(revertedExchange.status, 'ACTIVE');
assert.equal(revertedExchange.trade_in_deal_id, null);
assert.equal(db.getDealById(incomingTradeIn.id).trade_in_for_deal_id, null, 'trade-in unlinked cleanly on revert');
db.deleteDeal(incomingTradeIn.id);

// Audit log checks
const dealLogs = db.listAuditLogs(created.id);
assert.ok(dealLogs.length >= 4, 'audit logs recorded for deal mutations');
assert.ok(db.listAuditLogs(undefined, 50).length >= dealLogs.length, 'global audit logs accessible');

// Auto-lock & Cloud Backup Settings
assert.equal(db.setAutoLockMinutes(3), 3);
assert.equal(db.getAutoLockMinutes(), 3);
const cloudSet = db.setCloudBackupSettings({ cloud_backup_dir: 'C:\\OneDrive\\CarBizBackups', last_synced_at: '2026-11-12T10:00:00Z' });
assert.equal(cloudSet.cloud_backup_dir, 'C:\\OneDrive\\CarBizBackups');
assert.equal(db.getCloudBackupSettings().last_synced_at, '2026-11-12T10:00:00Z');

// --- backup & remaining tests ---
const bak = path.join(tmp, 'backup.db');
db.backupTo(bak).then(() => {
  assert.ok(fs.statSync(bak).size > 0);
  const copy = new CarDealsDb(bak);
  assert.equal(copy.listDeals().length, 3, 'backup contains all data');
  copy.close();

  // --- delete cascades expenses & attachments ---
  db.deleteDeal(created.id);
  const left = db.db.prepare('SELECT COUNT(*) c FROM expenses WHERE car_deal_id = ?').get(created.id).c;
  assert.equal(left, 0, 'ON DELETE CASCADE removed expenses');
  assert.equal(db.listDeals().length, 2);

  // --- nothing is required: a completely blank car saves ---
  const blank = db.createDeal({});
  assert.equal(blank.status, 'ACTIVE');
  assert.equal(blank.make, null);
  assert.equal(blank.purchase_price, null);
  db.updateDeal(blank.id, { make: '  Toyota ', year: 'abc', purchase_price: 'Rs 1,250,000', engine_number: '1NZ-123' });
  const b2 = db.listDeals().find((d) => d.id === blank.id);
  db.updateDeal(blank.id, { ...b2, seller_address: '  Plot 9, Lahore ' });
  assert.equal(db.listDeals().find((d) => d.id === blank.id).seller_address, 'Plot 9, Lahore');
  assert.equal(b2.make, 'Toyota');
  assert.equal(b2.year, null);
  assert.equal(b2.purchase_price, 1250000);
  assert.equal(b2.engine_number, '1NZ-123');

  // --- direct sold entry (no buying slip): created already SOLD, purchase details empty ---
  const direct = db.createDeal(
    { make: 'Honda', model: 'City', registration_number: 'xyz 12' },
    { sale_price: '3,100,000', sale_date: '2026-11-12', purchaser_name: 'Direct Buyer', purchaser_contact: '0300-1112223' },
  );
  assert.equal(direct.status, 'SOLD');
  assert.equal(direct.sale_price, 3100000);
  assert.equal(direct.purchase_price, null);
  assert.equal(direct.registration_number, 'XYZ 12');
  const blankSale = db.createDeal({ make: 'Suzuki' }, {});
  assert.equal(blankSale.status, 'SOLD');
  assert.equal(blankSale.sale_price, null);
  for (const id of [blank.id, direct.id, blankSale.id]) db.deleteDeal(id);

  // --- legacy database (old schema with NOT NULL columns) upgrades without losing anything ---
  {
    const { openDatabase } = require('../dist-electron/sqlite-driver.js');
    const legacyFile = path.join(tmp, 'legacy', 'old.db');
    fs.mkdirSync(path.dirname(legacyFile), { recursive: true });
    const old = openDatabase(legacyFile);
    old.exec(`
      CREATE TABLE car_deals (id INTEGER PRIMARY KEY AUTOINCREMENT, status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','SOLD')),
        make TEXT NOT NULL, model TEXT NOT NULL, variant TEXT, year INTEGER NOT NULL, color TEXT NOT NULL, registration_number TEXT NOT NULL,
        chassis_number TEXT, mileage INTEGER, bought_from_location TEXT NOT NULL, purchase_date TEXT NOT NULL, purchase_price REAL NOT NULL,
        seller_name TEXT NOT NULL, seller_contact TEXT NOT NULL, seller_cnic TEXT, sale_date TEXT, sale_price REAL, purchaser_name TEXT,
        purchaser_contact TEXT, purchaser_cnic TEXT, notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')));
      CREATE TABLE expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, car_deal_id INTEGER NOT NULL, category TEXT NOT NULL CHECK (category IN
        ('Mechanic/Repair','Denting/Painting','Parts','Detailing','Commission','Documentation/Tax','Other')), description TEXT NOT NULL DEFAULT '',
        amount REAL NOT NULL, date TEXT NOT NULL, FOREIGN KEY (car_deal_id) REFERENCES car_deals(id) ON DELETE CASCADE);
      CREATE INDEX idx_expenses_deal ON expenses(car_deal_id);
      INSERT INTO car_deals (make, model, year, color, registration_number, bought_from_location, purchase_date, purchase_price, seller_name, seller_contact)
        VALUES ('Toyota','Yaris',2021,'Red','LEG-001','Karachi','2026-10-01',3000000,'Old Seller','0300-1111111');
      INSERT INTO car_deals (make, model, year, color, registration_number, bought_from_location, purchase_date, purchase_price, seller_name, seller_contact, status, sale_price, sale_date, purchaser_name, purchaser_contact)
        VALUES ('Honda','Vezel',2019,'White','LEG-002','Lahore','2026-09-01',5000000,'S2','0300-2222222','SOLD',5400000,'2026-10-10','B2','0300-3333333');
      INSERT INTO expenses (car_deal_id, category, description, amount, date) VALUES (1,'Parts','Brake pads',10000,'2026-10-02'),(1,'Detailing','Wash',2000,'2026-10-03'),(2,'Parts','Tyres',40000,'2026-09-05');
      PRAGMA user_version = 1;`);
    old.close();

    const mig = new CarDealsDb(legacyFile);
    const rows = mig.listDeals();
    assert.equal(rows.length, 2, 'legacy rows kept');
    const yaris = rows.find((d) => d.model === 'Yaris');
    assert.equal(yaris.registration_number, 'LEG-001');
    assert.equal(yaris.total_expenses, 12000, 'expenses survived (no cascade delete)');
    assert.equal(rows.find((d) => d.model === 'Vezel').status, 'SOLD');
    assert.equal(rows.find((d) => d.model === 'Vezel').sale_price, 5400000);
    assert.ok(mig.listExpenses(yaris.id).length === 2);
    assert.ok(fs.existsSync(path.join(path.dirname(legacyFile), 'car-deals-before-update.db')), 'pre-upgrade backup written');

    // Verify upgraded status CHECK constraint allows RESERVED on legacy DB
    const reservedLegacy = mig.reserveDeal(yaris.id, { reserved_buyer_name: 'Legacy Token Buyer', reserved_token_amount: 50000 });
    assert.equal(reservedLegacy.status, 'RESERVED', 'legacy upgraded CHECK constraint permits RESERVED');
    mig.cancelReservation(yaris.id, true);

    const blankLegacy = mig.createDeal({});
    assert.ok(blankLegacy.id > 2, 'autoincrement continues after migration');
    mig.updateDeal(yaris.id, { ...yaris, engine_number: 'ENG-9', seller_address: 'House 7, Karachi' });
    assert.equal(mig.listDeals().find((d) => d.id === yaris.id).engine_number, 'ENG-9');
    assert.equal(mig.listDeals().find((d) => d.id === yaris.id).seller_address, 'House 7, Karachi');
    mig.deleteDeal(blankLegacy.id);
    mig.close();
    const again = new CarDealsDb(legacyFile);
    assert.equal(again.listDeals().length, 2);
    assert.equal(again.listExpenses(yaris.id).length, 2);
    again.close();
  }

  // --- deleting the samples must be permanent (no re-seed on reopen) ---
  for (const d of db.listDeals()) db.deleteDeal(d.id);
  assert.equal(db.listDeals().length, 0);
  db.close();
  db = new CarDealsDb(file);
  assert.equal(db.listDeals().length, 0, 'deleted sample data stays deleted after reopen');
  db.db.exec('PRAGMA user_version = 0');
  db.close();
  db = new CarDealsDb(file);
  assert.equal(db.listDeals().length, 0, 'legacy empty DB is not re-seeded');
  db.close();
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log('ALL DB & ZIP TESTS PASSED');
});
