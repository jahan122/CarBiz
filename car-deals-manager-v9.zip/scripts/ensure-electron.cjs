const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');

const rootDir = path.resolve(__dirname, '..');
const electronDir = path.join(rootDir, 'node_modules', 'electron');
const distDir = path.join(electronDir, 'dist');
const exeName = process.platform === 'win32' ? 'electron.exe' : process.platform === 'darwin' ? 'Electron.app/Contents/MacOS/Electron' : 'electron';
const exePath = path.join(distDir, exeName);
const pathTxt = path.join(electronDir, 'path.txt');

if (fs.existsSync(exePath) && fs.existsSync(pathTxt)) {
  process.exit(0);
}

console.log('[ensure-electron] Electron binary missing or incomplete. Repairing automatically...');
const pkg = JSON.parse(fs.readFileSync(path.join(electronDir, 'package.json'), 'utf8'));
const version = pkg.version;
const platform = process.platform;
const arch = process.arch;
const zipName = `electron-v${version}-${platform}-${arch}.zip`;

const cacheDirs = [
  process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'electron', 'Cache') : null,
  path.join(os.homedir(), '.cache', 'electron'),
  path.join(os.tmpdir(), 'electron-cache'),
].filter(Boolean);

let cachedZip = null;
for (const dir of cacheDirs) {
  const candidate = path.join(dir, zipName);
  if (fs.existsSync(candidate) && fs.statSync(candidate).size > 50 * 1024 * 1024) {
    cachedZip = candidate;
    break;
  }
}

if (!cachedZip) {
  const targetCache = cacheDirs[0];
  fs.mkdirSync(targetCache, { recursive: true });
  cachedZip = path.join(targetCache, zipName);
  const url = `https://github.com/electron/electron/releases/download/v${version}/${zipName}`;
  console.log(`[ensure-electron] Downloading ${zipName}...`);
  execSync(`curl -L --fail -o "${cachedZip}" "${url}"`, { stdio: 'inherit' });
}

fs.mkdirSync(distDir, { recursive: true });
console.log(`[ensure-electron] Extracting ${cachedZip}...`);
if (process.platform === 'win32') {
  execSync(
    `powershell -NoProfile -Command "Expand-Archive -LiteralPath '${cachedZip.replace(/'/g, "''")}' -DestinationPath '${distDir.replace(/'/g, "''")}' -Force"`,
    { stdio: 'inherit' },
  );
} else {
  execSync(`unzip -o "${cachedZip}" -d "${distDir}"`, { stdio: 'inherit' });
}

fs.writeFileSync(pathTxt, exeName, 'ascii');
console.log('[ensure-electron] Electron binary ready.');
