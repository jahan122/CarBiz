import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cardealsmanager.app',
  appName: 'Car Deals Manager',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    iosScheme: 'capacitor',
  },
  plugins: {
    Filesystem: {
      iosScheme: 'capacitor',
    },
  },
};

export default config;
