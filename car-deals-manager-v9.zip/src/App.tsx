import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { AppUser, DealWithTotals, TransferStatus } from './types';
import {
  buyerBalanceDue,
  carTitle,
  daysInStock,
  matchesQuery,
  netProfit,
  regOf,
  sellerBalanceDue,
} from './utils';
import HomeView from './components/HomeView';
import KpiCards from './components/KpiCards';
import DealsTable from './components/DealsTable';
import DealDrawer from './components/DealDrawer';
import WhatsAppShareModal from './components/WhatsAppShareModal';
import DealFormModal from './components/DealFormModal';
import ExpenseModal from './components/ExpenseModal';
import PaymentsModal from './components/PaymentsModal';
import ReceiptModal from './components/ReceiptModal';
import ReserveModal from './components/ReserveModal';
import SoldModal from './components/SoldModal';
import ConfirmDialog from './components/ConfirmDialog';
import ReportsView from './components/ReportsView';
import PartiesView from './components/PartiesView';
import AuditLogModal from './components/AuditLogModal';
import RecycleBinModal from './components/RecycleBinModal';
import BackupRestoreModal from './components/BackupRestoreModal';
import { PinLockScreen, PinSettingsModal } from './components/PinLock';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallBanner';

type Tab = 'ALL' | 'ACTIVE' | 'RESERVED' | 'SOLD';
type Section = 'HOME' | 'DEALS' | 'PARTIES' | 'REPORTS';
type TransferFilter = 'ALL' | TransferStatus;
type BalanceFilter = 'ALL' | 'DUE_TO_SELLER' | 'DUE_FROM_BUYER' | 'SETTLED';
type SortMode = 'NEWEST' | 'AGING_DESC' | 'BALANCE_DUE' | 'PROFIT_DESC';

type ModalState =
  | { type: 'create'; startSold?: boolean }
  | { type: 'edit'; deal: DealWithTotals }
  | { type: 'expenses'; deal: DealWithTotals }
  | { type: 'payments'; deal: DealWithTotals }
  | { type: 'receipt'; deal: DealWithTotals }
  | { type: 'whatsapp'; deal: DealWithTotals; mode?: 'RECEIPT' | 'SPECS' }
  | { type: 'reserve'; deal: DealWithTotals }
  | { type: 'sold'; deal: DealWithTotals }
  | { type: 'delete'; deal: DealWithTotals }
  | { type: 'recycleBin' }
  | { type: 'backupRestore' }
  | { type: 'pinSettings' }
  | { type: 'auditLog' }
  | null;

interface Toast {
  text: string;
  action?: { label: string; onClick: () => void };
}

export default function App() {
  const [deals, setDeals] = useState<DealWithTotals[]>([]);
  const [deletedCount, setDeletedCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [section, setSection] = useState<Section>('HOME');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);

  // Ledger Filters & Sorting
  const [tab, setTab] = useState<Tab>('ALL');
  const [query, setQuery] = useState('');
  const [transferFilter, setTransferFilter] = useState<TransferFilter>('ALL');
  const [makeFilter, setMakeFilter] = useState<string>('ALL');
  const [balanceFilter, setBalanceFilter] = useState<BalanceFilter>('ALL');
  const [addedFrom, setAddedFrom] = useState('');
  const [addedTo, setAddedTo] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('NEWEST');

  const [inspectedDeal, setInspectedDeal] = useState<DealWithTotals | null>(null);
  const [modal, setModal] = useState<ModalState>(null);
  const [toast, setToast] = useState<Toast | null>(null);

  // Multi-User, PIN Lock & Auto-Lock State
  const [hasUsers, setHasUsers] = useState(false);
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);
  const [locked, setLocked] = useState(false);
  const [securityReady, setSecurityReady] = useState(false);
  const [autoLockMinutes, setAutoLockMinutes] = useState(5);
  const searchRef = useRef<HTMLInputElement>(null);

  const isElectron = Boolean(window.api?.isElectron);
  const isOwner = !currentUser || currentUser.role === 'OWNER';
  const canViewProfit = isOwner || currentUser.can_view_profit;
  const canManagePayments = isOwner || currentUser.can_manage_payments;
  const canMarkSold = isOwner || currentUser.can_mark_sold;
  const canDelete = isOwner || currentUser.can_delete;

  const notify = useCallback((text: string, action?: Toast['action']) => {
    setToast({ text, action });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 5000);
    return () => clearTimeout(t);
  }, [toast]);

  const reload = useCallback(async () => {
    if (!window.api) return;
    const [activeList, deletedList] = await Promise.all([window.api.listDeals(), window.api.listDeletedDeals()]);
    setDeals(activeList);
    setDeletedCount(deletedList.length);
  }, []);

  const lockNow = useCallback(() => {
    setModal(null);
    setInspectedDeal(null);
    setMobileMoreOpen(false);
    setLocked(true);
    void window.api?.lockApp();
  }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      if (!window.api) {
        if (alive) {
          setSecurityReady(true);
          setLoading(false);
        }
        return;
      }
      try {
        const [usersExist, lockMins] = await Promise.all([
          window.api.hasUsers(),
          window.api.getAutoLockMinutes(),
        ]);
        if (!alive) return;
        setHasUsers(usersExist);
        setLocked(usersExist);
        setAutoLockMinutes(lockMins);
        setSecurityReady(true);
        if (!usersExist) {
          await reload();
        }
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [reload]);

  // Auto-Lock Inactivity Timer
  useEffect(() => {
    if (!hasUsers || locked || autoLockMinutes <= 0) return;
    const timeoutMs = autoLockMinutes * 60_000;
    let timer = window.setTimeout(lockNow, timeoutMs);

    const resetTimer = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(lockNow, timeoutMs);
    };

    const events: Array<keyof WindowEventMap> = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'];
    for (const ev of events) {
      window.addEventListener(ev, resetTimer, { passive: true });
    }
    return () => {
      window.clearTimeout(timer);
      for (const ev of events) {
        window.removeEventListener(ev, resetTimer);
      }
    };
  }, [hasUsers, locked, autoLockMinutes, lockNow]);

  useEffect(() => {
    if (modal || locked) return;
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const inField = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT');
      if (e.ctrlKey && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        setModal({ type: 'create' });
      } else if (hasUsers && e.ctrlKey && e.key.toLowerCase() === 'l') {
        e.preventDefault();
        lockNow();
      } else if (section === 'DEALS' && ((e.ctrlKey && e.key.toLowerCase() === 'f') || (!inField && e.key === '/'))) {
        e.preventDefault();
        searchRef.current?.focus();
        searchRef.current?.select();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [modal, locked, section, hasUsers, lockNow]);

  const counts = useMemo(
    () => ({
      ALL: deals.length,
      ACTIVE: deals.filter((d) => d.status === 'ACTIVE').length,
      RESERVED: deals.filter((d) => d.status === 'RESERVED').length,
      SOLD: deals.filter((d) => d.status === 'SOLD').length,
    }),
    [deals],
  );

  const uniqueMakes = useMemo(() => {
    const set = new Set<string>();
    for (const d of deals) {
      if (d.make && d.make.trim()) set.add(d.make.trim());
    }
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [deals]);

  const hasExtraFilters =
    query !== '' ||
    tab !== 'ALL' ||
    transferFilter !== 'ALL' ||
    makeFilter !== 'ALL' ||
    balanceFilter !== 'ALL' ||
    addedFrom !== '' ||
    addedTo !== '' ||
    sortMode !== 'NEWEST';

  function resetAllFilters() {
    setQuery('');
    setTab('ALL');
    setTransferFilter('ALL');
    setMakeFilter('ALL');
    setBalanceFilter('ALL');
    setAddedFrom('');
    setAddedTo('');
    setSortMode('NEWEST');
  }

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = deals.filter((d) => {
      if (tab !== 'ALL' && d.status !== tab) return false;
      if (transferFilter !== 'ALL' && (d.transfer_status ?? 'PENDING') !== transferFilter) return false;
      if (makeFilter !== 'ALL' && (d.make ?? '').trim() !== makeFilter) return false;

      if (balanceFilter !== 'ALL') {
        const sDue = sellerBalanceDue(d) ?? 0;
        const bDue = buyerBalanceDue(d) ?? 0;
        if (balanceFilter === 'DUE_TO_SELLER' && sDue <= 0) return false;
        if (balanceFilter === 'DUE_FROM_BUYER' && bDue <= 0) return false;
        if (balanceFilter === 'SETTLED' && (sDue > 0 || bDue > 0)) return false;
      }

      const entryDate = (d.created_at ?? '').slice(0, 10);
      if (addedFrom && entryDate && entryDate < addedFrom) return false;
      if (addedTo && entryDate && entryDate > addedTo) return false;

      if (q) {
        const agentMatch = (d.transfer_agent_name ?? '').toLowerCase().includes(q);
        if (!matchesQuery(d, query) && !agentMatch) return false;
      }

      return true;
    });

    if (sortMode === 'AGING_DESC') {
      list.sort((a, b) => {
        const aSold = a.status === 'SOLD' ? 1 : 0;
        const bSold = b.status === 'SOLD' ? 1 : 0;
        if (aSold !== bSold) return aSold - bSold;
        return (daysInStock(b) ?? -1) - (daysInStock(a) ?? -1);
      });
    } else if (sortMode === 'BALANCE_DUE') {
      const totalDue = (d: DealWithTotals) => (sellerBalanceDue(d) ?? 0) + (buyerBalanceDue(d) ?? 0);
      list.sort((a, b) => totalDue(b) - totalDue(a));
    } else if (sortMode === 'PROFIT_DESC' && canViewProfit) {
      list.sort((a, b) => (netProfit(b) ?? -Infinity) - (netProfit(a) ?? -Infinity));
    }

    return list;
  }, [deals, tab, query, transferFilter, makeFilter, balanceFilter, addedFrom, addedTo, sortMode, canViewProfit]);

  const liveDeal = (d: DealWithTotals): DealWithTotals => deals.find((x) => x.id === d.id) ?? d;

  const inspectDealById = useCallback(
    (dealId: number) => {
      const found = deals.find((d) => d.id === dealId);
      if (found) {
        setInspectedDeal(found);
        return;
      }
      void window.api?.getDeal(dealId).then((fetched) => {
        setInspectedDeal(fetched);
      });
    },
    [deals],
  );

  async function runExport(kind: 'zip' | 'db' | 'csv') {
    if (!window.api) return;
    try {
      const res = await window.api.backupOrExport(kind);
      if (res.saved) {
        const label =
          kind === 'zip' ? 'full backup (.zip)' : kind === 'db' ? 'database backup' : 'CSV spreadsheet';
        if (isElectron && res.path) {
          const p = res.path;
          notify(`Saved ${label}`, {
            label: 'Open folder',
            onClick: () => void window.api?.showInFolder(p),
          });
        } else {
          notify(`Downloaded ${label}`);
        }
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : String(err));
    }
  }

  async function softDeleteDeal(d: DealWithTotals) {
    if (!window.api) return;
    await window.api.softDeleteDeal(d.id);
    setModal(null);
    if (inspectedDeal?.id === d.id) setInspectedDeal(null);
    await reload();
    notify(`Moved ${carTitle(d)} (${regOf(d)}) to Recycle Bin`, {
      label: 'Undo',
      onClick: () => {
        void window.api?.restoreDeal(d.id).then(() => {
          void reload();
          notify(`Restored ${carTitle(d)} (${regOf(d)})`);
        });
      },
    });
  }

  const openPayments = (deal: DealWithTotals) => {
    if (!canManagePayments) {
      notify('You do not have permission to manage payments');
      return;
    }
    setModal({ type: 'payments', deal });
  };

  const openReserve = (deal: DealWithTotals) => {
    if (!canMarkSold) {
      notify('You do not have permission to reserve vehicles or record tokens');
      return;
    }
    setModal({ type: 'reserve', deal });
  };

  const openSold = (deal: DealWithTotals) => {
    if (!canMarkSold) {
      notify('You do not have permission to mark cars as sold');
      return;
    }
    setModal({ type: 'sold', deal });
  };

  const openDelete = (deal: DealWithTotals) => {
    if (!canDelete) {
      notify('Only Owner or authorized users can delete deals');
      return;
    }
    setModal({ type: 'delete', deal });
  };

  if (!securityReady) {
    return <div className="flex h-full items-center justify-center bg-[#F8FAFC] text-sm text-slate-500">Loading…</div>;
  }

  if (locked) {
    return (
      <PinLockScreen
        onUnlocked={(user) => {
          setCurrentUser(user);
          setLocked(false);
          if (!user.can_view_profit && user.role !== 'OWNER' && section === 'REPORTS') {
            setSection('HOME');
          }
          notify(`Signed in as ${user.name} (${user.role})`);
        }}
      />
    );
  }

  const tabs: { key: Tab; label: string }[] = [
    { key: 'ALL', label: 'All' },
    { key: 'ACTIVE', label: 'Active' },
    { key: 'RESERVED', label: 'Reserved' },
    { key: 'SOLD', label: 'Sold' },
  ];

  const sectionMeta: Record<Section, { title: string; mobileTitle: string; subtitle: string }> = {
    HOME: {
      title: 'Command Center',
      mobileTitle: 'Car Deals',
      subtitle: 'Quick vehicle lookup, overdue payment follow-ups & recent transactions',
    },
    DEALS: {
      title: 'Inventory & Deals Ledger',
      mobileTitle: 'Inventory',
      subtitle: 'Complete vehicle stock, bayana holds, installment balances, file transfers & profit',
    },
    PARTIES: {
      title: 'Parties & Commission Ledger',
      mobileTitle: 'Parties',
      subtitle: 'Customers, sellers, transfer agents & broker commissions across all deals',
    },
    REPORTS: {
      title: 'Reports & Profit Analytics',
      mobileTitle: 'Reports',
      subtitle: 'Monthly P&L breakdown, expense categories, cashflow & cheque clearance tracker',
    },
  };

  return (
    <div className="flex h-full bg-[#F8FAFC] text-slate-900">
      {/* Desktop Left Navigation Sidebar */}
      <aside
        className={`hidden shrink-0 flex-col justify-between border-r border-slate-200 bg-white transition-all duration-200 md:flex ${
          sidebarCollapsed ? 'w-[72px]' : 'w-60'
        }`}
      >
        <div>
          {/* Brand Header */}
          <div className="flex h-16 items-center justify-between border-b border-slate-200 px-4">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-brand-600 text-white shadow-xs">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 17H3a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1l3-4h10l3 4h1a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-2" />
                  <circle cx="7" cy="17" r="2.5" />
                  <circle cx="17" cy="17" r="2.5" />
                </svg>
              </div>
              {!sidebarCollapsed && (
                <div className="truncate">
                  <div className="truncate text-sm font-bold text-slate-900">Car Deals</div>
                  <div className="truncate text-[11px] text-slate-500">Showroom Manager</div>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => setSidebarCollapsed((c) => !c)}
              title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                {sidebarCollapsed ? <polyline points="9 18 15 12 9 6" /> : <polyline points="15 18 9 12 15 6" />}
              </svg>
            </button>
          </div>

          {/* Primary Navigation Links */}
          <nav className="space-y-1 p-3">
            <button
              type="button"
              onClick={() => setSection('HOME')}
              title="Home (Command Center)"
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition ${
                section === 'HOME'
                  ? 'bg-brand-50 text-brand-700 ring-1 ring-inset ring-brand-200'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                <polyline points="9 22 9 12 15 12 15 22" />
              </svg>
              {!sidebarCollapsed && <span className="truncate">Home</span>}
            </button>

            <button
              type="button"
              onClick={() => setSection('DEALS')}
              title="Inventory & Deals Ledger"
              className={`flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-xs font-semibold transition ${
                section === 'DEALS'
                  ? 'bg-brand-50 text-brand-700 ring-1 ring-inset ring-brand-200'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3 overflow-hidden">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                  <rect width="18" height="18" x="3" y="3" rx="2" />
                  <path d="M3 9h18" />
                  <path d="M9 21V9" />
                </svg>
                {!sidebarCollapsed && <span className="truncate">Inventory &amp; Deals</span>}
              </div>
              {!sidebarCollapsed && (
                <span className="rounded-full bg-slate-100 px-2 py-0.5 font-mono text-[11px] font-bold tabular-nums text-slate-700">
                  {counts.ACTIVE + counts.RESERVED}/{counts.ALL}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setSection('PARTIES')}
              title="Parties & Commission Ledger"
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition ${
                section === 'PARTIES'
                  ? 'bg-brand-50 text-brand-700 ring-1 ring-inset ring-brand-200'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
              {!sidebarCollapsed && <span className="truncate">Parties &amp; Brokers</span>}
            </button>

            {canViewProfit && (
              <button
                type="button"
                onClick={() => setSection('REPORTS')}
                title="Reports & Profit"
                className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition ${
                  section === 'REPORTS'
                    ? 'bg-brand-50 text-brand-700 ring-1 ring-inset ring-brand-200'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                  <line x1="18" x2="18" y1="20" y2="10" />
                  <line x1="12" x2="12" y1="20" y2="4" />
                  <line x1="6" x2="6" y1="20" y2="14" />
                </svg>
                {!sidebarCollapsed && <span className="truncate">Reports &amp; Profit</span>}
              </button>
            )}
          </nav>
        </div>

        {/* Bottom Utility Dock & Active User Card */}
        <div className="space-y-1 border-t border-slate-200 p-3">
          {currentUser && !sidebarCollapsed && (
            <div className="mb-2 flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
              <div className="min-w-0">
                <div className="truncate text-xs font-bold text-slate-900">{currentUser.name}</div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">
                  {currentUser.role}
                </div>
              </div>
              <button
                type="button"
                onClick={lockNow}
                className="rounded-lg border border-slate-300 bg-white px-2 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-100"
                title="Switch User / Lock (Ctrl+L)"
              >
                Switch
              </button>
            </div>
          )}

          {!sidebarCollapsed && <PWAInstallButton compact />}

          {canDelete && (
            <button
              type="button"
              onClick={() => setModal({ type: 'recycleBin' })}
              title="Recycle Bin"
              className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            >
              <div className="flex items-center gap-3 overflow-hidden">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                  <path d="M3 6h18" />
                  <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                  <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                </svg>
                {!sidebarCollapsed && <span className="truncate">Recycle Bin</span>}
              </div>
              {deletedCount > 0 && (
                <span className="rounded-full bg-red-100 px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums text-red-700">
                  {deletedCount}
                </span>
              )}
            </button>
          )}

          {canViewProfit && (
            <button
              type="button"
              onClick={() => setModal({ type: 'auditLog' })}
              title="Activity Audit Log"
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
              {!sidebarCollapsed && <span className="truncate">Activity Log</span>}
            </button>
          )}

          {isOwner && (
            <button
              type="button"
              onClick={() => setModal({ type: 'backupRestore' })}
              title="Backup, Cloud Sync & Restore"
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                <ellipse cx="12" cy="5" rx="9" ry="3" />
                <path d="M3 5V19A9 3 0 0 0 21 19V5" />
                <path d="M3 12A9 3 0 0 0 21 12" />
              </svg>
              {!sidebarCollapsed && <span className="truncate">Backup &amp; Sync</span>}
            </button>
          )}

          {isOwner && (
            <button
              type="button"
              onClick={() => setModal({ type: 'pinSettings' })}
              title="Users, PINs & Auto-Lock"
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
              </svg>
              {!sidebarCollapsed && <span className="truncate">PINs &amp; Auto-Lock</span>}
            </button>
          )}

          {hasUsers && (
            <button
              type="button"
              onClick={lockNow}
              title="Lock App Immediately (Ctrl+L)"
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-amber-700 hover:bg-amber-50"
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
              {!sidebarCollapsed && <span className="truncate">Lock App</span>}
            </button>
          )}
        </div>
      </aside>

      {/* Main Content Workspace */}
      <div className="flex min-w-0 flex-1 flex-col">
        <OfflineIndicator />

        {/* Mobile Compact Header */}
        <header className="pt-safe flex h-14 shrink-0 items-center justify-between gap-2 border-b border-slate-200 bg-white px-3.5 md:hidden">
          <div className="flex min-w-0 items-center gap-2.5">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-white">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 17H3a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1l3-4h10l3 4h1a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-2" />
                <circle cx="7" cy="17" r="2.5" />
                <circle cx="17" cy="17" r="2.5" />
              </svg>
            </div>
            <div className="min-w-0">
              <h1 className="truncate text-sm font-bold text-slate-900">{sectionMeta[section].mobileTitle}</h1>
              {currentUser && (
                <div className="truncate text-[10px] font-semibold text-slate-500">{currentUser.name}</div>
              )}
            </div>
          </div>

          <button
            type="button"
            className="btn btn-primary min-h-[40px] px-3 text-xs"
            onClick={() => setModal({ type: 'create' })}
          >
            + New Car
          </button>
        </header>

        {/* Desktop Header */}
        <header className="hidden h-16 shrink-0 items-center justify-between gap-4 border-b border-slate-200 bg-white px-6 md:flex">
          <div>
            <h1 className="text-base font-bold leading-tight text-slate-900">{sectionMeta[section].title}</h1>
            <p className="text-xs text-slate-500">{sectionMeta[section].subtitle}</p>
          </div>

          <div className="flex items-center gap-2.5">
            {canMarkSold && (
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setModal({ type: 'create', startSold: true })}
              >
                + Log Sold Car
              </button>
            )}
            <button type="button" className="btn btn-primary" onClick={() => setModal({ type: 'create' })}>
              + Log New Car
            </button>
          </div>
        </header>

        <main
          className={`flex min-h-0 flex-1 flex-col gap-4 px-3.5 py-3.5 pb-24 sm:px-6 sm:py-5 md:pb-5 ${
            section === 'DEALS' ? 'overflow-y-auto md:overflow-hidden' : 'overflow-y-auto'
          }`}
        >
          {loading ? (
            <div className="flex h-64 items-center justify-center text-sm text-slate-500">Loading showroom data…</div>
          ) : section === 'HOME' ? (
            <HomeView
              deals={deals}
              canViewProfit={canViewProfit}
              canManagePayments={canManagePayments}
              onInspect={(deal) => setInspectedDeal(deal)}
              onWhatsApp={(deal) => setModal({ type: 'whatsapp', deal, mode: 'RECEIPT' })}
              onPayments={openPayments}
              onReceipt={(deal) => setModal({ type: 'receipt', deal })}
              onCreateNew={(startSold) => setModal({ type: 'create', startSold: startSold && canMarkSold })}
              onNavigateLedger={(initialTab) => {
                if (initialTab) setTab(initialTab);
                setSection('DEALS');
              }}
              onNavigateReports={() => setSection('REPORTS')}
              onNotify={notify}
            />
          ) : section === 'PARTIES' ? (
            <PartiesView
              deals={deals}
              canViewProfit={canViewProfit}
              canManagePayments={canManagePayments}
              onInspectDeal={(deal) => setInspectedDeal(deal)}
              onPayments={openPayments}
              onWhatsApp={(deal, mode) => setModal({ type: 'whatsapp', deal, mode })}
            />
          ) : section === 'REPORTS' && canViewProfit ? (
            <ReportsView
              deals={deals}
              onInspectDealById={inspectDealById}
              onDataChanged={() => void reload()}
            />
          ) : (
            <>
              {canViewProfit && <KpiCards deals={deals} />}

              {/* Filter & Search Toolbar */}
              <div className="flex flex-wrap items-center justify-between gap-2.5 rounded-xl border border-slate-200 bg-white p-3 shadow-2xs">
                <div className="flex w-full flex-wrap items-center gap-2 lg:w-auto">
                  <div className="inline-flex w-full overflow-x-auto rounded-lg border border-slate-200 bg-slate-50 p-0.5 sm:w-auto">
                    {tabs.map((t) => (
                      <button
                        key={t.key}
                        type="button"
                        onClick={() => setTab(t.key)}
                        className={`flex min-h-[34px] flex-1 items-center justify-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-semibold transition sm:min-h-0 sm:flex-initial ${
                          tab === t.key ? 'bg-brand-600 text-white shadow-2xs' : 'text-slate-700 hover:bg-white'
                        }`}
                      >
                        {t.label}
                        <span
                          className={`rounded-full px-1.5 py-px font-mono text-[11px] tabular-nums ${
                            tab === t.key ? 'bg-white/20 text-white' : 'bg-slate-200/80 text-slate-600'
                          }`}
                        >
                          {counts[t.key]}
                        </span>
                      </button>
                    ))}
                  </div>

                  <select
                    aria-label="Filter by file transfer status"
                    className="input h-9 w-[calc(50%-4px)] py-1 text-xs sm:h-8 sm:w-40"
                    value={transferFilter}
                    onChange={(e) => setTransferFilter(e.target.value as TransferFilter)}
                  >
                    <option value="ALL">File: All Statuses</option>
                    <option value="PENDING">File: Pending (w/ Us)</option>
                    <option value="WITH_AGENT">File: With Agent</option>
                    <option value="COMPLETED">File: Transfer Done</option>
                  </select>

                  <select
                    aria-label="Filter by car make"
                    className="input h-9 w-[calc(50%-4px)] py-1 text-xs sm:h-8 sm:w-36"
                    value={makeFilter}
                    onChange={(e) => setMakeFilter(e.target.value)}
                  >
                    <option value="ALL">Make: All</option>
                    {uniqueMakes.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>

                  <select
                    aria-label="Filter by payment balance"
                    className="input h-9 w-[calc(50%-4px)] py-1 text-xs sm:h-8 sm:w-40"
                    value={balanceFilter}
                    onChange={(e) => setBalanceFilter(e.target.value as BalanceFilter)}
                  >
                    <option value="ALL">Balance: All</option>
                    <option value="DUE_TO_SELLER">Due to Seller</option>
                    <option value="DUE_FROM_BUYER">Due from Buyer</option>
                    <option value="SETTLED">Fully Settled</option>
                  </select>

                  <select
                    aria-label="Sort inventory"
                    className="input h-9 w-[calc(50%-4px)] py-1 text-xs sm:h-8 sm:w-44"
                    value={sortMode}
                    onChange={(e) => setSortMode(e.target.value as SortMode)}
                  >
                    <option value="NEWEST">Sort: Newest Purchase</option>
                    <option value="AGING_DESC">Sort: Longest in Stock</option>
                    <option value="BALANCE_DUE">Sort: Highest Balance Due</option>
                    {canViewProfit && <option value="PROFIT_DESC">Sort: Highest Profit</option>}
                  </select>

                  <div className="hidden items-center gap-1.5 text-xs text-slate-500 sm:flex">
                    <span className="font-medium">Added:</span>
                    <input
                      type="date"
                      aria-label="Entry added from date"
                      className="input h-8 w-32 py-1 text-xs"
                      value={addedFrom}
                      onChange={(e) => setAddedFrom(e.target.value)}
                    />
                    <span>–</span>
                    <input
                      type="date"
                      aria-label="Entry added to date"
                      className="input h-8 w-32 py-1 text-xs"
                      value={addedTo}
                      onChange={(e) => setAddedTo(e.target.value)}
                    />
                  </div>

                  {hasExtraFilters && (
                    <button type="button" onClick={resetAllFilters} className="btn btn-secondary btn-sm text-xs">
                      Reset ({visible.length}/{deals.length})
                    </button>
                  )}
                </div>

                <div className="relative w-full lg:w-72">
                  <input
                    ref={searchRef}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Escape' && setQuery('')}
                    placeholder="Search reg #, car, seller, buyer, agent…"
                    className="input h-9 bg-white pr-8 text-xs sm:h-8"
                  />
                  {query && (
                    <button
                      type="button"
                      aria-label="Clear search"
                      onClick={() => setQuery('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded px-1.5 py-0.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
                    >
                      ×
                    </button>
                  )}
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white shadow-2xs md:min-h-0 md:flex-1 md:overflow-auto">
                {visible.length === 0 ? (
                  <div className="flex h-72 flex-col items-center justify-center px-6 text-center">
                    <div className="text-base font-semibold text-slate-900">
                      {deals.length === 0 ? 'No car deals recorded yet' : 'No cars match this filter'}
                    </div>
                    <p className="mt-1 max-w-md text-sm text-slate-500">
                      {deals.length === 0
                        ? 'Tap "+ New Car" to record a purchase, or "+ Log Sold Car" if you already sold one.'
                        : 'Try clearing the search box or resetting your active filters.'}
                    </p>
                    <div className="mt-4 flex flex-wrap justify-center gap-2">
                      {deals.length === 0 ? (
                        <>
                          {canMarkSold && (
                            <button type="button" className="btn btn-secondary" onClick={() => setModal({ type: 'create', startSold: true })}>
                              + Log Sold Car
                            </button>
                          )}
                          <button type="button" className="btn btn-primary" onClick={() => setModal({ type: 'create' })}>
                            + Log New Car
                          </button>
                        </>
                      ) : (
                        <button type="button" className="btn btn-secondary" onClick={resetAllFilters}>
                          Reset filters
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  <DealsTable
                    deals={visible}
                    canViewProfit={canViewProfit}
                    canManagePayments={canManagePayments}
                    canMarkSold={canMarkSold}
                    canDelete={canDelete}
                    onInspect={(deal) => setInspectedDeal(deal)}
                    onWhatsApp={(deal) => setModal({ type: 'whatsapp', deal, mode: 'RECEIPT' })}
                    onExpense={(deal) => setModal({ type: 'expenses', deal })}
                    onPayments={openPayments}
                    onReceipt={(deal) => setModal({ type: 'receipt', deal })}
                    onReserve={openReserve}
                    onSold={openSold}
                    onEdit={(deal) => setModal({ type: 'edit', deal })}
                    onDelete={openDelete}
                  />
                )}
              </div>
            </>
          )}
        </main>
      </div>

      {/* Mobile Bottom Tab Bar */}
      <nav
        aria-label="Mobile Navigation"
        className="pb-safe fixed inset-x-0 bottom-0 z-30 flex items-stretch border-t border-slate-200 bg-white/95 backdrop-blur-md md:hidden"
      >
        <button
          type="button"
          onClick={() => {
            setMobileMoreOpen(false);
            setSection('HOME');
          }}
          className={`flex min-h-[54px] flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${
            section === 'HOME' && !mobileMoreOpen ? 'text-brand-600' : 'text-slate-500'
          }`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
            <polyline points="9 22 9 12 15 12 15 22" />
          </svg>
          <span>Home</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setMobileMoreOpen(false);
            setSection('DEALS');
          }}
          className={`flex min-h-[54px] flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${
            section === 'DEALS' && !mobileMoreOpen ? 'text-brand-600' : 'text-slate-500'
          }`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect width="18" height="18" x="3" y="3" rx="2" />
            <path d="M3 9h18" />
            <path d="M9 21V9" />
          </svg>
          <span>Deals</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setMobileMoreOpen(false);
            setSection('PARTIES');
          }}
          className={`flex min-h-[54px] flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${
            section === 'PARTIES' && !mobileMoreOpen ? 'text-brand-600' : 'text-slate-500'
          }`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
            <circle cx="9" cy="7" r="4" />
            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
          </svg>
          <span>Parties</span>
        </button>

        {canViewProfit && (
          <button
            type="button"
            onClick={() => {
              setMobileMoreOpen(false);
              setSection('REPORTS');
            }}
            className={`flex min-h-[54px] flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${
              section === 'REPORTS' && !mobileMoreOpen ? 'text-brand-600' : 'text-slate-500'
            }`}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" x2="18" y1="20" y2="10" />
              <line x1="12" x2="12" y1="20" y2="4" />
              <line x1="6" x2="6" y1="20" y2="14" />
            </svg>
            <span>Reports</span>
          </button>
        )}

        <button
          type="button"
          onClick={() => setMobileMoreOpen((v) => !v)}
          className={`flex min-h-[54px] flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${
            mobileMoreOpen ? 'text-brand-600' : 'text-slate-500'
          }`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="1" />
            <circle cx="12" cy="5" r="1" />
            <circle cx="12" cy="19" r="1" />
          </svg>
          <span>More</span>
        </button>
      </nav>

      {/* Mobile More Menu Bottom Sheet */}
      {mobileMoreOpen && (
        <div
          className="fixed inset-0 z-40 flex items-end bg-slate-900/40 md:hidden"
          onClick={() => setMobileMoreOpen(false)}
        >
          <div
            className="pb-safe w-full rounded-t-2xl border-t border-slate-200 bg-white p-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div>
                <div className="text-sm font-bold text-slate-900">Showroom Tools</div>
                {currentUser && (
                  <div className="text-xs text-slate-500">
                    Signed in as {currentUser.name} ({currentUser.role})
                  </div>
                )}
              </div>
              <button
                type="button"
                onClick={() => setMobileMoreOpen(false)}
                className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-700"
              >
                Close
              </button>
            </div>

            <div className="space-y-1.5">
              {canMarkSold && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMoreOpen(false);
                    setModal({ type: 'create', startSold: true });
                  }}
                  className="flex min-h-[44px] w-full items-center rounded-xl px-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
                >
                  + Log Direct Sold Car
                </button>
              )}

              <PWAInstallButton compact />

              {canViewProfit && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMoreOpen(false);
                    setModal({ type: 'auditLog' });
                  }}
                  className="flex min-h-[44px] w-full items-center rounded-xl px-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
                >
                  Activity Audit Log
                </button>
              )}

              {canDelete && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMoreOpen(false);
                    setModal({ type: 'recycleBin' });
                  }}
                  className="flex min-h-[44px] w-full items-center justify-between rounded-xl px-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
                >
                  <span>Recycle Bin</span>
                  {deletedCount > 0 && (
                    <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-bold text-red-700">
                      {deletedCount}
                    </span>
                  )}
                </button>
              )}

              {isOwner && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMoreOpen(false);
                    setModal({ type: 'backupRestore' });
                  }}
                  className="flex min-h-[44px] w-full items-center rounded-xl px-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
                >
                  Backups, Sync &amp; Restore
                </button>
              )}

              {isOwner && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMoreOpen(false);
                    setModal({ type: 'pinSettings' });
                  }}
                  className="flex min-h-[44px] w-full items-center rounded-xl px-3 text-sm font-semibold text-slate-800 hover:bg-slate-50"
                >
                  Users, PINs &amp; Auto-Lock
                </button>
              )}

              {hasUsers && (
                <button
                  type="button"
                  onClick={lockNow}
                  className="flex min-h-[44px] w-full items-center rounded-xl px-3 text-sm font-bold text-amber-700 hover:bg-amber-50"
                >
                  Lock App / Switch User
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Slide-Over Inspection Drawer */}
      {inspectedDeal && (
        <DealDrawer
          deal={liveDeal(inspectedDeal)}
          allDeals={deals}
          currentUser={currentUser}
          onClose={() => setInspectedDeal(null)}
          onInspectDealById={inspectDealById}
          onWhatsApp={(deal, mode) => setModal({ type: 'whatsapp', deal, mode })}
          onExpense={(deal) => setModal({ type: 'expenses', deal })}
          onPayments={openPayments}
          onReceipt={(deal) => setModal({ type: 'receipt', deal })}
          onReserve={openReserve}
          onSold={openSold}
          onEdit={(deal) => setModal({ type: 'edit', deal })}
          onDealChanged={() => void reload()}
          onNotify={(msg) => notify(msg)}
        />
      )}

      {/* WhatsApp Recipient & Receipt Picker Modal */}
      {modal?.type === 'whatsapp' && (
        <WhatsAppShareModal
          deal={liveDeal(modal.deal)}
          initialMode={modal.mode}
          onClose={() => setModal(null)}
          onSent={(msg) => {
            setModal(null);
            notify(msg);
          }}
        />
      )}

      {modal?.type === 'create' && (
        <DealFormModal
          mode="create"
          startSold={modal.startSold && canMarkSold}
          deals={deals}
          canManagePayments={canManagePayments}
          onInspectExisting={(existing) => {
            setModal(null);
            setInspectedDeal(existing);
          }}
          onClose={() => setModal(null)}
          onSaved={(msg) => {
            setModal(null);
            void reload();
            notify(msg);
          }}
        />
      )}
      {modal?.type === 'edit' && (
        <DealFormModal
          mode="edit"
          deal={liveDeal(modal.deal)}
          deals={deals}
          canManagePayments={canManagePayments}
          onInspectExisting={(existing) => {
            setModal(null);
            setInspectedDeal(existing);
          }}
          onClose={() => setModal(null)}
          onSaved={(msg) => {
            setModal(null);
            void reload();
            notify(msg);
          }}
        />
      )}
      {modal?.type === 'expenses' && (
        <ExpenseModal
          deal={liveDeal(modal.deal)}
          deals={deals}
          canViewProfit={canViewProfit}
          onClose={() => setModal(null)}
          onChanged={() => void reload()}
        />
      )}
      {modal?.type === 'payments' && (
        <PaymentsModal deal={liveDeal(modal.deal)} onClose={() => setModal(null)} onChanged={() => void reload()} />
      )}
      {modal?.type === 'receipt' && (
        <ReceiptModal
          deal={liveDeal(modal.deal)}
          onClose={() => setModal(null)}
          onSavedPdf={(filePath) => {
            setModal(null);
            if (isElectron && filePath) {
              notify('Receipt saved as PDF', {
                label: 'Open folder',
                onClick: () => void window.api?.showInFolder(filePath),
              });
            } else {
              notify('Receipt PDF ready');
            }
          }}
        />
      )}
      {modal?.type === 'reserve' && (
        <ReserveModal
          deal={liveDeal(modal.deal)}
          deals={deals}
          onClose={() => setModal(null)}
          onSaved={(msg) => {
            setModal(null);
            void reload();
            notify(msg);
          }}
        />
      )}
      {modal?.type === 'sold' && (
        <SoldModal
          deal={liveDeal(modal.deal)}
          deals={deals}
          canViewProfit={canViewProfit}
          canManagePayments={canManagePayments}
          onClose={() => setModal(null)}
          onSaved={(msg) => {
            setModal(null);
            void reload();
            notify(msg);
          }}
        />
      )}
      {modal?.type === 'delete' && (
        <ConfirmDialog
          title="Move car to Recycle Bin?"
          confirmLabel="Move to Recycle Bin"
          onCancel={() => setModal(null)}
          onConfirm={() => void softDeleteDeal(modal.deal)}
          message={
            <>
              <p>
                <strong>{carTitle(modal.deal)}</strong> ({regOf(modal.deal)}) will be moved to the Recycle Bin.
              </p>
              <p className="mt-2 text-slate-500">You can restore it anytime from the Recycle Bin.</p>
            </>
          }
        />
      )}
      {modal?.type === 'recycleBin' && (
        <RecycleBinModal
          onClose={() => setModal(null)}
          onChanged={(msg) => {
            void reload();
            notify(msg);
          }}
        />
      )}
      {modal?.type === 'auditLog' && (
        <AuditLogModal
          deals={deals}
          onClose={() => setModal(null)}
          onInspectDealById={inspectDealById}
        />
      )}
      {modal?.type === 'backupRestore' && (
        <BackupRestoreModal
          onClose={() => setModal(null)}
          onManualBackup={(kind) => void runExport(kind)}
          onRestored={(msg) => {
            setModal(null);
            void (async () => {
              if (!window.api) return;
              const [usersExist, lockMins, userList] = await Promise.all([
                window.api.hasUsers(),
                window.api.getAutoLockMinutes(),
                window.api.listUsers(),
              ]);
              setHasUsers(usersExist);
              setAutoLockMinutes(lockMins);
              setInspectedDeal(null);
              if (usersExist) {
                const owner = userList.find((u) => u.role === 'OWNER') ?? userList[0] ?? null;
                setCurrentUser(owner);
                setLocked(false);
              } else {
                setCurrentUser(null);
                setLocked(false);
              }
              await reload();
              notify(msg);
            })();
          }}
        />
      )}
      {modal?.type === 'pinSettings' && (
        <PinSettingsModal
          currentUser={currentUser}
          onClose={() => setModal(null)}
          onAutoLockChanged={(mins) => {
            setAutoLockMinutes(mins);
            notify(mins > 0 ? `Auto-lock set to ${mins} minute${mins === 1 ? '' : 's'}` : 'Auto-lock disabled');
          }}
          onUsersChanged={(updatedList, msg) => {
            setHasUsers(updatedList.length > 0);
            if (updatedList.length === 0) {
              setCurrentUser(null);
            } else if (currentUser) {
              const refreshed = updatedList.find((u) => u.id === currentUser.id) ?? null;
              setCurrentUser(refreshed);
            }
            notify(msg);
          }}
        />
      )}

      {toast && (
        <div
          role="status"
          className="fixed bottom-20 right-4 z-50 flex max-w-[calc(100vw-2rem)] items-center gap-3 rounded-xl bg-slate-900 px-4 py-2.5 text-sm text-white shadow-lg md:bottom-5 md:right-5"
        >
          <span>{toast.text}</span>
          {toast.action && (
            <button type="button" onClick={toast.action.onClick} className="shrink-0 font-semibold text-blue-300 underline hover:text-blue-200">
              {toast.action.label}
            </button>
          )}
        </div>
      )}
    </div>
  );
}