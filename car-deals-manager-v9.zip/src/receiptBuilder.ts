import {
  CHECKLIST_ITEMS,
  DEFAULT_BUSINESS_PROFILE,
  type BusinessProfile,
  type DealWithTotals,
  type Payment,
} from './types';
import { carTitle, fmtDate, fmtMoney, numberToWords, parseChecklist, regOf } from './utils';

/**
 * 'buying'    => We are the PURCHASER (buying the car from deal.seller_*)
 * 'sale'      => We are the SELLER (selling the car to deal.purchaser_*)
 * 'bayana'    => Dedicated Bayana / Token Hold Receipt (hold expiry + forfeit/refund terms)
 * 'spec_card' => Printable Window Spec Sheet (specs + asking price ONLY — zero cost/profit/seller info)
 */
export type ReceiptKind = 'buying' | 'sale' | 'bayana' | 'spec_card';

export type BayanaForfeitMode = 'NON_REFUNDABLE' | 'REFUNDABLE';

export interface ReceiptOptions {
  kind: ReceiptKind;
  deal: DealWithTotals;
  payments: Payment[];
  profile: BusinessProfile;
  paymentModeOverride?: string;
  vehicleType?: 'Motor Cycle' | 'Scooter' | 'Car' | 'Bus';
  includeTikliNote?: boolean;
  extraTerms?: string;
  // Bayana options
  bayanaTokenAmount?: number | null;
  bayanaAgreedPrice?: number | null;
  bayanaHoldDate?: string;
  bayanaExpiryDate?: string;
  bayanaBuyerName?: string;
  bayanaBuyerContact?: string;
  bayanaForfeitMode?: BayanaForfeitMode;
  // Window Spec Card options
  askingPrice?: number | null;
  specShowMileage?: boolean;
  specHighlightNote?: string;
}

interface PartyBlock {
  name: string;
  fatherName: string;
  cnic: string;
  contact: string;
  address: string;
}

function escHtml(s: string | number | null | undefined): string {
  if (s === null || s === undefined || String(s).trim() === '') return '&nbsp;';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escPlain(s: string | number | null | undefined): string {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** Renders the 13-box Pakistani CNIC grid (5 boxes - 7 boxes - 1 box) matching the physical form. */
function renderCnicBoxes(cnic: string): string {
  const digits = (cnic || '').replace(/\D/g, '').padEnd(13, ' ').slice(0, 13).split('');
  const box = (ch: string) =>
    `<span class="cnic-box">${ch === ' ' ? '&nbsp;' : escHtml(ch)}</span>`;

  const part1 = digits.slice(0, 5).map(box).join('');
  const part2 = digits.slice(5, 12).map(box).join('');
  const part3 = digits.slice(12, 13).map(box).join('');

  return `<div class="cnic-row">${part1}${box('-')}${part2}${box('-')}${part3}</div>`;
}

function buildBayanaReceiptHtml(opts: ReceiptOptions, profile: BusinessProfile): string {
  const { deal, payments } = opts;
  const tokenPayments = payments.filter((p) => p.direction === 'IN_FROM_BUYER' && p.payment_type === 'Token');
  const tokenAmt =
    opts.bayanaTokenAmount ??
    deal.reserved_token_amount ??
    (tokenPayments.length > 0 ? tokenPayments.reduce((s, p) => s + p.amount, 0) : null);

  const amountStr =
    tokenAmt !== null && tokenAmt > 0
      ? `${fmtMoney(tokenAmt)} (${numberToWords(tokenAmt)} Rupees Only)`
      : 'Rs. __________________';

  const agreedPriceStr =
    opts.bayanaAgreedPrice !== undefined && opts.bayanaAgreedPrice !== null && opts.bayanaAgreedPrice > 0
      ? `${fmtMoney(opts.bayanaAgreedPrice)} (${numberToWords(opts.bayanaAgreedPrice)} Rupees)`
      : deal.reserved_notes?.trim() || '';

  const holdDate = opts.bayanaHoldDate || deal.reserved_date || '';
  const expiryDate = opts.bayanaExpiryDate || deal.reserved_expiry_date || '';
  const buyerName = opts.bayanaBuyerName ?? deal.reserved_buyer_name ?? deal.purchaser_name ?? '';
  const buyerContact = opts.bayanaBuyerContact ?? deal.reserved_buyer_contact ?? deal.purchaser_contact ?? '';
  const forfeitMode: BayanaForfeitMode = opts.bayanaForfeitMode ?? 'NON_REFUNDABLE';

  let modeText = opts.paymentModeOverride?.trim() ?? '';
  if (!modeText && tokenPayments.length > 0) {
    const methods = Array.from(new Set(tokenPayments.map((p) => p.method)));
    const refs = tokenPayments.map((p) => p.cheque_number ? `Chq #${p.cheque_number}` : p.notes.trim()).filter(Boolean);
    modeText = methods.join(' / ') + (refs.length ? ` (${refs.join(', ')})` : '');
  }

  const termsHtml =
    forfeitMode === 'NON_REFUNDABLE'
      ? `<li><strong>Bayana / Forfeit Clause:</strong> If the Purchaser fails to pay the remaining balance and take delivery on or before <strong>${escHtml(expiryDate ? fmtDate(expiryDate) : 'the hold expiry date')}</strong>, this Bayana / Token advance shall stand <strong>forfeited</strong> and the Seller/Showroom shall be free to sell the vehicle to another party without further notice.</li>
         <li><strong>Seller Commitment:</strong> During this hold period, the vehicle is reserved exclusively for the Purchaser. Should the Seller fail to hand over the vehicle or verified documents as agreed, the Seller shall refund the Token amount in full.</li>`
      : `<li><strong>Refundable Hold Terms:</strong> This Token advance reserves the vehicle until <strong>${escHtml(expiryDate ? fmtDate(expiryDate) : 'the hold expiry date')}</strong>. Any inspection discrepancies or mutual cancellation within the hold window entitles the Purchaser to a full refund of the Token amount.</li>`;

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Bayana / Token Receipt - ${escPlain(regOf(deal))}</title>
<style>
  @page { size: A4 portrait; margin: 12mm 14mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Arial, Helvetica, sans-serif; color: #111827; margin: 0; padding: 0; font-size: 12.5px; line-height: 1.55; background: #fff; }
  .page { max-width: 750px; margin: 0 auto; border: 2px solid #0f172a; border-radius: 6px; padding: 20px 24px; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 14px; gap: 16px; }
  .biz-name { font-size: 19px; font-weight: 800; letter-spacing: 0.4px; text-transform: uppercase; color: #0f172a; }
  .biz-sub { font-size: 11px; color: #475569; margin-top: 2px; }
  .badge { background: #fef3c7; border: 1.5px solid #d97706; color: #92400e; font-weight: 800; font-size: 12px; padding: 6px 12px; border-radius: 4px; text-transform: uppercase; white-space: nowrap; }
  .title { text-align: center; font-size: 16px; font-weight: 800; text-decoration: underline; letter-spacing: 0.6px; margin: 4px 0 14px; }
  .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 20px; margin-bottom: 12px; }
  .field { display: flex; align-items: flex-end; gap: 6px; margin-bottom: 8px; }
  .lbl { white-space: nowrap; font-weight: 600; color: #334155; font-size: 12px; }
  .val { flex: 1; border-bottom: 1px solid #0f172a; padding: 0 5px 1px; font-weight: 700; color: #000; min-height: 18px; }
  .mono { font-family: Consolas, 'Courier New', monospace; }
  .amount-box { background: #f8fafc; border: 1.5px solid #0f172a; border-radius: 5px; padding: 10px 14px; margin: 12px 0; }
  .amount-main { font-size: 15px; font-weight: 800; color: #0f172a; }
  .terms { background: #fffbeb; border: 1px solid #fcd34d; border-radius: 5px; padding: 10px 14px; margin: 14px 0; font-size: 11.5px; }
  .terms h4 { margin: 0 0 6px; font-size: 12px; text-transform: uppercase; color: #92400e; letter-spacing: 0.4px; }
  .terms ol { margin: 0; padding-left: 18px; }
  .terms li { margin-bottom: 4px; }
  .sigs { display: grid; grid-template-columns: 1fr 1fr; gap: 36px; margin-top: 34px; }
  .sig-box { border-top: 1px solid #0f172a; padding-top: 6px; font-size: 11.5px; }
</style>
</head>
<body>
  <div class="page">
    <div class="header">
      <div>
        <div class="biz-name">${escHtml(profile.business_name.trim() || 'CAR SHOWROOM / DEALERSHIP')}</div>
        ${profile.tagline.trim() ? `<div class="biz-sub">${escHtml(profile.tagline)}</div>` : ''}
        <div class="biz-sub">${escHtml([profile.owner_name, profile.phone, profile.address].filter(Boolean).join(' · '))}</div>
      </div>
      <div class="badge">Bayana / Token Hold</div>
    </div>

    <div class="title">TOKEN / BAYANA RECEIPT &amp; VEHICLE HOLD AGREEMENT</div>

    <div class="grid-2">
      <div class="field"><span class="lbl">Token Date:</span><span class="val">${escHtml(holdDate ? fmtDate(holdDate) : '')}</span></div>
      <div class="field"><span class="lbl">Hold Valid Until:</span><span class="val" style="color:#b45309;">${escHtml(expiryDate ? fmtDate(expiryDate) : '')}</span></div>
    </div>

    <div class="amount-box">
      <div style="font-size:11px;text-transform:uppercase;color:#475569;font-weight:700;">Token / Bayana Received With Thanks</div>
      <div class="amount-main">${escHtml(amountStr)}</div>
      <div class="field" style="margin-top:8px;margin-bottom:0;">
        <span class="lbl">Payment Mode / Ref:</span><span class="val">${escHtml(modeText || 'Cash')}</span>
      </div>
    </div>

    <div class="grid-2">
      <div class="field"><span class="lbl">Received From (Buyer):</span><span class="val">${escHtml(buyerName)}</span></div>
      <div class="field"><span class="lbl">Contact No:</span><span class="val mono">${escHtml(buyerContact)}</span></div>
    </div>

    <div style="font-size:11.5px;font-weight:800;text-transform:uppercase;color:#334155;margin:10px 0 6px;border-bottom:1px solid #cbd5e1;padding-bottom:3px;">
      Reserved Vehicle Particulars
    </div>
    <div class="grid-2">
      <div class="field"><span class="lbl">Vehicle:</span><span class="val">${escHtml(carTitle(deal))}</span></div>
      <div class="field"><span class="lbl">Registration No:</span><span class="val mono">${escHtml(deal.registration_number)}</span></div>
      <div class="field"><span class="lbl">Color / Engine CC:</span><span class="val">${escHtml([deal.color, deal.horse_power].filter(Boolean).join(' · '))}</span></div>
      <div class="field"><span class="lbl">Engine / Chassis No:</span><span class="val mono">${escHtml([deal.engine_number, deal.chassis_number].filter(Boolean).join(' / '))}</span></div>
    </div>

    ${
      agreedPriceStr
        ? `<div class="field"><span class="lbl">Agreed Deal Price / Hold Terms:</span><span class="val">${escHtml(agreedPriceStr)}</span></div>`
        : ''
    }

    <div class="terms">
      <h4>Bayana &amp; Token Terms</h4>
      <ol>
        ${termsHtml}
        <li>Original vehicle file, registration card/book, and biometric verification shall be handed over strictly upon clearance of 100% agreed balance.</li>
      </ol>
      ${opts.extraTerms?.trim() ? `<div style="margin-top:6px;"><strong>Remarks:</strong> ${escHtml(opts.extraTerms.trim())}</div>` : ''}
    </div>

    <div class="sigs">
      <div class="sig-box">
        <div><strong>Purchaser / Token Payer Signature</strong></div>
        <div style="margin-top:4px;">Name: ${escHtml(buyerName)}</div>
        <div>Phone: ${escHtml(buyerContact)}</div>
      </div>
      <div class="sig-box">
        <div><strong>Authorized Dealer / Seller Signature</strong></div>
        <div style="margin-top:4px;">Name: ${escHtml(profile.owner_name || deal.seller_name)}</div>
        <div>Phone: ${escHtml(profile.phone)}</div>
      </div>
    </div>
  </div>
</body>
</html>`;
}

/**
 * Generates a clean Showroom Window Spec Sheet for display on windshields or sharing with walk-in buyers.
 * Intentionally excludes ALL purchase prices, repair expenses, profit margins, and seller details.
 */
function buildWindowSpecCardHtml(opts: ReceiptOptions, profile: BusinessProfile): string {
  const { deal } = opts;
  const checklist = parseChecklist(deal.checklist_json);
  const verifiedItems = CHECKLIST_ITEMS.filter((i) => Boolean(checklist[i.key]));
  const askingStr =
    opts.askingPrice !== undefined && opts.askingPrice !== null && opts.askingPrice > 0
      ? fmtMoney(opts.askingPrice)
      : 'Demand Upon Inspection';

  const specs: [string, string][] = [
    ['Make & Model', [deal.make, deal.model].filter(Boolean).join(' ') || '—'],
    ['Variant / Trim', deal.variant || '—'],
    ['Model Year', deal.year ? String(deal.year) : '—'],
    ['Registration #', deal.registration_number || 'Unregistered / Applied'],
    ['Exterior Color', deal.color || '—'],
    ['Engine Capacity', deal.horse_power || '—'],
    ...(opts.specShowMileage !== false
      ? [['Mileage', deal.mileage ? `${deal.mileage.toLocaleString('en-US')} km` : '—'] as [string, string]]
      : []),
    ['Token Tax Paid', deal.token_tax_paid_till || '—'],
  ];

  const displayName = profile.business_name.trim() || profile.owner_name.trim() || 'Showroom Vehicle Spec Sheet';
  const contactLine = [profile.owner_name, profile.phone, profile.address].filter(Boolean).join(' · ');

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Showroom Spec Sheet - ${escPlain(carTitle(deal))}</title>
<style>
  @page { size: A4 portrait; margin: 12mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Arial, Helvetica, sans-serif; color: #0f172a; margin: 0; padding: 0; background: #fff; }
  .card { max-width: 740px; margin: 0 auto; border: 3px solid #0f172a; border-radius: 12px; overflow: hidden; }
  .hero { background: #0f172a; color: #fff; padding: 24px 28px; display: flex; justify-content: space-between; align-items: center; gap: 20px; }
  .hero-sub { font-size: 12px; text-transform: uppercase; letter-spacing: 1.5px; color: #94a3b8; font-weight: 700; }
  .hero-title { font-size: 30px; font-weight: 900; line-height: 1.15; margin-top: 4px; }
  .year-pill { background: #2563eb; color: #fff; font-size: 22px; font-weight: 900; padding: 10px 18px; border-radius: 8px; white-space: nowrap; }
  .price-band { background: #f1f5f9; border-bottom: 2px solid #cbd5e1; padding: 16px 28px; display: flex; justify-content: space-between; align-items: center; }
  .price-lbl { font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #475569; }
  .price-val { font-size: 28px; font-weight: 900; color: #0f172a; font-variant-numeric: tabular-nums; }
  .body { padding: 22px 28px; }
  .spec-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 24px; }
  .spec-item { border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; display: flex; justify-content: space-between; align-items: baseline; gap: 12px; }
  .spec-k { font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase; }
  .spec-v { font-size: 15px; font-weight: 800; color: #0f172a; text-align: right; }
  .checks { margin-top: 22px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px 18px; }
  .checks h4 { margin: 0 0 10px; font-size: 12px; text-transform: uppercase; letter-spacing: 0.8px; color: #334155; }
  .check-list { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 16px; font-size: 12.5px; font-weight: 600; color: #065f46; }
  .notes { margin-top: 16px; border-left: 4px solid #2563eb; background: #eff6ff; padding: 12px 16px; border-radius: 4px; font-size: 13px; color: #1e293b; }
  .footer { background: #0f172a; color: #e2e8f0; padding: 16px 28px; display: flex; justify-content: space-between; align-items: center; gap: 16px; font-size: 12px; }
  .footer strong { color: #fff; font-size: 14px; }
  @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
</style>
</head>
<body>
  <div class="card">
    <div class="hero">
      <div>
        <div class="hero-sub">${escHtml(displayName)}</div>
        <div class="hero-title">${escHtml([deal.make, deal.model, deal.variant].filter(Boolean).join(' ') || `Vehicle #${deal.id}`)}</div>
      </div>
      ${deal.year ? `<div class="year-pill">${escHtml(deal.year)}</div>` : ''}
    </div>

    <div class="price-band">
      <div class="price-lbl">Asking Price / Showroom Demand</div>
      <div class="price-val">${escHtml(askingStr)}</div>
    </div>

    <div class="body">
      <div class="spec-grid">
        ${specs
          .map(
            ([k, v]) => `
            <div class="spec-item">
              <span class="spec-k">${escHtml(k)}</span>
              <span class="spec-v">${escHtml(v)}</span>
            </div>`,
          )
          .join('')}
      </div>

      ${
        verifiedItems.length > 0
          ? `<div class="checks">
               <h4>Verified Paperwork &amp; Inspection Highlights (${verifiedItems.length}/${CHECKLIST_ITEMS.length})</h4>
               <div class="check-list">
                 ${verifiedItems.map((i) => `<div>&#10003; ${escHtml(i.label)}</div>`).join('')}
               </div>
             </div>`
          : ''
      }

      ${
        (opts.specHighlightNote?.trim() || opts.extraTerms?.trim())
          ? `<div class="notes"><strong>Highlights:</strong> ${escHtml(opts.specHighlightNote?.trim() || opts.extraTerms?.trim())}</div>`
          : ''
      }
    </div>

    <div class="footer">
      <div>
        <strong>${escHtml(displayName)}</strong>
        ${profile.tagline.trim() ? ` — ${escHtml(profile.tagline)}` : ''}
      </div>
      <div>${escHtml(contactLine || 'Contact Showroom Desk for Viewing & Test Drive')}</div>
    </div>
  </div>
</body>
</html>`;
}

export function buildReceiptHtml(opts: ReceiptOptions): string {
  const { kind, deal, payments } = opts;
  const profile = { ...DEFAULT_BUSINESS_PROFILE, ...opts.profile };

  if (kind === 'bayana') return buildBayanaReceiptHtml(opts, profile);
  if (kind === 'spec_card') return buildWindowSpecCardHtml(opts, profile);

  const isBuying = kind === 'buying';

  const ourDetails: PartyBlock = {
    name: profile.owner_name.trim() || DEFAULT_BUSINESS_PROFILE.owner_name,
    fatherName: profile.father_name.trim() || DEFAULT_BUSINESS_PROFILE.father_name,
    cnic: profile.cnic.trim() || DEFAULT_BUSINESS_PROFILE.cnic,
    contact: profile.phone.trim() || DEFAULT_BUSINESS_PROFILE.phone,
    address: profile.address.trim() || DEFAULT_BUSINESS_PROFILE.address,
  };

  const seller: PartyBlock = isBuying
    ? {
        name: deal.seller_name ?? '',
        fatherName: deal.seller_father_name ?? '',
        cnic: deal.seller_cnic ?? '',
        contact: deal.seller_contact ?? '',
        address: deal.seller_address ?? '',
      }
    : ourDetails;

  const buyer: PartyBlock = isBuying
    ? ourDetails
    : {
        name: deal.purchaser_name ?? '',
        fatherName: deal.purchaser_father_name ?? '',
        cnic: deal.purchaser_cnic ?? '',
        contact: deal.purchaser_contact ?? '',
        address: deal.purchaser_address ?? '',
      };

  const txDate = isBuying ? deal.purchase_date : deal.sale_date;
  const amount = isBuying ? deal.purchase_price : deal.sale_price;
  const amountStr =
    amount !== null && amount > 0
      ? `${fmtMoney(amount)} (${numberToWords(amount)} Rupees Only)`
      : '';

  const relevantPayments = payments.filter((p) =>
    isBuying ? p.direction === 'OUT_TO_SELLER' : p.direction === 'IN_FROM_BUYER',
  );

  let paymentModeText = opts.paymentModeOverride?.trim() ?? '';
  if (!paymentModeText && relevantPayments.length > 0) {
    const methods = Array.from(new Set(relevantPayments.map((p) => p.method)));
    const notesWithRef = relevantPayments
      .map((p) => (p.cheque_number ? `Chq #${p.cheque_number}` : p.notes.trim()))
      .filter(Boolean);
    paymentModeText = methods.join(' / ') + (notesWithRef.length ? ` (${notesWithRef.join(', ')})` : '');
  }

  const makeModel = [deal.make, deal.model].filter(Boolean).join(' ');
  const modelYear = [deal.variant, deal.year].filter(Boolean).join(' ');
  const selectedType = opts.vehicleType ?? 'Car';

  const vehicleTypes = ['Motor Cycle', 'Scooter', 'Car', 'Bus']
    .map((t) =>
      t === selectedType
        ? `<strong style="text-decoration:underline;">${t}</strong>`
        : `<span style="text-decoration:line-through;color:#64748b;">${t}</span>`,
    )
    .join(' / ');

  const showTikli = opts.includeTikliNote !== false;

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Sale Receipt &amp; Delivery Letter - ${escPlain(regOf(deal))}</title>
<style>
  @page { size: A4 portrait; margin: 10mm 13mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Arial, Helvetica, sans-serif; color: #111827; margin: 0; padding: 0; font-size: 12px; line-height: 1.5; background: #ffffff; }
  .page { max-width: 760px; margin: 0 auto; padding: 4px 6px; }
  .optional-banner { text-align: center; border-bottom: 1.5px solid #111827; padding-bottom: 5px; margin-bottom: 8px; }
  .optional-banner .biz { font-size: 15px; font-weight: 800; letter-spacing: 0.5px; text-transform: uppercase; }
  .optional-banner .sub { font-size: 10.5px; color: #374151; }
  .doc-heading { text-align: center; font-size: 15.5px; font-weight: 800; text-decoration: underline; letter-spacing: 0.5px; margin: 4px 0 9px 0; }
  .line-row { display: flex; align-items: flex-end; gap: 7px; margin-bottom: 6px; width: 100%; }
  .lbl { white-space: nowrap; font-weight: 500; color: #111827; }
  .fill { flex: 1; border-bottom: 1px solid #111827; padding: 0 5px 1px 5px; font-weight: 700; min-height: 17px; color: #000000; }
  .mono { font-family: Consolas, 'Courier New', monospace; }
  .split-2 { display: grid; grid-template-columns: 1fr 1.18fr; gap: 24px; margin-top: 8px; }
  .cnic-row { display: inline-flex; align-items: center; margin-top: 4px; }
  .cnic-box { display: inline-flex; align-items: center; justify-content: center; width: 18px; height: 20px; border: 1px solid #111827; font-weight: 700; font-size: 11.5px; margin-right: -1px; }
  .tear-line { border: none; border-top: 1.5px dashed #111827; margin: 14px 0 12px 0; }
  .liability-text { margin: 7px 0 9px 0; font-size: 11.8px; line-height: 1.42; text-align: justify; }
  .tikli-note { margin-top: 12px; font-size: 11.5px; font-weight: 600; line-height: 1.38; max-width: 240px; }
  .extra-remarks { margin-top: 8px; font-size: 10.8px; border: 1px solid #cbd5e1; padding: 4px 8px; background: #f8fafc; }
  @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
</style>
</head>
<body>
  <div class="page">
    ${
      profile.business_name.trim()
        ? `<div class="optional-banner">
             <div class="biz">${escHtml(profile.business_name)}</div>
             ${profile.tagline.trim() ? `<div class="sub">${escHtml(profile.tagline)}</div>` : ''}
           </div>`
        : ''
    }

    <div class="doc-heading">SALE RECEIPT</div>

    <div class="line-row">
      <span class="lbl">RECEIVED with thanks the sum of</span>
      <span class="fill">${escHtml(amountStr)}</span>
    </div>

    <div class="line-row">
      <span class="lbl">Mr.</span>
      <span class="fill" style="flex:1.25;">${escHtml(buyer.name)}</span>
      <span class="lbl">S/O</span>
      <span class="fill" style="flex:1;">${escHtml(buyer.fatherName)}</span>
    </div>

    <div class="line-row">
      <span class="lbl">Resident of</span>
      <span class="fill">${escHtml(buyer.address)}</span>
    </div>

    <div class="line-row">
      <span class="lbl">Against the sale of my ${vehicleTypes}</span>
      <span class="fill">${escHtml(deal.color ? `Color: ${deal.color}` : '')}</span>
    </div>

    <div class="line-row">
      <span class="lbl">Registration No:</span>
      <span class="fill mono">${escHtml(deal.registration_number)}</span>
      <span class="lbl">Make:</span>
      <span class="fill">${escHtml(makeModel)}</span>
      <span class="lbl">Model:</span>
      <span class="fill">${escHtml(modelYear)}</span>
    </div>

    <div class="line-row">
      <span class="lbl">Horse Power:</span>
      <span class="fill">${escHtml(deal.horse_power)}</span>
      <span class="lbl">Engine No:</span>
      <span class="fill mono">${escHtml(deal.engine_number)}</span>
      <span class="lbl">Chassis No:</span>
      <span class="fill mono">${escHtml(deal.chassis_number)}</span>
    </div>

    <div class="line-row">
      <span class="lbl">The full and final payment has been received in Cash/ Cheque No.</span>
      <span class="fill">${escHtml(paymentModeText)}</span>
    </div>

    <div class="split-2">
      <div>
        <div class="line-row">
          <span class="lbl">Dated:</span>
          <span class="fill">${escHtml(txDate ? fmtDate(txDate) : '')}</span>
        </div>
        <div style="margin-top:8px;">
          <div class="lbl">CNIC Number:</div>
          ${renderCnicBoxes(seller.cnic)}
        </div>
      </div>

      <div>
        <div class="line-row">
          <span class="lbl">Signature:</span>
          <span class="fill"></span>
        </div>
        <div class="line-row">
          <span class="lbl">Seller Name:</span>
          <span class="fill">${escHtml(seller.name)}</span>
        </div>
        <div class="line-row">
          <span class="lbl">S/O:</span>
          <span class="fill">${escHtml(seller.fatherName)}</span>
        </div>
        <div class="line-row">
          <span class="lbl">R/O:</span>
          <span class="fill">${escHtml(seller.address)}</span>
        </div>
        <div class="line-row">
          <span class="lbl">Contact No:</span>
          <span class="fill mono">${escHtml(seller.contact)}</span>
        </div>
      </div>
    </div>

    <hr class="tear-line" />

    <div class="doc-heading">DELIVERY LETTER</div>

    <div style="text-align:center; margin-bottom:8px;">
      I have taken the delivery of ${vehicleTypes}
    </div>

    <div class="line-row">
      <span class="lbl">Registration No:</span>
      <span class="fill mono">${escHtml(deal.registration_number)}</span>
      <span class="lbl">Make:</span>
      <span class="fill">${escHtml(makeModel)}</span>
      <span class="lbl">Model:</span>
      <span class="fill">${escHtml(modelYear)}</span>
    </div>

    <div class="line-row">
      <span class="lbl">Horse Power:</span>
      <span class="fill">${escHtml(deal.horse_power)}</span>
      <span class="lbl">Engine No:</span>
      <span class="fill mono">${escHtml(deal.engine_number)}</span>
      <span class="lbl">Chassis No:</span>
      <span class="fill mono">${escHtml(deal.chassis_number)}</span>
    </div>

    <div class="line-row">
      <span class="lbl">from Mr.</span>
      <span class="fill" style="flex:1.25;">${escHtml(seller.name)}</span>
      <span class="lbl">S/O</span>
      <span class="fill" style="flex:1;">${escHtml(seller.fatherName)}</span>
    </div>

    <div class="line-row">
      <span class="lbl">Resident of</span>
      <span class="fill">${escHtml(seller.address)}</span>
    </div>

    <div class="liability-text">
      And now I am responsible for all liabilities of traffic including challans, court proceedings, theft,
      accident and any other illegal activity.
    </div>

    <div class="split-2">
      <div>
        <div class="line-row">
          <span class="lbl">Dated:</span>
          <span class="fill">${escHtml(txDate ? fmtDate(txDate) : '')}</span>
        </div>
        <div style="margin-top:8px;">
          <div class="lbl">CNIC Number:</div>
          ${renderCnicBoxes(buyer.cnic)}
        </div>
        ${
          showTikli
            ? `<div class="tikli-note">
                 Original file along with original tikli and number plates has been received.
               </div>`
            : ''
        }
      </div>

      <div>
        <div class="line-row">
          <span class="lbl">Signature:</span>
          <span class="fill"></span>
        </div>
        <div class="line-row">
          <span class="lbl">Buyer Name:</span>
          <span class="fill">${escHtml(buyer.name)}</span>
        </div>
        <div class="line-row">
          <span class="lbl">S/O:</span>
          <span class="fill">${escHtml(buyer.fatherName)}</span>
        </div>
        <div class="line-row">
          <span class="lbl">R/O:</span>
          <span class="fill">${escHtml(buyer.address)}</span>
        </div>
        <div class="line-row">
          <span class="lbl">Contact No:</span>
          <span class="fill mono">${escHtml(buyer.contact)}</span>
        </div>
      </div>
    </div>

    ${
      opts.extraTerms?.trim()
        ? `<div class="extra-remarks"><strong>Remarks:</strong> ${escHtml(opts.extraTerms.trim())}</div>`
        : ''
    }
  </div>
</body>
</html>`;
}