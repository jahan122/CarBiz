import { createRoot } from 'react-dom/client';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import App from './App.tsx';
import './index.css';
import { installWebFallbackApi } from './webFallbackApi';
import {
  completeCloudOAuthCallback,
  hydrateClientIdsFromPreferences,
} from './services/cloudSyncEngine';

installWebFallbackApi();
void hydrateClientIdsFromPreferences();

async function handleOAuthUrl(url: string) {
  try {
    const updated = await completeCloudOAuthCallback(url);
    if (updated) {
      window.dispatchEvent(
        new CustomEvent('carbiz:oauth-completed', {
          detail: {
            provider: updated.provider,
            accountEmail: updated.accountEmail ?? null,
          },
        }),
      );
      void window.api?.syncBackupNow();
    }
  } catch (err) {
    console.error('OAuth callback failed:', err);
  }
}

if (Capacitor.isNativePlatform()) {
  void CapApp.addListener('appUrlOpen', ({ url }) => {
    if (url.includes('oauth-callback')) {
      void handleOAuthUrl(url);
    }
  });
} else if (typeof window !== 'undefined' && window.location.pathname.includes('oauth-callback')) {
  void handleOAuthUrl(window.location.href).finally(() => {
    window.history.replaceState({}, document.title, '/');
  });
}

createRoot(document.getElementById('root')!).render(<App />);
