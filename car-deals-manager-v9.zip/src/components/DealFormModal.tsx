import { useEffect, useMemo, useRef, useState } from 'react';
import Modal from './Modal';
import MoneyInput from './MoneyInput';
import WebcamCaptureModal from './WebcamCaptureModal';
import {
  ATTACHMENT_CATEGORY_LABELS,
  CHECKLIST_ITEMS,
  PAYMENT_METHODS,
  PAYMENT_TYPES,
  type AttachmentCategory,
  type ChecklistKey,
  type DealAttachment,
  type DealChecklist,
  type DealWithTotals,
  type InitialPaymentInput,
  type NewDealInput,
  type PaymentMethod,
  type PaymentType,
  type SaleInput,
} from '../types';
import {
  buildPartyDirectory,
  carTitle,
  formatCnic,
  formatPhone,
  moneyToInput,
  normalizeReg,
  parseChecklist,
  parseNum,
  regOf,
  todayISO,
} from '../utils';
import { prepareAttachmentFile } from '../utils/imageCompress';

interface Props {
  mode: 'create' | 'edit';
  startSold?: boolean;
  deal?: DealWithTotals;
  deals?: DealWithTotals[];
  canManagePayments?: boolean;
  onInspectExisting?: (deal: DealWithTotals) => void;
  onClose: () => void;
  onSaved: (message: string) => void;
}

export default function DealFormModal({
  mode,
  startSold = false,
  deal,
  deals = [],
  canManagePayments = true,
  onInspectExisting,
  onClose,
  onSaved,
}: Props) {
  const isEdit = mode === 'edit' && Boolean(deal);

  // Vehicle fields
  const [make, setMake] = useState(deal?.make || '');
  const [model, setModel] = useState(deal?.model || '');
  const [variant, setVariant] = useState(deal?.variant || '');
  const [year, setYear] = useState(deal?.year ? String(deal.year) : '');
  const [color, setColor] = useState(deal?.color || '');
  const [horsePower, setHorsePower] = useState(deal?.horse_power || '');
  const [regNumber, setRegNumber] = useState(deal?.registration_number || '');
  const [chassisNumber, setChassisNumber] = useState(deal?.chassis_number || '');
  const [engineNumber, setEngineNumber] = useState(deal?.engine_number || '');
  const [mileage, setMileage] = useState(deal?.mileage ? String(deal.mileage) : '');

  // Purchase & Seller fields
  const [boughtFrom, setBoughtFrom] = useState(deal?.bought_from_location || '');
  const [purchaseDate, setPurchaseDate] = useState(deal?.purchase_date || todayISO());
  const [purchasePrice, setPurchasePrice] = useState(moneyToInput(deal?.purchase_price));
  const [sellerName, setSellerName] = useState(deal?.seller_name || '');
  const [sellerFatherName, setSellerFatherName] = useState(deal?.seller_father_name || '');
  const [sellerContact, setSellerContact] = useState(deal?.seller_contact || '');
  const [sellerCnic, setSellerCnic] = useState(deal?.seller_cnic || '');
  const [sellerAddress, setSellerAddress] = useState(deal?.seller_address || '');
  const [sellerDueDate, setSellerDueDate] = useState(deal?.seller_due_date || '');
  const [notes, setNotes] = useState(deal?.notes || '');

  // Initial Seller Payment (optional, create mode before draft is saved)
  const [initSellerAmount, setInitSellerAmount] = useState('');
  const [initSellerType, setInitSellerType] = useState<PaymentType>('Advance');
  const [initSellerMethod, setInitSellerMethod] = useState<PaymentMethod>('Cash');
  const [initSellerNotes, setInitSellerNotes] = useState('');

  // Document & Condition Checklist
  const [checklist, setChecklist] = useState<DealChecklist>(() => parseChecklist(deal?.checklist_json));
  const [tokenTaxPaidTill, setTokenTaxPaidTill] = useState(deal?.token_tax_paid_till || '');
  const [showChecklist, setShowChecklist] = useState(true);

  // Optional Immediate Sale fields (only when creating a new already-sold deal)
  const [alreadySold, setAlreadySold] = useState(!isEdit && startSold);
  const [saleDate, setSaleDate] = useState(todayISO());
  const [salePrice, setSalePrice] = useState('');
  const [purchaserName, setPurchaserName] = useState('');
  const [purchaserFatherName, setPurchaserFatherName] = useState('');
  const [purchaserContact, setPurchaserContact] = useState('');
  const [purchaserCnic, setPurchaserCnic] = useState('');
  const [purchaserAddress, setPurchaserAddress] = useState('');
  const [buyerDueDate, setBuyerDueDate] = useState('');

  // Initial Buyer Payment (when alreadySold is checked in create mode)
  const [initBuyerAmount, setInitBuyerAmount] = useState('');
  const [initBuyerType, setInitBuyerType] = useState<PaymentType>('Final Balance');
  const [initBuyerMethod, setInitBuyerMethod] = useState<PaymentMethod>('Cash');
  const [initBuyerNotes, setInitBuyerNotes] = useState('');

  // Attachments, Drag-and-Drop Compression & Webcam
  const [activeDealId, setActiveDealId] = useState<number | null>(deal?.id ?? null);
  const [attachments, setAttachments] = useState<DealAttachment[]>([]);
  const [docCategory, setDocCategory] = useState<AttachmentCategory>('CNIC_FRONT');
  const [docLabel, setDocLabel] = useState('');
  const [webcamOpen, setWebcamOpen] = useState(false);
  const [draggingFiles, setDraggingFiles] = useState(false);
  const [uploadingFiles, setUploadingFiles] = useState(false);
  const [uploadStatusMsg, setUploadStatusMsg] = useState('');
  const multiFileRef = useRef<HTMLInputElement>(null);
  const mobileCamRef = useRef<HTMLInputElement>(null);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!activeDealId || !window.api) return;
    void window.api.listAttachments(activeDealId).then(setAttachments);
  }, [activeDealId]);

  // Party Directory for autocomplete
  const parties = useMemo(() => buildPartyDirectory(deals), [deals]);

  // Duplicate Registration / Chassis / Engine detection (non-blocking)
  const duplicateMatches = useMemo(() => {
    const normReg = normalizeReg(regNumber);
    const normChassis = normalizeReg(chassisNumber);
    const normEngine = normalizeReg(engineNumber);
    if (!normReg && !normChassis && !normEngine) return [];

    const selfId = activeDealId ?? deal?.id ?? -1;
    const matches: { deal: DealWithTotals; reasons: string[] }[] = [];

    for (const d of deals) {
      if (d.id === selfId) continue;
      const reasons: string[] = [];
      if (normReg && normReg.length >= 3 && normalizeReg(d.registration_number) === normReg) {
        reasons.push(`Reg # ${d.registration_number}`);
      }
      if (normChassis && normChassis.length >= 5 && normalizeReg(d.chassis_number) === normChassis) {
        reasons.push(`Chassis # ${d.chassis_number}`);
      }
      if (normEngine && normEngine.length >= 5 && normalizeReg(d.engine_number) === normEngine) {
        reasons.push(`Engine # ${d.engine_number}`);
      }
      if (reasons.length > 0) {
        matches.push({ deal: d, reasons });
      }
    }
    return matches;
  }, [deals, regNumber, chassisNumber, engineNumber, activeDealId, deal?.id]);

  function handleSellerNameChange(val: string) {
    setSellerName(val);
    const found = parties.find((p) => p.name.toLowerCase() === val.trim().toLowerCase());
    if (found) {
      if (!sellerFatherName && found.father_name) setSellerFatherName(found.father_name);
      if (!sellerContact && found.contact) setSellerContact(formatPhone(found.contact));
      if (!sellerCnic && found.cnic) setSellerCnic(formatCnic(found.cnic));
      if (!sellerAddress && found.address) setSellerAddress(found.address);
    }
  }

  function handlePurchaserNameChange(val: string) {
    setPurchaserName(val);
    const found = parties.find((p) => p.name.toLowerCase() === val.trim().toLowerCase());
    if (found) {
      if (!purchaserFatherName && found.father_name) setPurchaserFatherName(found.father_name);
      if (!purchaserContact && found.contact) setPurchaserContact(formatPhone(found.contact));
      if (!purchaserCnic && found.cnic) setPurchaserCnic(formatCnic(found.cnic));
      if (!purchaserAddress && found.address) setPurchaserAddress(found.address);
    }
  }

  function toggleChecklist(key: ChecklistKey) {
    setChecklist((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  const checkedCount = useMemo(
    () => CHECKLIST_ITEMS.filter((i) => Boolean(checklist[i.key])).length,
    [checklist],
  );

  function buildPayload(): {
    input: NewDealInput;
    sale: SaleInput | null;
    initialPayments: {
      sellerPayment?: InitialPaymentInput | null;
      buyerPayment?: InitialPaymentInput | null;
    } | null;
  } {
    const input: NewDealInput = {
      make,
      model,
      variant,
      year: year || null,
      color,
      horse_power: horsePower,
      registration_number: regNumber,
      chassis_number: chassisNumber,
      engine_number: engineNumber,
      mileage: mileage || null,
      bought_from_location: boughtFrom,
      purchase_date: purchaseDate || null,
      purchase_price: parseNum(purchasePrice),
      seller_name: sellerName,
      seller_father_name: sellerFatherName,
      seller_contact: sellerContact,
      seller_cnic: sellerCnic,
      seller_address: sellerAddress,
      seller_due_date: sellerDueDate || null,
      token_tax_paid_till: tokenTaxPaidTill || null,
      checklist_json: JSON.stringify(checklist),
      notes,
    };

    const sale: SaleInput | null =
      !isEdit && alreadySold
        ? {
            sale_date: saleDate || null,
            sale_price: parseNum(salePrice),
            purchaser_name: purchaserName,
            purchaser_father_name: purchaserFatherName,
            purchaser_contact: purchaserContact,
            purchaser_cnic: purchaserCnic,
            purchaser_address: purchaserAddress,
            buyer_due_date: buyerDueDate || null,
          }
        : null;

    const sAmt = parseNum(initSellerAmount);
    const bAmt = parseNum(initBuyerAmount);

    const sellerPayment: InitialPaymentInput | null =
      !activeDealId && canManagePayments && sAmt !== null && sAmt > 0
        ? {
            amount: sAmt,
            payment_type: initSellerType,
            method: initSellerMethod,
            date: purchaseDate || todayISO(),
            notes: initSellerNotes.trim() || 'Initial payment on purchase',
          }
        : null;

    const buyerPayment: InitialPaymentInput | null =
      !activeDealId && alreadySold && canManagePayments && bAmt !== null && bAmt > 0
        ? {
            amount: bAmt,
            payment_type: initBuyerType,
            method: initBuyerMethod,
            date: saleDate || todayISO(),
            notes: initBuyerNotes.trim() || 'Initial payment on sale',
          }
        : null;

    const initialPayments =
      sellerPayment || buyerPayment ? { sellerPayment, buyerPayment } : null;

    return { input, sale, initialPayments };
  }

  async function ensureDealSaved(): Promise<number | null> {
    if (!window.api) return null;
    if (activeDealId) return activeDealId;
    const { input, sale, initialPayments } = buildPayload();
    const created = await window.api.createDeal(input, sale, initialPayments);
    setActiveDealId(created.id);
    return created.id;
  }

  async function processIncomingFiles(fileList: FileList | File[]) {
    if (!window.api) return;
    const files = Array.from(fileList);
    if (files.length === 0) return;
    setUploadingFiles(true);
    setUploadStatusMsg('');
    setError('');
    try {
      const targetId = await ensureDealSaved();
      if (!targetId) return;
      const baseLabel = docLabel.trim() || ATTACHMENT_CATEGORY_LABELS[docCategory];
      let savedCount = 0;
      let savedBytes = 0;

      for (const f of files) {
        const prepared = await prepareAttachmentFile(f);
        savedBytes += Math.max(0, prepared.originalBytes - prepared.finalBytes);
        await window.api.saveAttachmentData(
          targetId,
          docCategory,
          files.length > 1 ? `${baseLabel} (${savedCount + 1})` : baseLabel,
          prepared.fileName,
          prepared.dataUrl,
        );
        savedCount++;
      }
      setDocLabel('');
      const list = await window.api.listAttachments(targetId);
      setAttachments(list);
      const savedKb = Math.round(savedBytes / 1024);
      setUploadStatusMsg(
        `Added ${savedCount} file${savedCount === 1 ? '' : 's'}${savedKb > 5 ? ` · Compressed ${savedKb.toLocaleString()} KB` : ''}`,
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setUploadingFiles(false);
      setDraggingFiles(false);
    }
  }

  async function handleAttachFile() {
    if (!window.api) return;
    if (window.api.isElectron) {
      setError('');
      try {
        const targetId = await ensureDealSaved();
        if (!targetId) return;
        const labelText = docLabel.trim() || ATTACHMENT_CATEGORY_LABELS[docCategory];
        const added = await window.api.pickAndSaveAttachment(targetId, docCategory, labelText);
        if (added) {
          setDocLabel('');
          const list = await window.api.listAttachments(targetId);
          setAttachments(list);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      }
    } else {
      multiFileRef.current?.click();
    }
  }

  async function handleOpenWebcam() {
    setError('');
    try {
      const targetId = await ensureDealSaved();
      if (!targetId) return;
      setWebcamOpen(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  async function handleDeleteAttachment(attId: number) {
    if (!window.api || !activeDealId) return;
    await window.api.deleteAttachment(attId);
    const list = await window.api.listAttachments(activeDealId);
    setAttachments(list);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!window.api || saving) return;
    setSaving(true);
    setError('');
    try {
      const { input, sale, initialPayments } = buildPayload();
      let saved: DealWithTotals;
      if (activeDealId) {
        saved = await window.api.updateDeal(activeDealId, input);
        if (!isEdit && alreadySold && sale) {
          saved = await window.api.markSold(activeDealId, sale, initialPayments?.buyerPayment ?? null);
        }
      } else {
        saved = await window.api.createDeal(input, sale, initialPayments);
      }
      const carLabel = [saved.year, saved.make, saved.model].filter(Boolean).join(' ') || `Car #${saved.id}`;
      onSaved(isEdit ? `Updated ${carLabel}` : `Added ${carLabel}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  }

  const purchaseNumeric = parseNum(purchasePrice);
  const saleNumeric = parseNum(salePrice);

  return (
    <>
      <Modal
        title={isEdit ? 'Edit Car Deal' : 'Add New Car Deal'}
        subtitle="Enter vehicle specifications, seller details, initial payment, checklist, and CNIC / registration documents"
        onClose={onClose}
        width="max-w-3xl"
        footer={
          <>
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" form="deal-form" className="btn btn-primary" disabled={saving}>
              {saving ? 'Saving…' : isEdit || activeDealId ? 'Save Changes' : 'Save Car Deal'}
            </button>
          </>
        }
      >
        <form id="deal-form" onSubmit={(e) => void handleSubmit(e)} className="space-y-5">
          {error && (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-xs font-semibold text-red-700">
              {error}
            </div>
          )}

          {/* Duplicate Vehicle Warning */}
          {duplicateMatches.length > 0 && (
            <div className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-xs text-amber-900">
              <div className="font-bold">Possible duplicate vehicle detected</div>
              <p className="mt-0.5 text-amber-800">
                An existing record matches the identifiers below (you can still save if this is a buyback/trade-in):
              </p>
              <div className="mt-2 space-y-1.5">
                {duplicateMatches.map(({ deal: m, reasons }) => (
                  <div key={m.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-200 bg-white px-3 py-1.5">
                    <div>
                      <span className="font-bold">{carTitle(m)}</span> ({regOf(m)}) ·{' '}
                      <span className="font-semibold text-amber-800">{m.status}</span> · Matched:{' '}
                      <span className="font-mono">{reasons.join(', ')}</span>
                    </div>
                    {onInspectExisting && (
                      <button
                        type="button"
                        onClick={() => onInspectExisting(m)}
                        className="rounded border border-amber-300 bg-amber-50 px-2 py-0.5 font-semibold text-amber-900 hover:bg-amber-100"
                      >
                        Inspect Deal #{m.id}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 1. Vehicle Details */}
          <div>
            <h3 className="mb-2.5 text-xs font-extrabold uppercase tracking-wider text-slate-500">
              1. Vehicle Details
            </h3>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Make</label>
                <input
                  type="text"
                  className="input text-xs"
                  placeholder="e.g. Toyota, Honda, Suzuki"
                  value={make}
                  onChange={(e) => setMake(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Model</label>
                <input
                  type="text"
                  className="input text-xs"
                  placeholder="e.g. Corolla, Civic, Alto"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Variant / Grade</label>
                <input
                  type="text"
                  className="input text-xs"
                  placeholder="e.g. GLi 1.3, VXR, Oriel"
                  value={variant}
                  onChange={(e) => setVariant(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Model Year</label>
                <input
                  type="number"
                  className="input text-xs"
                  placeholder="e.g. 2021"
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Color</label>
                <input
                  type="text"
                  className="input text-xs"
                  placeholder="e.g. White, Silver, Black"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Engine Capacity (CC)</label>
                <input
                  type="text"
                  className="input text-xs"
                  placeholder="e.g. 1300 CC"
                  value={horsePower}
                  onChange={(e) => setHorsePower(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Registration #</label>
                <input
                  type="text"
                  className="input font-mono text-xs uppercase"
                  placeholder="e.g. BXK-482"
                  value={regNumber}
                  onChange={(e) => setRegNumber(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Chassis #</label>
                <input
                  type="text"
                  className="input font-mono text-xs uppercase"
                  placeholder="Chassis number"
                  value={chassisNumber}
                  onChange={(e) => setChassisNumber(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Engine #</label>
                <input
                  type="text"
                  className="input font-mono text-xs uppercase"
                  placeholder="Engine number"
                  value={engineNumber}
                  onChange={(e) => setEngineNumber(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Mileage (km)</label>
                <input
                  type="number"
                  className="input text-xs"
                  placeholder="e.g. 54000"
                  value={mileage}
                  onChange={(e) => setMileage(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Bought From (City/Showroom)</label>
                <input
                  type="text"
                  className="input text-xs"
                  placeholder="e.g. Karachi, Lahore"
                  value={boughtFrom}
                  onChange={(e) => setBoughtFrom(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Token Tax Paid Till</label>
                <input
                  type="text"
                  className="input text-xs"
                  placeholder="e.g. Jun 2027 or Lifetime"
                  value={tokenTaxPaidTill}
                  onChange={(e) => setTokenTaxPaidTill(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* 2. Purchase & Seller Information */}
          <div className="border-t border-slate-200 pt-4">
            <h3 className="mb-2.5 text-xs font-extrabold uppercase tracking-wider text-slate-500">
              2. Purchase &amp; Seller Information
            </h3>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Purchase Date</label>
                <input
                  type="date"
                  className="input text-xs"
                  value={purchaseDate}
                  onChange={(e) => setPurchaseDate(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Purchase Price (PKR)</label>
                <MoneyInput value={purchasePrice} onChange={setPurchasePrice} placeholder="3,450,000" className="input text-xs tabular-nums" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Seller Balance Due Date</label>
                <input
                  type="date"
                  className="input text-xs"
                  value={sellerDueDate}
                  onChange={(e) => setSellerDueDate(e.target.value)}
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Seller Full Name</label>
                <input
                  type="text"
                  list="saved-parties-list"
                  className="input text-xs"
                  placeholder="Type name or pick saved party"
                  value={sellerName}
                  onChange={(e) => handleSellerNameChange(e.target.value)}
                />
                <datalist id="saved-parties-list">
                  {parties.map((p) => (
                    <option key={`${p.name}-${p.cnic || p.contact}`} value={p.name}>
                      {[p.contact, p.cnic, p.roles.join('/')].filter(Boolean).join(' · ')}
                    </option>
                  ))}
                </datalist>
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Seller S/O (Father Name)</label>
                <input
                  type="text"
                  className="input text-xs"
                  placeholder="Father's name"
                  value={sellerFatherName}
                  onChange={(e) => setSellerFatherName(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Seller Contact #</label>
                <input
                  type="text"
                  inputMode="tel"
                  className="input text-xs"
                  placeholder="03XX-XXXXXXX"
                  value={sellerContact}
                  onChange={(e) => setSellerContact(formatPhone(e.target.value))}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">Seller CNIC #</label>
                <input
                  type="text"
                  inputMode="numeric"
                  className="input font-mono text-xs"
                  placeholder="42101-XXXXXXX-X"
                  value={sellerCnic}
                  onChange={(e) => setSellerCnic(formatCnic(e.target.value))}
                />
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1 block text-xs font-semibold text-slate-700">Seller Address</label>
                <input
                  type="text"
                  className="input text-xs"
                  placeholder="Complete residential address"
                  value={sellerAddress}
                  onChange={(e) => setSellerAddress(e.target.value)}
                />
              </div>

              {/* Initial Seller Payment on Purchase (create mode) */}
              {!activeDealId && canManagePayments && (
                <div className="rounded-xl border border-indigo-200 bg-indigo-50/40 p-3 sm:col-span-3">
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-800">
                      Initial Payment Paid to Seller Today (Optional)
                    </span>
                    {purchaseNumeric !== null && purchaseNumeric > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setInitSellerAmount(moneyToInput(purchaseNumeric));
                          setInitSellerType('Final Balance');
                        }}
                        className="text-[11px] font-semibold text-brand-700 hover:underline"
                      >
                        Paid Full Purchase Price
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-4">
                    <div>
                      <MoneyInput
                        value={initSellerAmount}
                        onChange={setInitSellerAmount}
                        placeholder="Amount (Rs)"
                        className="input text-xs tabular-nums"
                      />
                    </div>
                    <div>
                      <select
                        className="input text-xs"
                        value={initSellerType}
                        onChange={(e) => setInitSellerType(e.target.value as PaymentType)}
                      >
                        {PAYMENT_TYPES.map((t) => (
                          <option key={t}>{t}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <select
                        className="input text-xs"
                        value={initSellerMethod}
                        onChange={(e) => setInitSellerMethod(e.target.value as PaymentMethod)}
                      >
                        {PAYMENT_METHODS.map((m) => (
                          <option key={m}>{m}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <input
                        type="text"
                        className="input text-xs"
                        placeholder="Notes / bank ref"
                        value={initSellerNotes}
                        onChange={(e) => setInitSellerNotes(e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="sm:col-span-3">
                <label className="mb-1 block text-xs font-semibold text-slate-700">Deal Notes</label>
                <textarea
                  rows={2}
                  className="input text-xs"
                  placeholder="Condition notes, token details, key count, etc."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* 3. Document & Condition Checklist */}
          <div className="border-t border-slate-200 pt-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500">
                3. Document &amp; Condition Checklist ({checkedCount}/{CHECKLIST_ITEMS.length} Verified)
              </h3>
              <button
                type="button"
                onClick={() => setShowChecklist((v) => !v)}
                className="text-xs font-semibold text-brand-700 hover:underline"
              >
                {showChecklist ? 'Collapse' : 'Expand'}
              </button>
            </div>

            {showChecklist && (
              <div className="mt-2.5 grid grid-cols-1 gap-3 rounded-xl border border-slate-200 bg-slate-50/60 p-3 sm:grid-cols-2">
                <div>
                  <div className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-600">
                    Paperwork &amp; Excise Docs
                  </div>
                  <div className="space-y-1.5">
                    {CHECKLIST_ITEMS.filter((i) => i.group === 'DOCS').map((item) => (
                      <label key={item.key} className="flex cursor-pointer items-center gap-2 text-xs text-slate-800">
                        <input
                          type="checkbox"
                          className="h-3.5 w-3.5 rounded border-slate-300 text-brand-600"
                          checked={Boolean(checklist[item.key])}
                          onChange={() => toggleChecklist(item.key)}
                        />
                        <span>{item.label}</span>
                        {item.critical && !checklist[item.key] && (
                          <span className="rounded bg-amber-100 px-1 py-px text-[9px] font-bold text-amber-800">
                            KEY
                          </span>
                        )}
                      </label>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-600">
                    Vehicle Condition Check
                  </div>
                  <div className="space-y-1.5">
                    {CHECKLIST_ITEMS.filter((i) => i.group === 'COND').map((item) => (
                      <label key={item.key} className="flex cursor-pointer items-center gap-2 text-xs text-slate-800">
                        <input
                          type="checkbox"
                          className="h-3.5 w-3.5 rounded border-slate-300 text-brand-600"
                          checked={Boolean(checklist[item.key])}
                          onChange={() => toggleChecklist(item.key)}
                        />
                        <span>{item.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 4. Attach Documents & Webcam Capture */}
          <div className="border-t border-slate-200 pt-4">
            <div className="mb-2.5 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500">
                4. Attach Documents &amp; Photos ({attachments.length})
              </h3>
              {!activeDealId && (
                <span className="text-[11px] text-slate-400">
                  Attaching or capturing will automatically create the deal draft first
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <select
                className="input text-xs"
                value={docCategory}
                onChange={(e) => setDocCategory(e.target.value as AttachmentCategory)}
              >
                {(Object.keys(ATTACHMENT_CATEGORY_LABELS) as AttachmentCategory[]).map((cat) => (
                  <option key={cat} value={cat}>
                    {ATTACHMENT_CATEGORY_LABELS[cat]}
                  </option>
                ))}
              </select>
              <input
                type="text"
                className="input text-xs"
                placeholder="Label (optional, e.g. Seller CNIC Front)"
                value={docLabel}
                onChange={(e) => setDocLabel(e.target.value)}
              />
            </div>

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDraggingFiles(true);
              }}
              onDragLeave={() => setDraggingFiles(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDraggingFiles(false);
                if (e.dataTransfer.files.length > 0) {
                  void processIncomingFiles(e.dataTransfer.files);
                }
              }}
              className={`mt-3 rounded-xl border-2 border-dashed p-3 transition ${
                draggingFiles
                  ? 'border-brand-500 bg-brand-50'
                  : 'border-slate-300 bg-slate-50/70'
              }`}
            >
              <input
                ref={multiFileRef}
                type="file"
                multiple
                accept="image/*,application/pdf"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.length) void processIncomingFiles(e.target.files);
                  e.target.value = '';
                }}
              />
              <input
                ref={mobileCamRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.length) void processIncomingFiles(e.target.files);
                  e.target.value = '';
                }}
              />
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs text-slate-600">
                  <strong>Drag &amp; drop multiple photos/PDFs</strong> here — phone photos auto-compress to keep backups small.
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    disabled={uploadingFiles}
                    className="btn btn-secondary btn-sm text-xs"
                    onClick={() => multiFileRef.current?.click()}
                  >
                    {uploadingFiles ? 'Compressing…' : 'Upload Multiple / PDF'}
                  </button>
                  <button
                    type="button"
                    disabled={uploadingFiles}
                    className="btn btn-secondary btn-sm text-xs sm:hidden"
                    onClick={() => mobileCamRef.current?.click()}
                  >
                    Camera
                  </button>
                  {window.api?.isElectron && (
                    <button
                      type="button"
                      className="btn btn-secondary btn-sm text-xs"
                      onClick={() => void handleAttachFile()}
                    >
                      Browse Disk
                    </button>
                  )}
                  <button
                    type="button"
                    className="btn btn-primary btn-sm text-xs"
                    onClick={() => void handleOpenWebcam()}
                  >
                    Webcam
                  </button>
                </div>
              </div>
              {uploadStatusMsg && (
                <div className="mt-2 text-[11px] font-semibold text-emerald-700">{uploadStatusMsg}</div>
              )}
            </div>

            {attachments.length > 0 && (
              <div className="mt-3 space-y-1.5">
                {attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs"
                  >
                    <span className="truncate font-semibold text-slate-700">
                      {att.label} <span className="font-normal text-slate-400">({att.file_name})</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => void handleDeleteAttachment(att.id)}
                      className="ml-2 text-slate-400 hover:text-red-600"
                      title="Remove attachment"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 5. Optional Immediate Sale Section (for new entries) */}
          {!isEdit && (
            <div className="border-t border-slate-200 pt-4">
              <label className="flex cursor-pointer items-center gap-2 text-xs font-bold text-slate-700">
                <input
                  type="checkbox"
                  checked={alreadySold}
                  onChange={(e) => setAlreadySold(e.target.checked)}
                />
                This car is already sold (enter purchaser details now)
              </label>

              {alreadySold && (
                <div className="mt-3 grid grid-cols-1 gap-3 rounded-xl border border-emerald-200 bg-emerald-50/40 p-3.5 sm:grid-cols-3">
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Sale Date</label>
                    <input
                      type="date"
                      className="input text-xs"
                      value={saleDate}
                      onChange={(e) => setSaleDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Sale Price (PKR)</label>
                    <MoneyInput value={salePrice} onChange={setSalePrice} placeholder="3,650,000" className="input text-xs tabular-nums" />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Buyer Balance Due Date</label>
                    <input
                      type="date"
                      className="input text-xs"
                      value={buyerDueDate}
                      onChange={(e) => setBuyerDueDate(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Purchaser Name</label>
                    <input
                      type="text"
                      list="saved-parties-list"
                      className="input text-xs"
                      value={purchaserName}
                      onChange={(e) => handlePurchaserNameChange(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Purchaser S/O</label>
                    <input
                      type="text"
                      className="input text-xs"
                      value={purchaserFatherName}
                      onChange={(e) => setPurchaserFatherName(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Purchaser Contact</label>
                    <input
                      type="text"
                      inputMode="tel"
                      className="input text-xs"
                      value={purchaserContact}
                      onChange={(e) => setPurchaserContact(formatPhone(e.target.value))}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Purchaser CNIC</label>
                    <input
                      type="text"
                      inputMode="numeric"
                      className="input font-mono text-xs"
                      value={purchaserCnic}
                      onChange={(e) => setPurchaserCnic(formatCnic(e.target.value))}
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Purchaser Address</label>
                    <input
                      type="text"
                      className="input text-xs"
                      value={purchaserAddress}
                      onChange={(e) => setPurchaserAddress(e.target.value)}
                    />
                  </div>

                  {!activeDealId && canManagePayments && (
                    <div className="rounded-lg border border-emerald-200 bg-white/80 p-3 sm:col-span-3">
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
                          Initial Payment Received from Buyer Today (Optional)
                        </span>
                        {saleNumeric !== null && saleNumeric > 0 && (
                          <button
                            type="button"
                            onClick={() => {
                              setInitBuyerAmount(moneyToInput(saleNumeric));
                              setInitBuyerType('Final Balance');
                            }}
                            className="text-[11px] font-semibold text-emerald-700 hover:underline"
                          >
                            Received Full Sale Price
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-4">
                        <MoneyInput
                          value={initBuyerAmount}
                          onChange={setInitBuyerAmount}
                          placeholder="Amount (Rs)"
                          className="input text-xs tabular-nums"
                        />
                        <select
                          className="input text-xs"
                          value={initBuyerType}
                          onChange={(e) => setInitBuyerType(e.target.value as PaymentType)}
                        >
                          {PAYMENT_TYPES.map((t) => (
                            <option key={t}>{t}</option>
                          ))}
                        </select>
                        <select
                          className="input text-xs"
                          value={initBuyerMethod}
                          onChange={(e) => setInitBuyerMethod(e.target.value as PaymentMethod)}
                        >
                          {PAYMENT_METHODS.map((m) => (
                            <option key={m}>{m}</option>
                          ))}
                        </select>
                        <input
                          type="text"
                          className="input text-xs"
                          placeholder="Notes / ref"
                          value={initBuyerNotes}
                          onChange={(e) => setInitBuyerNotes(e.target.value)}
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </form>
      </Modal>

      {/* Webcam Capture Modal rendered outside DealFormModal backdrop */}
      {webcamOpen && activeDealId && (
        <WebcamCaptureModal
          dealId={activeDealId}
          defaultCategory={docCategory}
          defaultLabel={docLabel}
          onClose={() => setWebcamOpen(false)}
          onSaved={async () => {
            setWebcamOpen(false);
            setDocLabel('');
            if (window.api && activeDealId) {
              const list = await window.api.listAttachments(activeDealId);
              setAttachments(list);
            }
          }}
        />
      )}
    </>
  );
}