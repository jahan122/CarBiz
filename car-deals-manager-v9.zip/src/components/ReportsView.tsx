import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  EXPENSE_CATEGORIES,
  PAYMENT_METHODS,
  type ChequeStatus,
  type DealWithTotals,
  type Expense,
  type ExpenseCategory,
  type Payment,
  type PaymentMethod,
} from '../types';
import {
  carTitle,
  daysInStock,
  fmtDate,
  fmtMoney,
  netProfit,
  regOf,
  sellerBalanceDue,
  sellerOverpaid,
  totalCost,
} from '../utils';

interface Props {
  deals: DealWithTotals[];
  onInspectDealById?: (dealId: number) => void;
  onDataChanged?: () => void;
}

interface MonthRow {
  monthKey: string;
  label: string;
  soldCount: number;
  revenue: number;
  cost: number;
  transferCost: number;
  profit: number;
}

interface MakeRow {
  make: string;
  soldCount: number;
  activeCount: number;
  revenue: number;
  profit: number;
}

function formatMonthLabel(ym: string): string {
  if (ym === 'Unknown') return 'Date Not Recorded';
  const [y, m] = ym.split('-').map(Number);
  if (!y || !m) return ym;
  return new Date(y, m - 1, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

export default function ReportsView({ deals, onInspectDealById, onDataChanged }: Props) {
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [chequeFilter, setChequeFilter] = useState<'ATTENTION' | 'ALL'>('ATTENTION');
  const [updatingChequeId, setUpdatingChequeId] = useState<number | null>(null);

  const loadLedgerData = useCallback(async () => {
    if (!window.api) return;
    const [exps, pays] = await Promise.all([window.api.listAllExpenses(), window.api.listAllPayments()]);
    setExpenses(exps);
    setPayments(pays);
  }, []);

  useEffect(() => {
    void loadLedgerData();
  }, [loadLedgerData, deals]);

  const dealMap = useMemo(() => new Map(deals.map((d) => [d.id, d])), [deals]);
  const unsoldDeals = useMemo(() => deals.filter((d) => d.status !== 'SOLD'), [deals]);
  const reservedDeals = useMemo(() => deals.filter((d) => d.status === 'RESERVED'), [deals]);
  const allSoldDeals = useMemo(() => deals.filter((d) => d.status === 'SOLD'), [deals]);

  // All-time profit across every sold deal with known purchase + sale price
  const allTimeStats = useMemo(() => {
    let profit = 0;
    let totalTransferSpend = 0;
    let counted = 0;
    for (const d of deals) {
      totalTransferSpend += d.transfer_cost ?? 0;
    }
    for (const d of allSoldDeals) {
      const p = netProfit(d);
      if (p !== null) {
        profit += p;
        counted++;
      }
    }
    return { profit, totalTransferSpend, counted, totalSold: allSoldDeals.length };
  }, [deals, allSoldDeals]);

  // Money currently tied up in unsold cars (both ACTIVE and RESERVED)
  const inventoryStats = useMemo(() => {
    let purchaseCapital = 0;
    let prepExpenses = 0;
    let transferExpenses = 0;
    let balanceOwedToSellers = 0;
    let tokenHeld = 0;
    let agingOver30 = 0;

    for (const d of unsoldDeals) {
      purchaseCapital += d.purchase_price ?? 0;
      prepExpenses += d.total_expenses;
      transferExpenses += d.transfer_cost ?? 0;
      if (d.status === 'RESERVED') tokenHeld += d.received_from_buyer ?? 0;
      balanceOwedToSellers += sellerBalanceDue(d) ?? 0;
      const age = daysInStock(d);
      if (age !== null && age >= 30) agingOver30++;
    }
    const totalTiedUp = purchaseCapital + prepExpenses + transferExpenses;
    const netCashOutlaid = Math.max(0, totalTiedUp - balanceOwedToSellers);
    return {
      totalTiedUp,
      purchaseCapital,
      prepExpenses,
      transferExpenses,
      balanceOwedToSellers,
      netCashOutlaid,
      tokenHeld,
      agingOver30,
    };
  }, [unsoldDeals]);

  // Filtered sold deals (based on sale_date)
  const filteredSold = useMemo(() => {
    return allSoldDeals.filter((d) => {
      if (!fromDate && !toDate) return true;
      const dt = d.sale_date ?? '';
      if (!dt) return false;
      if (fromDate && dt < fromDate) return false;
      if (toDate && dt > toDate) return false;
      return true;
    });
  }, [allSoldDeals, fromDate, toDate]);

  // Filtered expenses & payments for date range analytics
  const filteredExpenses = useMemo(() => {
    return expenses.filter((e) => {
      if (!fromDate && !toDate) return true;
      if (!e.date) return false;
      if (fromDate && e.date < fromDate) return false;
      if (toDate && e.date > toDate) return false;
      return true;
    });
  }, [expenses, fromDate, toDate]);

  const filteredPayments = useMemo(() => {
    return payments.filter((p) => {
      if (!fromDate && !toDate) return true;
      if (!p.date) return false;
      if (fromDate && p.date < fromDate) return false;
      if (toDate && p.date > toDate) return false;
      return true;
    });
  }, [payments, fromDate, toDate]);

  const filteredSummary = useMemo(() => {
    let revenue = 0;
    let cost = 0;
    let countedRevenue = 0;
    let countedCost = 0;
    let profit = 0;
    let profitableCount = 0;
    let daysSum = 0;
    let daysCount = 0;
    let weightedCapitalDays = 0;

    for (const d of filteredSold) {
      revenue += d.sale_price ?? 0;
      cost += totalCost(d);
      const p = netProfit(d);
      const days = daysInStock(d);
      if (days !== null) {
        daysSum += days;
        daysCount++;
      }
      if (p !== null) {
        profit += p;
        profitableCount++;
        const c = totalCost(d);
        countedRevenue += d.sale_price ?? 0;
        countedCost += c;
        if (days !== null && c > 0) {
          weightedCapitalDays += c * Math.max(1, days);
        }
      }
    }

    const avgProfit = profitableCount > 0 ? profit / profitableCount : 0;
    const avgDaysToSell = daysCount > 0 ? Math.round(daysSum / daysCount) : null;
    const marginPct = countedRevenue > 0 ? (profit / countedRevenue) * 100 : null;
    const simpleRoiPct = countedCost > 0 ? (profit / countedCost) * 100 : null;
    const monthlyRoiPct = weightedCapitalDays > 0 ? (profit / (weightedCapitalDays / 30)) * 100 : null;

    return {
      revenue,
      cost,
      profit,
      profitableCount,
      avgProfit,
      avgDaysToSell,
      marginPct,
      simpleRoiPct,
      monthlyRoiPct,
    };
  }, [filteredSold]);

  // Expense Category Breakdown
  const expenseByCategory = useMemo(() => {
    const map = new Map<ExpenseCategory, { category: ExpenseCategory; total: number; count: number }>();
    for (const c of EXPENSE_CATEGORIES) {
      map.set(c, { category: c, total: 0, count: 0 });
    }
    let grandTotal = 0;
    for (const e of filteredExpenses) {
      const cat = EXPENSE_CATEGORIES.includes(e.category) ? e.category : 'Other';
      const entry = map.get(cat)!;
      entry.total += e.amount;
      entry.count += 1;
      grandTotal += e.amount;
    }
    const rows = Array.from(map.values()).sort((a, b) => b.total - a.total);
    return { rows, grandTotal };
  }, [filteredExpenses]);

  // Cashflow by Payment Method
  const cashflowByMethod = useMemo(() => {
    const map = new Map<PaymentMethod, { method: PaymentMethod; inflow: number; outflow: number; count: number }>();
    for (const m of PAYMENT_METHODS) {
      map.set(m, { method: m, inflow: 0, outflow: 0, count: 0 });
    }
    let totalIn = 0;
    let totalOut = 0;
    for (const p of filteredPayments) {
      const m = PAYMENT_METHODS.includes(p.method) ? p.method : 'Other';
      const entry = map.get(m)!;
      if (p.direction === 'IN_FROM_BUYER') {
        entry.inflow += p.amount;
        totalIn += p.amount;
      } else {
        entry.outflow += p.amount;
        totalOut += p.amount;
      }
      entry.count += 1;
    }
    const rows = Array.from(map.values()).filter((r) => r.count > 0 || r.method === 'Cash' || r.method === 'Bank Transfer' || r.method === 'Cheque');
    return { rows, totalIn, totalOut };
  }, [filteredPayments]);

  // Cheque Clearance Tracker (across all recorded cheques)
  const chequeRows = useMemo(() => {
    const list = payments
      .filter((p) => p.method === 'Cheque' || Boolean(p.cheque_number))
      .map((p) => ({
        payment: p,
        deal: dealMap.get(p.car_deal_id) ?? null,
        status: (p.cheque_status ?? 'PENDING') as ChequeStatus,
      }));
    list.sort((a, b) => {
      const order = { BOUNCED: 0, PENDING: 1, CLEARED: 2 };
      const diff = order[a.status] - order[b.status];
      if (diff !== 0) return diff;
      return (a.payment.cheque_date ?? a.payment.date).localeCompare(b.payment.cheque_date ?? b.payment.date);
    });
    return list;
  }, [payments, dealMap]);

  const visibleCheques = useMemo(
    () =>
      chequeFilter === 'ATTENTION'
        ? chequeRows.filter((c) => c.status === 'PENDING' || c.status === 'BOUNCED')
        : chequeRows,
    [chequeRows, chequeFilter],
  );

  const attentionChequesCount = useMemo(
    () => chequeRows.filter((c) => c.status === 'PENDING' || c.status === 'BOUNCED').length,
    [chequeRows],
  );

  async function handleUpdateChequeStatus(paymentId: number, status: ChequeStatus) {
    if (!window.api) return;
    setUpdatingChequeId(paymentId);
    try {
      await window.api.updateChequeStatus(paymentId, status);
      await loadLedgerData();
      onDataChanged?.();
    } finally {
      setUpdatingChequeId(null);
    }
  }

  // Profit grouped by month
  const monthlyRows = useMemo<MonthRow[]>(() => {
    const map = new Map<string, MonthRow>();
    for (const d of filteredSold) {
      const key = d.sale_date && d.sale_date.length >= 7 ? d.sale_date.slice(0, 7) : 'Unknown';
      const cur = map.get(key) ?? {
        monthKey: key,
        label: formatMonthLabel(key),
        soldCount: 0,
        revenue: 0,
        cost: 0,
        transferCost: 0,
        profit: 0,
      };
      cur.soldCount += 1;
      cur.revenue += d.sale_price ?? 0;
      cur.cost += totalCost(d);
      cur.transferCost += d.transfer_cost ?? 0;
      const p = netProfit(d);
      if (p !== null) cur.profit += p;
      map.set(key, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.monthKey.localeCompare(a.monthKey));
  }, [filteredSold]);

  // Best-selling makes
  const makeRows = useMemo<MakeRow[]>(() => {
    const map = new Map<string, MakeRow>();
    for (const d of filteredSold) {
      const make = (d.make ?? 'Unspecified').trim() || 'Unspecified';
      const cur = map.get(make) ?? { make, soldCount: 0, activeCount: 0, revenue: 0, profit: 0 };
      cur.soldCount += 1;
      cur.revenue += d.sale_price ?? 0;
      const p = netProfit(d);
      if (p !== null) cur.profit += p;
      map.set(make, cur);
    }
    for (const d of unsoldDeals) {
      const make = (d.make ?? 'Unspecified').trim() || 'Unspecified';
      const cur = map.get(make) ?? { make, soldCount: 0, activeCount: 0, revenue: 0, profit: 0 };
      cur.activeCount += 1;
      map.set(make, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.soldCount - a.soldCount || b.profit - a.profit);
  }, [filteredSold, unsoldDeals]);

  const maxMakeSold = Math.max(1, ...makeRows.map((m) => m.soldCount));

  function setQuickPreset(preset: 'thisMonth' | 'last30' | 'thisYear' | 'all') {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const iso = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    if (preset === 'all') {
      setFromDate('');
      setToDate('');
    } else if (preset === 'thisMonth') {
      setFromDate(`${now.getFullYear()}-${pad(now.getMonth() + 1)}-01`);
      setToDate(iso(now));
    } else if (preset === 'last30') {
      const start = new Date(now);
      start.setDate(start.getDate() - 30);
      setFromDate(iso(start));
      setToDate(iso(now));
    } else if (preset === 'thisYear') {
      setFromDate(`${now.getFullYear()}-01-01`);
      setToDate(iso(now));
    }
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-5 overflow-y-auto pb-4">
      {/* Top KPI Summary Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-ink-200 bg-white p-5 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-wider text-ink-500">All-Time Net Profit</div>
          <div
            className={`mt-2 text-2xl font-bold tabular-nums ${
              allTimeStats.profit >= 0 ? 'text-emerald-700' : 'text-red-700'
            }`}
          >
            {allTimeStats.profit < 0 ? '− ' : '+ '}
            {fmtMoney(Math.abs(allTimeStats.profit))}
          </div>
          <div className="mt-1 text-xs text-ink-500">
            Across {allTimeStats.counted} completed deal{allTimeStats.counted === 1 ? '' : 's'} ({allTimeStats.totalSold} total sold)
          </div>
        </div>

        <div className="rounded-xl border border-ink-200 bg-white p-5 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-wider text-ink-500">Capital Tied Up (Unsold)</div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-brand-700">{fmtMoney(inventoryStats.totalTiedUp)}</div>
          <div className="mt-1 text-xs text-ink-500">
            {unsoldDeals.length} unsold ({reservedDeals.length} reserved) · {inventoryStats.agingOver30} aging 30+d
          </div>
          {inventoryStats.tokenHeld > 0 && (
            <div className="mt-0.5 text-[11px] font-semibold text-indigo-700">
              Tokens Held: {fmtMoney(inventoryStats.tokenHeld)}
            </div>
          )}
        </div>

        <div className="rounded-xl border border-ink-200 bg-white p-5 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-wider text-ink-500">Filtered Period Profit</div>
          <div
            className={`mt-2 text-2xl font-bold tabular-nums ${
              filteredSummary.profit >= 0 ? 'text-emerald-700' : 'text-red-700'
            }`}
          >
            {filteredSummary.profit < 0 ? '− ' : '+ '}
            {fmtMoney(Math.abs(filteredSummary.profit))}
          </div>
          <div className="mt-1 text-xs text-ink-500">
            {filteredSold.length} sold · Avg {fmtMoney(filteredSummary.avgProfit)} / car
          </div>
        </div>

        <div className="rounded-xl border border-ink-200 bg-white p-5 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-wider text-ink-500">Turnaround &amp; ROI</div>
          <div className="mt-2 text-2xl font-bold tabular-nums text-indigo-700">
            {filteredSummary.avgDaysToSell !== null ? `${filteredSummary.avgDaysToSell} days` : '—'}
          </div>
          <div className="mt-1 text-xs text-ink-500">
            Margin:{' '}
            <strong>{filteredSummary.marginPct !== null ? `${filteredSummary.marginPct.toFixed(1)}%` : '—'}</strong>
            {' · '}
            ROI:{' '}
            <strong>{filteredSummary.simpleRoiPct !== null ? `${filteredSummary.simpleRoiPct.toFixed(1)}%` : '—'}</strong>
            {filteredSummary.monthlyRoiPct !== null && <span> ({filteredSummary.monthlyRoiPct.toFixed(1)}%/mo)</span>}
          </div>
        </div>
      </div>

      {/* Date-Range Filter Bar */}
      <div className="flex flex-wrap items-end justify-between gap-4 rounded-xl border border-ink-200 bg-white px-4 py-4 shadow-sm sm:px-5">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="label">From Date</label>
            <input type="date" className="input" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
          </div>
          <div>
            <label className="label">To Date</label>
            <input type="date" className="input" value={toDate} onChange={(e) => setToDate(e.target.value)} />
          </div>
          {(fromDate || toDate) && (
            <button type="button" className="btn btn-secondary" onClick={() => setQuickPreset('all')}>
              Clear Dates
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <span className="mr-1 text-xs font-medium text-ink-500">Quick range:</span>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => setQuickPreset('thisMonth')}>
            This Month
          </button>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => setQuickPreset('last30')}>
            Last 30 Days
          </button>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => setQuickPreset('thisYear')}>
            This Year
          </button>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => setQuickPreset('all')}>
            All Time
          </button>
        </div>
      </div>

      {/* Expense Category Breakdown + Cashflow by Payment Method */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Expense Breakdown by Category */}
        <div className="overflow-hidden rounded-xl border border-ink-200 bg-white shadow-sm lg:col-span-6">
          <div className="flex items-center justify-between border-b border-ink-200 px-5 py-3.5">
            <div>
              <h2 className="text-sm font-bold text-ink-900">Repair &amp; Expense Breakdown</h2>
              <p className="text-xs text-ink-500">Spending by category across {filteredExpenses.length} entries</p>
            </div>
            <span className="text-sm font-bold tabular-nums text-ink-900">
              {fmtMoney(expenseByCategory.grandTotal)}
            </span>
          </div>
          <div className="space-y-3 p-5">
            {expenseByCategory.grandTotal === 0 ? (
              <div className="py-6 text-center text-xs text-ink-500">
                No expenses recorded in the selected period.
              </div>
            ) : (
              expenseByCategory.rows
                .filter((r) => r.total > 0 || r.count > 0)
                .map((row) => {
                  const pct =
                    expenseByCategory.grandTotal > 0 ? (row.total / expenseByCategory.grandTotal) * 100 : 0;
                  return (
                    <div key={row.category}>
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-ink-900">{row.category}</span>
                          <span className="rounded bg-ink-100 px-1.5 py-0.5 text-[10px] font-semibold text-ink-600 tabular-nums">
                            {row.count}
                          </span>
                        </div>
                        <div className="tabular-nums">
                          <span className="font-bold text-ink-900">{fmtMoney(row.total)}</span>
                          <span className="ml-1.5 text-[11px] text-ink-500">({pct.toFixed(1)}%)</span>
                        </div>
                      </div>
                      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-ink-100">
                        <div
                          className="h-full rounded-full bg-amber-500 transition-all"
                          style={{ width: `${Math.max(4, Math.round(pct))}%` }}
                        />
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        </div>

        {/* Cashflow by Payment Method */}
        <div className="overflow-hidden rounded-xl border border-ink-200 bg-white shadow-sm lg:col-span-6">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-200 px-5 py-3.5">
            <div>
              <h2 className="text-sm font-bold text-ink-900">Cashflow by Payment Method</h2>
              <p className="text-xs text-ink-500">Inflows vs. outflows across {filteredPayments.length} payments</p>
            </div>
            <div className="flex items-center gap-3 text-xs tabular-nums">
              <span className="font-semibold text-emerald-700">In: {fmtMoney(cashflowByMethod.totalIn)}</span>
              <span className="font-semibold text-amber-700">Out: {fmtMoney(cashflowByMethod.totalOut)}</span>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-ink-50 text-left text-[11px] font-semibold uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-4 py-2.5">Method</th>
                  <th className="px-4 py-2.5 text-center">Txns</th>
                  <th className="px-4 py-2.5 text-right">In (Buyers)</th>
                  <th className="px-4 py-2.5 text-right">Out (Sellers)</th>
                  <th className="px-4 py-2.5 text-right">Net Flow</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {cashflowByMethod.rows.map((row) => {
                  const net = row.inflow - row.outflow;
                  return (
                    <tr key={row.method} className="hover:bg-ink-50/70">
                      <td className="px-4 py-2.5 font-semibold text-ink-900">{row.method}</td>
                      <td className="px-4 py-2.5 text-center tabular-nums text-ink-600">{row.count}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums text-emerald-700">
                        {row.inflow > 0 ? fmtMoney(row.inflow) : '—'}
                      </td>
                      <td className="px-4 py-2.5 text-right tabular-nums text-amber-700">
                        {row.outflow > 0 ? fmtMoney(row.outflow) : '—'}
                      </td>
                      <td
                        className={`px-4 py-2.5 text-right font-bold tabular-nums ${
                          net >= 0 ? 'text-emerald-700' : 'text-red-700'
                        }`}
                      >
                        {net === 0 ? '—' : `${net < 0 ? '− ' : '+ '}${fmtMoney(Math.abs(net))}`}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Cheque Clearance Tracker */}
      <div className="overflow-hidden rounded-xl border border-ink-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink-200 px-5 py-3.5">
          <div>
            <h2 className="text-sm font-bold text-ink-900">
              Cheque Clearance Tracker ({chequeRows.length})
            </h2>
            <p className="text-xs text-ink-500">
              {attentionChequesCount > 0
                ? `${attentionChequesCount} cheque${attentionChequesCount === 1 ? '' : 's'} pending or bounced`
                : 'All recorded cheques are cleared'}
            </p>
          </div>
          <div className="flex gap-1.5">
            <button
              type="button"
              onClick={() => setChequeFilter('ATTENTION')}
              className={`min-h-[34px] rounded-lg border px-3 py-1 text-xs font-semibold ${
                chequeFilter === 'ATTENTION'
                  ? 'border-brand-600 bg-brand-600 text-white'
                  : 'border-ink-200 bg-ink-50 text-ink-700'
              }`}
            >
              Pending / Bounced ({attentionChequesCount})
            </button>
            <button
              type="button"
              onClick={() => setChequeFilter('ALL')}
              className={`min-h-[34px] rounded-lg border px-3 py-1 text-xs font-semibold ${
                chequeFilter === 'ALL'
                  ? 'border-brand-600 bg-brand-600 text-white'
                  : 'border-ink-200 bg-ink-50 text-ink-700'
              }`}
            >
              All Cheques ({chequeRows.length})
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-ink-50 text-left text-[11px] font-semibold uppercase tracking-wide text-ink-500">
              <tr>
                <th className="px-4 py-2.5">Vehicle</th>
                <th className="px-4 py-2.5">Cheque # &amp; Due Date</th>
                <th className="px-4 py-2.5">Direction</th>
                <th className="px-4 py-2.5 text-right">Amount</th>
                <th className="px-4 py-2.5">Status</th>
                <th className="px-4 py-2.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-100">
              {visibleCheques.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-xs text-ink-500">
                    {chequeRows.length === 0
                      ? 'No cheque payments recorded yet.'
                      : 'No pending or bounced cheques right now.'}
                  </td>
                </tr>
              ) : (
                visibleCheques.map(({ payment: p, deal: d, status }) => (
                  <tr key={p.id} className="hover:bg-ink-50/60">
                    <td className="px-4 py-2.5">
                      {d ? (
                        <button
                          type="button"
                          onClick={() => onInspectDealById?.(d.id)}
                          className="text-left hover:text-brand-700"
                        >
                          <div className="font-semibold text-ink-900">{carTitle(d)}</div>
                          <div className="font-mono text-xs text-ink-500">{regOf(d)}</div>
                        </button>
                      ) : (
                        <span className="text-xs text-ink-400">Deal #{p.car_deal_id}</span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-xs">
                      <div className="font-mono font-bold text-ink-900">
                        {p.cheque_number ? `#${p.cheque_number}` : 'No cheque #'}
                      </div>
                      <div className="text-ink-500">
                        Due: {fmtDate(p.cheque_date ?? p.date)}
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-xs">
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          p.direction === 'IN_FROM_BUYER'
                            ? 'bg-emerald-50 text-emerald-700'
                            : 'bg-blue-50 text-blue-700'
                        }`}
                      >
                        {p.direction === 'IN_FROM_BUYER' ? 'IN ← Buyer' : 'OUT → Seller'}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-right font-bold tabular-nums text-ink-900">
                      {fmtMoney(p.amount)}
                    </td>
                    <td className="px-4 py-2.5">
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${
                          status === 'CLEARED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : status === 'BOUNCED'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {status}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <div className="inline-flex flex-wrap justify-end gap-1">
                        {status !== 'CLEARED' && (
                          <button
                            type="button"
                            disabled={updatingChequeId === p.id}
                            onClick={() => void handleUpdateChequeStatus(p.id, 'CLEARED')}
                            className="btn btn-secondary btn-sm text-emerald-700 hover:bg-emerald-50"
                          >
                            Mark Cleared
                          </button>
                        )}
                        {status !== 'BOUNCED' && (
                          <button
                            type="button"
                            disabled={updatingChequeId === p.id}
                            onClick={() => void handleUpdateChequeStatus(p.id, 'BOUNCED')}
                            className="btn btn-secondary btn-sm text-red-700 hover:bg-red-50"
                          >
                            Mark Bounced
                          </button>
                        )}
                        {status !== 'PENDING' && (
                          <button
                            type="button"
                            disabled={updatingChequeId === p.id}
                            onClick={() => void handleUpdateChequeStatus(p.id, 'PENDING')}
                            className="btn btn-secondary btn-sm"
                          >
                            Reset Pending
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Main Analytics Grid: Profit by Month + Best-Selling Makes */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Profit by Month */}
        <div className="overflow-hidden rounded-xl border border-ink-200 bg-white shadow-sm lg:col-span-7">
          <div className="flex items-center justify-between border-b border-ink-200 px-5 py-3.5">
            <div>
              <h2 className="text-sm font-bold text-ink-900">Profit by Month</h2>
              <p className="text-xs text-ink-500">Grouped by vehicle sale month</p>
            </div>
            <span className="rounded-full bg-ink-100 px-2.5 py-0.5 text-xs font-semibold text-ink-700">
              {monthlyRows.length} month{monthlyRows.length === 1 ? '' : 's'}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-ink-50 text-left text-[11px] font-semibold uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-4 py-2.5">Month</th>
                  <th className="px-4 py-2.5 text-center">Sold</th>
                  <th className="px-4 py-2.5 text-right">Sales</th>
                  <th className="px-4 py-2.5 text-right">Transfer</th>
                  <th className="px-4 py-2.5 text-right">Total Cost</th>
                  <th className="px-4 py-2.5 text-right">Net Profit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {monthlyRows.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-10 text-center text-ink-500">
                      No sold cars in the selected date range.
                    </td>
                  </tr>
                ) : (
                  monthlyRows.map((m) => (
                    <tr key={m.monthKey} className="hover:bg-ink-50/70">
                      <td className="px-4 py-2.5 font-semibold text-ink-900">{m.label}</td>
                      <td className="px-4 py-2.5 text-center tabular-nums text-ink-700">{m.soldCount}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums text-ink-700">{fmtMoney(m.revenue)}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums text-indigo-700">{fmtMoney(m.transferCost)}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums text-ink-700">{fmtMoney(m.cost)}</td>
                      <td
                        className={`px-4 py-2.5 text-right font-bold tabular-nums ${
                          m.profit >= 0 ? 'text-emerald-700' : 'text-red-700'
                        }`}
                      >
                        {m.profit < 0 ? '− ' : '+ '}
                        {fmtMoney(Math.abs(m.profit))}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Best-Selling Makes */}
        <div className="overflow-hidden rounded-xl border border-ink-200 bg-white shadow-sm lg:col-span-5">
          <div className="border-b border-ink-200 px-5 py-3.5">
            <h2 className="text-sm font-bold text-ink-900">Best-Selling Makes</h2>
            <p className="text-xs text-ink-500">Units sold, profit generated &amp; current unsold stock</p>
          </div>
          <div className="divide-y divide-ink-100 p-4">
            {makeRows.length === 0 ? (
              <div className="py-8 text-center text-sm text-ink-500">No vehicle records available yet.</div>
            ) : (
              makeRows.map((row) => {
                const pct = Math.round((row.soldCount / maxMakeSold) * 100);
                return (
                  <div key={row.make} className="py-3 first:pt-0 last:pb-0">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-ink-900">{row.make}</span>
                        <span className="rounded bg-emerald-50 px-1.5 py-0.5 text-xs font-semibold text-emerald-700">
                          {row.soldCount} sold
                        </span>
                        {row.activeCount > 0 && (
                          <span className="rounded bg-amber-50 px-1.5 py-0.5 text-xs font-medium text-amber-700">
                            {row.activeCount} in stock
                          </span>
                        )}
                      </div>
                      <span
                        className={`font-bold tabular-nums ${
                          row.profit >= 0 ? 'text-emerald-700' : 'text-red-700'
                        }`}
                      >
                        {row.soldCount > 0 ? `${row.profit < 0 ? '−' : '+'} ${fmtMoney(Math.abs(row.profit))}` : '—'}
                      </span>
                    </div>
                    <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-ink-100">
                      <div
                        className="h-full rounded-full bg-brand-600 transition-all"
                        style={{ width: `${row.soldCount > 0 ? Math.max(8, pct) : 0}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Unsold Inventory Breakdown */}
      <div className="overflow-hidden rounded-xl border border-ink-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-200 px-5 py-3.5">
          <div>
            <h2 className="text-sm font-bold text-ink-900">Money Tied Up in Unsold Cars ({unsoldDeals.length})</h2>
            <p className="text-xs text-ink-500">Current active &amp; reserved showroom stock, aging &amp; capital breakdown</p>
          </div>
          <div className="text-sm font-bold tabular-nums text-brand-700">Total: {fmtMoney(inventoryStats.totalTiedUp)}</div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-ink-50 text-left text-[11px] font-semibold uppercase tracking-wide text-ink-500">
              <tr>
                <th className="px-4 py-2.5">Car</th>
                <th className="px-4 py-2.5">Reg #</th>
                <th className="px-4 py-2.5">Status</th>
                <th className="px-4 py-2.5">Purchase Date</th>
                <th className="px-4 py-2.5 text-center">Days in Stock</th>
                <th className="px-4 py-2.5 text-right">Purchase Price</th>
                <th className="px-4 py-2.5 text-right">Expenses</th>
                <th className="px-4 py-2.5 text-right">Transfer</th>
                <th className="px-4 py-2.5 text-right">Total Tied Up</th>
                <th className="px-4 py-2.5 text-right">Due to Seller</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-100">
              {unsoldDeals.length === 0 ? (
                <tr>
                  <td colSpan={10} className="px-4 py-8 text-center text-ink-500">
                    No unsold cars currently in stock.
                  </td>
                </tr>
              ) : (
                unsoldDeals.map((d) => {
                  const due = sellerBalanceDue(d);
                  const over = sellerOverpaid(d);
                  const age = daysInStock(d);
                  return (
                    <tr
                      key={d.id}
                      onClick={() => onInspectDealById?.(d.id)}
                      className="cursor-pointer hover:bg-ink-50/70"
                    >
                      <td className="px-4 py-2.5 font-semibold text-ink-900">{carTitle(d)}</td>
                      <td className="px-4 py-2.5 font-mono text-xs text-ink-700">{regOf(d)}</td>
                      <td className="px-4 py-2.5">
                        <span
                          className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${
                            d.status === 'RESERVED' ? 'bg-indigo-50 text-indigo-700' : 'bg-amber-50 text-amber-700'
                          }`}
                        >
                          {d.status === 'RESERVED' ? 'Reserved' : 'Active'}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-ink-600">{fmtDate(d.purchase_date)}</td>
                      <td className="px-4 py-2.5 text-center tabular-nums">
                        {age === null ? (
                          '—'
                        ) : (
                          <span
                            className={`rounded px-2 py-0.5 text-xs font-bold ${
                              age >= 60
                                ? 'bg-red-100 text-red-800'
                                : age >= 30
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-ink-100 text-ink-700'
                            }`}
                          >
                            {age}d
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-2.5 text-right tabular-nums">{fmtMoney(d.purchase_price)}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">{fmtMoney(d.total_expenses)}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums text-indigo-700">{fmtMoney(d.transfer_cost ?? 0)}</td>
                      <td className="px-4 py-2.5 text-right font-bold tabular-nums text-ink-900">{fmtMoney(totalCost(d))}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">
                        {over > 0 ? (
                          <span className="font-semibold text-red-700">Overpaid {fmtMoney(over)}</span>
                        ) : due === null ? (
                          '—'
                        ) : due === 0 ? (
                          <span className="text-emerald-700">Paid</span>
                        ) : (
                          <span className="font-semibold text-amber-700">{fmtMoney(due)}</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}