import { useCallback, useEffect, useState, type DragEvent } from 'react';
import {
  ATTACHMENT_CATEGORY_LABELS,
  CHECKLIST_ITEMS,
  type AppUser,
  type AttachmentCategory,
  type AuditLogEntry,
  type ChecklistKey,
  type DealAttachment,
  type DealChecklist,
  type DealWithTotals,
  type Expense,
  type Payment,
  type TransferStatus,
} from '../types';
import {
  buyerBalanceDue,
  buyerOverpaid,
  carTitle as formatCarTitle,
  checklistSummary,
  daysInStock,
  daysPastDue,
  fmtDate,
  fmtMoney,
  parseChecklist,
  regOf,
  sellerBalanceDue,
  sellerOverpaid,
} from '../utils';
import { prepareAttachmentFile } from '../utils/imageCompress';
import WebcamCaptureModal from './WebcamCaptureModal';

interface Props {
  deal: DealWithTotals;
  allDeals?: DealWithTotals[];
  currentUser?: AppUser | null;
  onClose: () => void;
  onInspectDealById?: (dealId: number) => void;
  onWhatsApp: (deal: DealWithTotals, mode: 'SPECS' | 'RECEIPT') => void;
  onExpense: (deal: DealWithTotals) => void;
  onPayments: (deal: DealWithTotals) => void;
  onReceipt: (deal: DealWithTotals) => void;
  onReserve: (deal: DealWithTotals) => void;
  onSold: (deal: DealWithTotals) => void;
  onEdit: (deal: DealWithTotals) => void;
  onDealChanged: () => void;
  onNotify: (msg: string) => void;
}

const formatPkr = (n: number | null | undefined): string => {
  if (n === null || n === undefined || Number.isNaN(n)) return '—';
  return `Rs. ${Math.round(n).toLocaleString('en-PK')}`;
};

function DueBadge({ dueDate, amountDue }: { dueDate: string | null; amountDue: number }) {
  if (amountDue <= 0 || !dueDate) return null;
  const past = daysPastDue(dueDate);
  if (past === null) return null;
  if (past > 0) {
    return (
      <span className="rounded bg-red-100 px-1.5 py-0.5 text-[10px] font-bold text-red-800">
        Overdue {past}d ({fmtDate(dueDate)})
      </span>
    );
  }
  if (past === 0) {
    return (
      <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-900">
        Due Today
      </span>
    );
  }
  return (
    <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-600">
      Due {fmtDate(dueDate)}
    </span>
  );
}

function parseAuditChanges(json: string | null): Array<[string, { from: unknown; to: unknown }]> {
  if (!json) return [];
  try {
    const parsed = JSON.parse(json) as unknown;
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return Object.entries(parsed as Record<string, { from: unknown; to: unknown }>);
    }
  } catch {
    /* ignore */
  }
  return [];
}

export default function DealDrawer({
  deal,
  allDeals = [],
  currentUser,
  onClose,
  onInspectDealById,
  onWhatsApp,
  onExpense,
  onPayments,
  onReceipt,
  onReserve,
  onSold,
  onEdit,
  onDealChanged,
  onNotify,
}: Props) {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'payments' | 'expenses' | 'checklist' | 'transfer' | 'documents' | 'history'
  >('overview');

  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [attachments, setAttachments] = useState<DealAttachment[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [previews, setPreviews] = useState<Record<number, string>>({});

  // Transfer state
  const [transferStatus, setTransferStatus] = useState<TransferStatus>(deal.transfer_status || 'PENDING');
  const [agentName, setAgentName] = useState(deal.transfer_agent_name || '');
  const [agentContact, setAgentContact] = useState(deal.transfer_agent_contact || '');
  const [handoverDate, setHandoverDate] = useState(deal.file_handover_date || '');
  const [completedDate, setCompletedDate] = useState(deal.transfer_completed_date || '');
  const [transferCost, setTransferCost] = useState(deal.transfer_cost ? String(deal.transfer_cost) : '');
  const [transferNotes, setTransferNotes] = useState(deal.transfer_notes || '');
  const [savingTransfer, setSavingTransfer] = useState(false);

  // Checklist state
  const [checklist, setChecklist] = useState<DealChecklist>(() => parseChecklist(deal.checklist_json));
  const [tokenTaxTill, setTokenTaxTill] = useState(deal.token_tax_paid_till || '');
  const [savingChecklist, setSavingChecklist] = useState(false);

  // Attachments & Webcam
  const [docCategory, setDocCategory] = useState<AttachmentCategory>('CNIC_FRONT');
  const [docLabel, setDocLabel] = useState('');
  const [webcamOpen, setWebcamOpen] = useState(false);
  const [lightboxAtt, setLightboxAtt] = useState<DealAttachment | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadingFiles, setUploadingFiles] = useState(false);

  const canViewProfit = !currentUser || currentUser.role === 'OWNER' || currentUser.can_view_profit;
  const canManagePayments = !currentUser || currentUser.role === 'OWNER' || currentUser.can_manage_payments;
  const canMarkSold = !currentUser || currentUser.role === 'OWNER' || currentUser.can_mark_sold;
  const isElectron = Boolean(window.api?.isElectron);

  const tradeInGivenDeal = deal.trade_in_deal_id
    ? allDeals.find((d) => d.id === deal.trade_in_deal_id) ?? null
    : null;
  const tradeInForSoldDeal = deal.trade_in_for_deal_id
    ? allDeals.find((d) => d.id === deal.trade_in_for_deal_id) ?? null
    : null;

  useEffect(() => {
    setTransferStatus(deal.transfer_status || 'PENDING');
    setAgentName(deal.transfer_agent_name || '');
    setAgentContact(deal.transfer_agent_contact || '');
    setHandoverDate(deal.file_handover_date || '');
    setCompletedDate(deal.transfer_completed_date || '');
    setTransferCost(deal.transfer_cost ? String(deal.transfer_cost) : '');
    setTransferNotes(deal.transfer_notes || '');
    setChecklist(parseChecklist(deal.checklist_json));
    setTokenTaxTill(deal.token_tax_paid_till || '');
  }, [deal]);

  // Clear cached image data URLs when switching between vehicles to avoid memory bloat
  useEffect(() => {
    setPreviews({});
    setLightboxAtt(null);
  }, [deal.id]);

  const loadAllDetails = useCallback(async () => {
    if (!window.api) return;
    const [expList, payList, attList, logs] = await Promise.all([
      window.api.listExpenses(deal.id),
      window.api.listPayments(deal.id),
      window.api.listAttachments(deal.id),
      window.api.listAuditLogs(deal.id, 100),
    ]);
    setExpenses(expList);
    setPayments(payList);
    setAttachments(attList);
    setAuditLogs(logs);
  }, [deal.id]);

  useEffect(() => {
    void loadAllDetails();
  }, [loadAllDetails, deal.total_expenses, deal.paid_to_seller, deal.received_from_buyer, deal.attachment_count]);

  // Lazy-load attachment image previews ONLY when the Documents tab is open
  useEffect(() => {
    if (activeTab !== 'documents' || !window.api || attachments.length === 0) return;
    let alive = true;
    const missingImages = attachments.filter(
      (att) => /\.(png|jpe?g|webp)$/i.test(att.file_name) && !previews[att.id],
    );
    if (missingImages.length === 0) return;

    (async () => {
      const updates: Record<number, string> = {};
      for (const att of missingImages) {
        const url = await window.api?.readAttachmentDataUrl(att.file_path);
        if (!alive) return;
        if (url) updates[att.id] = url;
      }
      if (alive && Object.keys(updates).length > 0) {
        setPreviews((prev) => ({ ...prev, ...updates }));
      }
    })();

    return () => {
      alive = false;
    };
  }, [activeTab, attachments, previews]);

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        if (lightboxAtt) {
          setLightboxAtt(null);
        } else if (!webcamOpen) {
          onClose();
        }
      }
    }
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [lightboxAtt, webcamOpen, onClose]);

  const purchasePrice = deal.purchase_price ?? 0;
  const transferExpense = deal.transfer_cost ?? 0;
  const totalCostVal = purchasePrice + deal.total_expenses + transferExpense;
  const netProfit =
    deal.status === 'SOLD' && deal.sale_price !== null && deal.purchase_price !== null
      ? deal.sale_price - totalCostVal
      : null;

  const sellerBalance = sellerBalanceDue(deal) ?? 0;
  const sOverpaid = sellerOverpaid(deal);
  const buyerBalance = buyerBalanceDue(deal) ?? 0;
  const bOverpaid = buyerOverpaid(deal);
  const stockDays = daysInStock(deal);
  const checkSummary = checklistSummary(deal);
  const reservePastDue = deal.status === 'RESERVED' ? daysPastDue(deal.reserved_expiry_date) : null;

  async function handleSaveTransfer(e: React.FormEvent) {
    e.preventDefault();
    if (!window.api) return;
    setSavingTransfer(true);
    try {
      await window.api.updateTransfer(deal.id, {
        transfer_status: transferStatus,
        transfer_agent_name: agentName,
        transfer_agent_contact: agentContact,
        file_handover_date: handoverDate,
        transfer_completed_date: completedDate,
        transfer_cost: transferCost || 0,
        transfer_notes: transferNotes,
      });
      onDealChanged();
      await loadAllDetails();
      onNotify('Transfer & file handover details saved');
    } finally {
      setSavingTransfer(false);
    }
  }

  async function handleToggleChecklist(key: ChecklistKey) {
    if (!window.api) return;
    const next: DealChecklist = { ...checklist, [key]: !checklist[key] };
    setChecklist(next);
    setSavingChecklist(true);
    try {
      await window.api.updateChecklist(deal.id, JSON.stringify(next), tokenTaxTill || null);
      onDealChanged();
      await loadAllDetails();
    } finally {
      setSavingChecklist(false);
    }
  }

  async function handleSaveTokenTax() {
    if (!window.api) return;
    setSavingChecklist(true);
    try {
      await window.api.updateChecklist(deal.id, JSON.stringify(checklist), tokenTaxTill || null);
      onDealChanged();
      await loadAllDetails();
      onNotify('Checklist & token tax saved');
    } finally {
      setSavingChecklist(false);
    }
  }

  async function handlePickAttachment() {
    if (!window.api) return;
    const labelText = docLabel.trim() || ATTACHMENT_CATEGORY_LABELS[docCategory];
    const added = await window.api.pickAndAddAttachment(deal.id, docCategory, labelText);
    if (added) {
      setDocLabel('');
      onDealChanged();
      await loadAllDetails();
      onNotify(`Attached ${added.label}`);
    }
  }

  async function handleUploadFiles(fileList: FileList | File[]) {
    const files = Array.from(fileList);
    if (!window.api || files.length === 0) return;
    setUploadingFiles(true);
    try {
      let savedCount = 0;
      let savedBytes = 0;
      for (const file of files) {
        const prepared = await prepareAttachmentFile(file);
        const labelText =
          docLabel.trim() ||
          (files.length > 1 ? `${ATTACHMENT_CATEGORY_LABELS[docCategory]} (${savedCount + 1})` : ATTACHMENT_CATEGORY_LABELS[docCategory]);
        await window.api.saveAttachmentData(deal.id, docCategory, labelText, prepared.fileName, prepared.dataUrl);
        savedCount++;
        if (prepared.compressed && prepared.originalBytes > prepared.finalBytes) {
          savedBytes += prepared.originalBytes - prepared.finalBytes;
        }
      }
      setDocLabel('');
      onDealChanged();
      await loadAllDetails();
      const mbSaved = savedBytes > 25000 ? ` (compressed, saved ${(savedBytes / (1024 * 1024)).toFixed(1)} MB)` : '';
      onNotify(`Attached ${savedCount} file${savedCount === 1 ? '' : 's'}${mbSaved}`);
    } finally {
      setUploadingFiles(false);
    }
  }

  function handleDrop(e: DragEvent<HTMLDivElement>) {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer?.files?.length) {
      void handleUploadFiles(e.dataTransfer.files);
    }
  }

  async function handleDownloadAttachment(att: DealAttachment) {
    if (!window.api) return;
    const url = previews[att.id] ?? (await window.api.readAttachmentDataUrl(att.file_path));
    if (!url) return;
    const a = document.createElement('a');
    a.href = url;
    a.download = att.file_name;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function handleDeleteAttachment(id: number) {
    if (!window.api) return;
    await window.api.deleteAttachment(id);
    setPreviews((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    onDealChanged();
    await loadAllDetails();
    onNotify('Attachment deleted');
  }

  const carTitle = [deal.year, deal.make, deal.model, deal.variant].filter(Boolean).join(' ') || `Car #${deal.id}`;

  return (
    <>
      <div className="fixed inset-0 z-40 flex justify-end bg-slate-900/35 backdrop-blur-[1px]" onClick={onClose}>
        <aside
          className="flex h-full w-full max-w-2xl flex-col border-l border-slate-200 bg-white shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-2 border-b border-slate-200 bg-slate-50/70 px-4 py-3.5 sm:px-6 sm:py-4">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base font-extrabold text-slate-900 sm:text-lg">{carTitle}</h2>
                <span
                  className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide ${
                    deal.status === 'SOLD'
                      ? 'bg-emerald-100 text-emerald-800'
                      : deal.status === 'RESERVED'
                        ? 'bg-indigo-100 text-indigo-800'
                        : 'bg-blue-100 text-blue-800'
                  }`}
                >
                  {deal.status === 'SOLD' ? 'Sold' : deal.status === 'RESERVED' ? 'Reserved (Token)' : 'In Stock'}
                </span>
                {deal.registration_number && (
                  <span className="rounded-md border border-slate-300 bg-white px-2 py-0.5 font-mono text-xs font-bold text-slate-800">
                    {deal.registration_number}
                  </span>
                )}
                {stockDays !== null && (
                  <span
                    className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${
                      deal.status === 'SOLD'
                        ? 'bg-slate-100 text-slate-600'
                        : stockDays >= 60
                          ? 'bg-red-100 text-red-800'
                          : stockDays >= 30
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {deal.status === 'SOLD' ? `Sold in ${stockDays}d` : `${stockDays}d in stock`}
                  </span>
                )}
              </div>
              <p className="mt-1 text-xs text-slate-500">
                Purchased: {deal.purchase_date ? fmtDate(deal.purchase_date) : 'N/A'}
                {deal.bought_from_location ? ` · From ${deal.bought_from_location}` : ''}
                {deal.created_by ? ` · Logged by ${deal.created_by}` : ''}
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="shrink-0 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100"
            >
              ✕ Close
            </button>
          </div>

          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 bg-white px-4 py-2.5 sm:px-6">
            <button type="button" className="btn btn-secondary btn-sm text-xs" onClick={() => onEdit(deal)}>
              Edit
            </button>
            <button type="button" className="btn btn-secondary btn-sm text-xs" onClick={() => onReceipt(deal)}>
              Receipt / PDF
            </button>
            <button
              type="button"
              className="btn btn-secondary btn-sm text-xs text-emerald-700"
              onClick={() => onWhatsApp(deal, deal.status === 'SOLD' ? 'RECEIPT' : 'SPECS')}
            >
              WhatsApp
            </button>
            {deal.status !== 'SOLD' && canMarkSold && (
              <button
                type="button"
                className="btn btn-secondary btn-sm text-xs text-indigo-700"
                onClick={() => onReserve(deal)}
              >
                {deal.status === 'RESERVED' ? 'Edit Hold' : 'Reserve / Token'}
              </button>
            )}
            {deal.status !== 'SOLD' && canMarkSold && (
              <button type="button" className="btn btn-primary btn-sm ml-auto text-xs" onClick={() => onSold(deal)}>
                {deal.status === 'RESERVED' ? 'Convert to Sold' : 'Mark as Sold'}
              </button>
            )}
          </div>

          {/* Trade-In Exchange Link Banners */}
          {(deal.trade_in_deal_id || deal.trade_in_for_deal_id) && (
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-purple-200 bg-purple-50 px-4 py-2 text-xs text-purple-950 sm:px-6">
              <div>
                <span className="font-bold">Exchange / Trade-In Linked: </span>
                {deal.trade_in_deal_id ? (
                  <span>
                    Accepted{' '}
                    <strong>
                      {tradeInGivenDeal
                        ? `${formatCarTitle(tradeInGivenDeal)} (${regOf(tradeInGivenDeal)})`
                        : `Car #${deal.trade_in_deal_id}`}
                    </strong>{' '}
                    as part-payment
                  </span>
                ) : (
                  <span>
                    Received as trade-in for{' '}
                    <strong>
                      {tradeInForSoldDeal
                        ? `${formatCarTitle(tradeInForSoldDeal)} (${regOf(tradeInForSoldDeal)})`
                        : `Deal #${deal.trade_in_for_deal_id}`}
                    </strong>
                  </span>
                )}
              </div>
              {onInspectDealById && (
                <button
                  type="button"
                  onClick={() => onInspectDealById((deal.trade_in_deal_id ?? deal.trade_in_for_deal_id)!)}
                  className="font-bold text-purple-800 underline hover:text-purple-950"
                >
                  Open Linked Car →
                </button>
              )}
            </div>
          )}

          {/* Reservation Banner */}
          {deal.status === 'RESERVED' && (
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-indigo-200 bg-indigo-50 px-4 py-2.5 text-xs text-indigo-950 sm:px-6">
              <div>
                <span className="font-bold">Reserved / Bayana Hold</span>
                {deal.reserved_buyer_name ? ` for ${deal.reserved_buyer_name}` : ''}
                {deal.reserved_buyer_contact ? ` (${deal.reserved_buyer_contact})` : ''}
                {deal.reserved_token_amount ? ` · Token: ${fmtMoney(deal.reserved_token_amount)}` : ''}
                {deal.reserved_expiry_date && (
                  <span className="ml-1.5">
                    · Expires: <strong>{fmtDate(deal.reserved_expiry_date)}</strong>
                    {reservePastDue !== null && reservePastDue > 0 && (
                      <span className="ml-1.5 rounded bg-red-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                        Expired {reservePastDue}d ago
                      </span>
                    )}
                  </span>
                )}
                {deal.reserved_notes && <div className="mt-0.5 text-[11px] text-indigo-800">{deal.reserved_notes}</div>}
              </div>
            </div>
          )}

          {/* Financial Summary Strip */}
          <div className="grid grid-cols-2 gap-2.5 border-b border-slate-200 bg-slate-50 px-4 py-3 sm:grid-cols-4 sm:px-6">
            <div className="rounded-lg border border-slate-200 bg-white p-2.5">
              <div className="text-[11px] font-semibold text-slate-500">Purchase Price</div>
              <div className="mt-0.5 text-sm font-extrabold tabular-nums text-slate-900">
                {canViewProfit ? formatPkr(deal.purchase_price) : 'Restricted'}
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 bg-white p-2.5">
              <div className="text-[11px] font-semibold text-slate-500">Expenses + Transfer</div>
              <div className="mt-0.5 text-sm font-extrabold tabular-nums text-slate-900">
                {canViewProfit ? formatPkr(deal.total_expenses + transferExpense) : 'Restricted'}
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 bg-white p-2.5">
              <div className="text-[11px] font-semibold text-slate-500">
                {deal.status === 'SOLD' ? 'Sale Price' : 'Total Investment'}
              </div>
              <div className="mt-0.5 text-sm font-extrabold tabular-nums text-slate-900">
                {deal.status === 'SOLD'
                  ? formatPkr(deal.sale_price)
                  : canViewProfit
                    ? formatPkr(totalCostVal)
                    : 'Restricted'}
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 bg-white p-2.5">
              <div className="text-[11px] font-semibold text-slate-500">Net Profit</div>
              <div
                className={`mt-0.5 text-sm font-extrabold tabular-nums ${
                  !canViewProfit
                    ? 'text-slate-400'
                    : netProfit === null
                      ? 'text-slate-400'
                      : netProfit >= 0
                        ? 'text-emerald-700'
                        : 'text-red-600'
                }`}
              >
                {!canViewProfit ? 'Hidden' : netProfit === null ? 'Pending Sale' : formatPkr(netProfit)}
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex overflow-x-auto border-b border-slate-200 bg-white px-4 text-xs font-bold sm:px-6">
            {(
              [
                ['overview', 'Overview'],
                ['payments', `Payments (${payments.length})`],
                ['expenses', `Expenses (${expenses.length})`],
                ['checklist', `Checklist (${checkSummary.checkedCount}/${checkSummary.totalCount})`],
                ['transfer', 'File & Transfer'],
                ['documents', `Docs & Camera (${attachments.length})`],
                ['history', `History (${auditLogs.length})`],
              ] as const
            ).map(([tabKey, tabLabel]) => (
              <button
                key={tabKey}
                type="button"
                onClick={() => setActiveTab(tabKey)}
                className={`min-h-[40px] shrink-0 border-b-2 px-3 py-2.5 transition-colors ${
                  activeTab === tabKey
                    ? 'border-brand-600 text-brand-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {tabLabel}
              </button>
            ))}
          </div>

          {/* Body Content */}
          <div className="flex-1 space-y-5 overflow-y-auto p-4 sm:p-6">
            {activeTab === 'overview' && (
              <>
                {checkSummary.missingCriticalDocs.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setActiveTab('checklist')}
                    className="flex w-full items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-left text-xs text-amber-900 hover:bg-amber-100/70"
                  >
                    <div>
                      <span className="font-bold">Missing Key Paperwork ({checkSummary.missingCriticalDocs.length}):</span>{' '}
                      {checkSummary.missingCriticalDocs.join(', ')}
                    </div>
                    <span className="shrink-0 font-bold text-amber-800 underline">Review Checklist →</span>
                  </button>
                )}

                <div className="rounded-xl border border-slate-200 bg-white p-4">
                  <h3 className="mb-3 text-xs font-extrabold uppercase tracking-wider text-slate-500">
                    Vehicle Specifications
                  </h3>
                  <div className="grid grid-cols-2 gap-3 text-xs sm:grid-cols-3">
                    <div>
                      <span className="text-slate-400">Make / Model:</span>
                      <div className="font-bold text-slate-800">
                        {[deal.make, deal.model, deal.variant].filter(Boolean).join(' ') || '—'}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Year / Color:</span>
                      <div className="font-bold text-slate-800">
                        {[deal.year, deal.color].filter(Boolean).join(' · ') || '—'}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Engine Capacity:</span>
                      <div className="font-bold text-slate-800">{deal.horse_power || '—'}</div>
                    </div>
                    <div>
                      <span className="text-slate-400">Registration #:</span>
                      <div className="font-mono font-bold text-slate-800">{deal.registration_number || '—'}</div>
                    </div>
                    <div>
                      <span className="text-slate-400">Chassis #:</span>
                      <div className="font-mono font-bold text-slate-800">{deal.chassis_number || '—'}</div>
                    </div>
                    <div>
                      <span className="text-slate-400">Engine #:</span>
                      <div className="font-mono font-bold text-slate-800">{deal.engine_number || '—'}</div>
                    </div>
                    <div>
                      <span className="text-slate-400">Mileage:</span>
                      <div className="font-bold text-slate-800">
                        {deal.mileage ? `${deal.mileage.toLocaleString()} km` : '—'}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Bought From:</span>
                      <div className="font-bold text-slate-800">{deal.bought_from_location || '—'}</div>
                    </div>
                    <div>
                      <span className="text-slate-400">Token Tax Paid Till:</span>
                      <div className="font-bold text-slate-800">{deal.token_tax_paid_till || '—'}</div>
                    </div>
                  </div>
                </div>

                {/* Seller Party */}
                <div className="rounded-xl border border-slate-200 bg-white p-4">
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                    <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500">
                      Seller Details (Purchased From)
                    </h3>
                    {deal.purchase_price !== null && (
                      <div className="flex flex-wrap items-center gap-1.5">
                        <DueBadge dueDate={deal.seller_due_date} amountDue={sellerBalance} />
                        {sOverpaid > 0 ? (
                          <span className="rounded-full bg-red-100 px-2 py-0.5 text-[11px] font-bold text-red-800">
                            Overpaid by {formatPkr(sOverpaid)}
                          </span>
                        ) : (
                          <span
                            className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${
                              sellerBalance === 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {sellerBalance === 0 ? 'Seller Paid in Full' : `Due to Seller: ${formatPkr(sellerBalance)}`}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="grid grid-cols-1 gap-2 text-xs sm:grid-cols-2">
                    <div>
                      <span className="text-slate-400">Name:</span>{' '}
                      <span className="font-bold text-slate-800">{deal.seller_name || '—'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">S/O (Father):</span>{' '}
                      <span className="font-bold text-slate-800">{deal.seller_father_name || '—'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">CNIC:</span>{' '}
                      <span className="font-mono font-bold text-slate-800">{deal.seller_cnic || '—'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Contact:</span>{' '}
                      <span className="font-bold text-slate-800">{deal.seller_contact || '—'}</span>
                    </div>
                    <div className="sm:col-span-2">
                      <span className="text-slate-400">Address:</span>{' '}
                      <span className="font-semibold text-slate-700">{deal.seller_address || '—'}</span>
                    </div>
                  </div>
                </div>

                {/* Purchaser Party (if Sold) */}
                {deal.status === 'SOLD' && (
                  <div className="rounded-xl border border-emerald-200 bg-emerald-50/40 p-4">
                    <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                      <h3 className="text-xs font-extrabold uppercase tracking-wider text-emerald-800">
                        Purchaser Details (Sold To on {deal.sale_date ? fmtDate(deal.sale_date) : 'N/A'})
                      </h3>
                      {deal.sale_price !== null && (
                        <div className="flex flex-wrap items-center gap-1.5">
                          <DueBadge dueDate={deal.buyer_due_date} amountDue={buyerBalance} />
                          {bOverpaid > 0 ? (
                            <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-[11px] font-bold text-indigo-800">
                              Excess received: {formatPkr(bOverpaid)}
                            </span>
                          ) : (
                            <span
                              className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${
                                buyerBalance === 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {buyerBalance === 0 ? 'Buyer Paid in Full' : `Due from Buyer: ${formatPkr(buyerBalance)}`}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="grid grid-cols-1 gap-2 text-xs sm:grid-cols-2">
                      <div>
                        <span className="text-slate-500">Name:</span>{' '}
                        <span className="font-bold text-slate-900">{deal.purchaser_name || '—'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">S/O (Father):</span>{' '}
                        <span className="font-bold text-slate-900">{deal.purchaser_father_name || '—'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">CNIC:</span>{' '}
                        <span className="font-mono font-bold text-slate-900">{deal.purchaser_cnic || '—'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Contact:</span>{' '}
                        <span className="font-bold text-slate-900">{deal.purchaser_contact || '—'}</span>
                      </div>
                      <div className="sm:col-span-2">
                        <span className="text-slate-500">Address:</span>{' '}
                        <span className="font-semibold text-slate-800">{deal.purchaser_address || '—'}</span>
                      </div>
                    </div>
                  </div>
                )}

                {deal.notes && (
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs">
                    <div className="mb-1 font-bold text-slate-700">Deal Notes</div>
                    <p className="whitespace-pre-wrap text-slate-600">{deal.notes}</p>
                  </div>
                )}
              </>
            )}

            {activeTab === 'payments' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs">
                    <div className="text-slate-500">Paid to Seller</div>
                    <div className="mt-0.5 text-base font-extrabold tabular-nums text-slate-900">{formatPkr(deal.paid_to_seller)}</div>
                    <div className="mt-0.5 text-[11px] font-semibold">
                      {sOverpaid > 0 ? (
                        <span className="text-red-700">Overpaid by {formatPkr(sOverpaid)}</span>
                      ) : (
                        <span className="text-amber-700">Remaining Due: {formatPkr(sellerBalance)}</span>
                      )}
                    </div>
                    {sellerBalance > 0 && deal.seller_due_date && (
                      <div className="mt-1">
                        <DueBadge dueDate={deal.seller_due_date} amountDue={sellerBalance} />
                      </div>
                    )}
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs">
                    <div className="text-slate-500">Received from Buyer</div>
                    <div className="mt-0.5 text-base font-extrabold tabular-nums text-emerald-700">
                      {formatPkr(deal.received_from_buyer)}
                    </div>
                    <div className="mt-0.5 text-[11px] font-semibold">
                      {deal.status === 'SOLD' ? (
                        bOverpaid > 0 ? (
                          <span className="text-indigo-700">Excess received: {formatPkr(bOverpaid)}</span>
                        ) : (
                          <span className="text-amber-700">Remaining Due: {formatPkr(buyerBalance)}</span>
                        )
                      ) : deal.status === 'RESERVED' ? (
                        <span className="text-indigo-700">Bayana / Token Held</span>
                      ) : (
                        <span className="text-slate-500">Not Sold Yet</span>
                      )}
                    </div>
                    {buyerBalance > 0 && deal.buyer_due_date && (
                      <div className="mt-1">
                        <DueBadge dueDate={deal.buyer_due_date} amountDue={buyerBalance} />
                      </div>
                    )}
                  </div>
                </div>

                {canManagePayments && (
                  <div className="flex justify-end">
                    <button type="button" className="btn btn-primary btn-sm text-xs" onClick={() => onPayments(deal)}>
                      + Manage / Record Payments
                    </button>
                  </div>
                )}

                <div className="space-y-2">
                  {payments.length === 0 ? (
                    <div className="rounded-xl border border-dashed border-slate-300 py-8 text-center text-xs text-slate-400">
                      No payments recorded for this vehicle yet.
                    </div>
                  ) : (
                    payments.map((p) => (
                      <div
                        key={p.id}
                        className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs"
                      >
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span
                              className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                p.direction === 'IN_FROM_BUYER'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}
                            >
                              {p.direction === 'IN_FROM_BUYER' ? 'IN ← Buyer' : 'OUT → Seller'}
                            </span>
                            <span className="font-bold text-slate-800">{p.payment_type}</span>
                            <span className="text-slate-400">via {p.method}</span>
                            {p.method === 'Cheque' && (
                              <span
                                className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${
                                  p.cheque_status === 'CLEARED'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : p.cheque_status === 'BOUNCED'
                                      ? 'bg-red-100 text-red-800'
                                      : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {p.cheque_status ?? 'PENDING'}
                              </span>
                            )}
                          </div>
                          <div className="mt-0.5 text-[11px] text-slate-500">
                            {p.date}
                            {p.cheque_number ? ` · Cheque #${p.cheque_number}` : ''}
                            {p.cheque_date ? ` (Due ${p.cheque_date})` : ''}
                            {p.notes ? ` · ${p.notes}` : ''}
                            {p.created_by ? ` · By ${p.created_by}` : ''}
                          </div>
                        </div>
                        <span className="font-extrabold tabular-nums text-slate-900">{formatPkr(p.amount)}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {activeTab === 'expenses' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-slate-600">
                    Total General Expenses:{' '}
                    <span className="tabular-nums text-slate-900">
                      {canViewProfit ? formatPkr(deal.total_expenses) : 'Restricted'}
                    </span>
                  </div>
                  <button type="button" className="btn btn-primary btn-sm text-xs" onClick={() => onExpense(deal)}>
                    + Add / Manage Expenses
                  </button>
                </div>

                <div className="space-y-2">
                  {expenses.length === 0 ? (
                    <div className="rounded-xl border border-dashed border-slate-300 py-8 text-center text-xs text-slate-400">
                      No expenses logged for this car yet.
                    </div>
                  ) : (
                    expenses.map((exp) => (
                      <div
                        key={exp.id}
                        className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs"
                      >
                        <div>
                          <div className="font-bold text-slate-800">
                            {exp.category}
                            {exp.description && exp.description !== exp.category ? ` — ${exp.description}` : ''}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            {exp.date}
                            {exp.payee_name ? ` · Paid to: ${exp.payee_name}` : ''}
                            {exp.created_by ? ` · Logged by ${exp.created_by}` : ''}
                          </div>
                        </div>
                        <span className="font-extrabold tabular-nums text-slate-900">
                          {canViewProfit ? formatPkr(exp.amount) : '—'}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {activeTab === 'checklist' && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-xs">
                  <div>
                    <div className="font-bold text-slate-900">
                      {checkSummary.checkedCount} of {checkSummary.totalCount} items verified
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Toggle any box below to save immediately to the vehicle record.
                    </div>
                  </div>
                  {savingChecklist && <span className="text-[11px] font-semibold text-brand-700">Saving…</span>}
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="rounded-xl border border-slate-200 bg-white p-4">
                    <h4 className="mb-2.5 text-xs font-extrabold uppercase tracking-wider text-slate-500">
                      Paperwork &amp; Excise Docs ({checkSummary.docsChecked}/{checkSummary.docsTotal})
                    </h4>
                    <div className="space-y-2">
                      {CHECKLIST_ITEMS.filter((i) => i.group === 'DOCS').map((item) => (
                        <label
                          key={item.key}
                          className="flex cursor-pointer items-center justify-between rounded-lg border border-slate-100 px-3 py-2 text-xs hover:bg-slate-50"
                        >
                          <span className="flex items-center gap-2.5 font-medium text-slate-800">
                            <input
                              type="checkbox"
                              className="h-4 w-4 rounded border-slate-300 text-brand-600"
                              checked={Boolean(checklist[item.key])}
                              onChange={() => void handleToggleChecklist(item.key)}
                            />
                            {item.label}
                          </span>
                          {item.critical && !checklist[item.key] && (
                            <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800">
                              Missing
                            </span>
                          )}
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-xl border border-slate-200 bg-white p-4">
                    <h4 className="mb-2.5 text-xs font-extrabold uppercase tracking-wider text-slate-500">
                      Vehicle Condition Check
                    </h4>
                    <div className="space-y-2">
                      {CHECKLIST_ITEMS.filter((i) => i.group === 'COND').map((item) => (
                        <label
                          key={item.key}
                          className="flex cursor-pointer items-center gap-2.5 rounded-lg border border-slate-100 px-3 py-2 text-xs font-medium text-slate-800 hover:bg-slate-50"
                        >
                          <input
                            type="checkbox"
                            className="h-4 w-4 rounded border-slate-300 text-brand-600"
                            checked={Boolean(checklist[item.key])}
                            onChange={() => void handleToggleChecklist(item.key)}
                          />
                          {item.label}
                        </label>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:flex-row sm:items-end">
                  <div className="flex-1">
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Token Tax Paid Till</label>
                    <input
                      type="text"
                      className="input text-xs"
                      value={tokenTaxTill}
                      onChange={(e) => setTokenTaxTill(e.target.value)}
                      placeholder="e.g. Jun 2027 or Lifetime"
                    />
                  </div>
                  <button
                    type="button"
                    disabled={savingChecklist}
                    onClick={() => void handleSaveTokenTax()}
                    className="btn btn-primary btn-sm text-xs"
                  >
                    Save Token Tax
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'transfer' && (
              <form
                onSubmit={(e) => void handleSaveTransfer(e)}
                className="space-y-4 rounded-xl border border-slate-200 bg-white p-4"
              >
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-600">
                  Excise File Handover &amp; Transfer Tracking
                </h4>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Transfer Status</label>
                    <select
                      className="input text-xs"
                      value={transferStatus}
                      onChange={(e) => setTransferStatus(e.target.value as TransferStatus)}
                    >
                      <option value="PENDING">Pending Handover</option>
                      <option value="WITH_AGENT">File With Agent / Excise</option>
                      <option value="COMPLETED">Transfer Completed</option>
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Transfer Fee / Cost (PKR)</label>
                    <input
                      type="number"
                      className="input text-xs"
                      value={transferCost}
                      onChange={(e) => setTransferCost(e.target.value)}
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Agent Name</label>
                    <input
                      type="text"
                      className="input text-xs"
                      value={agentName}
                      onChange={(e) => setAgentName(e.target.value)}
                      placeholder="Excise agent or representative"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Agent Contact</label>
                    <input
                      type="text"
                      className="input text-xs"
                      value={agentContact}
                      onChange={(e) => setAgentContact(e.target.value)}
                      placeholder="03XX-XXXXXXX"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">File Handover Date</label>
                    <input
                      type="date"
                      className="input text-xs"
                      value={handoverDate}
                      onChange={(e) => setHandoverDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Transfer Completed Date</label>
                    <input
                      type="date"
                      className="input text-xs"
                      value={completedDate}
                      onChange={(e) => setCompletedDate(e.target.value)}
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-xs font-semibold text-slate-700">Transfer / Biometric Notes</label>
                    <textarea
                      rows={2}
                      className="input text-xs"
                      value={transferNotes}
                      onChange={(e) => setTransferNotes(e.target.value)}
                      placeholder="e.g. Original book, smart card & NADRA biometric slip handed over"
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <button type="submit" className="btn btn-primary btn-sm text-xs" disabled={savingTransfer}>
                    {savingTransfer ? 'Saving…' : 'Save Transfer Details'}
                  </button>
                </div>
              </form>
            )}

            {activeTab === 'documents' && (
              <div className="space-y-4">
                <div className="rounded-xl border border-slate-200 bg-white p-4">
                  <h4 className="mb-3 text-xs font-extrabold uppercase tracking-wider text-slate-600">
                    Attach CNIC, Smart Card, Registration Book or Car Photos
                  </h4>
                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    <select
                      className="input text-xs"
                      value={docCategory}
                      onChange={(e) => setDocCategory(e.target.value as AttachmentCategory)}
                    >
                      {(Object.keys(ATTACHMENT_CATEGORY_LABELS) as AttachmentCategory[]).map((cat) => (
                        <option key={cat} value={cat}>
                          {ATTACHMENT_CATEGORY_LABELS[cat]}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      className="input text-xs"
                      placeholder="Custom label (e.g. Seller CNIC Front)"
                      value={docLabel}
                      onChange={(e) => setDocLabel(e.target.value)}
                    />
                  </div>

                  {/* Multi-File Drag-and-Drop Dropzone */}
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragging(true);
                    }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={handleDrop}
                    className={`mt-3 rounded-xl border-2 border-dashed p-4 text-center transition ${
                      isDragging ? 'border-brand-600 bg-brand-50' : 'border-slate-300 bg-slate-50/70'
                    }`}
                  >
                    <div className="text-xs font-semibold text-slate-700">
                      {uploadingFiles
                        ? 'Compressing & saving files…'
                        : 'Drag & drop multiple car photos or PDFs here'}
                    </div>
                    <div className="mt-0.5 text-[11px] text-slate-500">
                      Large phone photos are auto-resized so backups stay small and fast.
                    </div>
                    <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                      <label className="btn btn-secondary btn-sm cursor-pointer text-xs">
                        Select Multiple Files / PDFs
                        <input
                          type="file"
                          multiple
                          accept="image/*,.pdf"
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files?.length) void handleUploadFiles(e.target.files);
                            e.target.value = '';
                          }}
                        />
                      </label>

                      <label className="btn btn-secondary btn-sm cursor-pointer text-xs sm:hidden">
                        Phone Camera
                        <input
                          type="file"
                          accept="image/*"
                          capture="environment"
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files?.length) void handleUploadFiles(e.target.files);
                            e.target.value = '';
                          }}
                        />
                      </label>

                      {isElectron && (
                        <button
                          type="button"
                          className="btn btn-secondary btn-sm text-xs"
                          onClick={() => void handlePickAttachment()}
                        >
                          Browse PC Folder
                        </button>
                      )}

                      <button
                        type="button"
                        className="btn btn-primary btn-sm text-xs"
                        onClick={() => setWebcamOpen(true)}
                      >
                        Capture Webcam
                      </button>
                    </div>
                  </div>
                </div>

                {attachments.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-slate-300 py-8 text-center text-xs text-slate-400">
                    No documents or photos attached to this vehicle yet.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {attachments.map((att) => {
                      const imgUrl = previews[att.id];
                      const isImage = /\.(png|jpe?g|webp)$/i.test(att.file_name);
                      return (
                        <div key={att.id} className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                          {imgUrl ? (
                            <button
                              type="button"
                              onClick={() => setLightboxAtt(att)}
                              className="block h-36 w-full overflow-hidden bg-slate-900"
                            >
                              <img src={imgUrl} alt={att.label} className="h-full w-full object-cover hover:opacity-90" />
                            </button>
                          ) : (
                            <div className="flex h-36 items-center justify-center bg-slate-100 text-xs font-bold text-slate-500">
                              {isImage ? 'Loading preview…' : `Document: ${att.file_name}`}
                            </div>
                          )}
                          <div className="flex items-center justify-between px-3 py-2 text-xs">
                            <div className="min-w-0">
                              <div className="truncate font-bold text-slate-800">{att.label}</div>
                              <div className="truncate text-[10px] text-slate-400">{att.file_name}</div>
                            </div>
                            <div className="flex items-center gap-2">
                              {isElectron ? (
                                <button
                                  type="button"
                                  onClick={() => void window.api?.showInFolder(att.file_path)}
                                  className="text-[11px] font-semibold text-brand-700 hover:underline"
                                >
                                  Folder
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => void handleDownloadAttachment(att)}
                                  className="text-[11px] font-semibold text-brand-700 hover:underline"
                                >
                                  Download
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => void handleDeleteAttachment(att.id)}
                                className="min-h-[28px] min-w-[28px] text-slate-400 hover:text-red-600"
                                title="Delete attachment"
                              >
                                ✕
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'history' && (
              <div className="space-y-3">
                {auditLogs.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-slate-300 py-8 text-center text-xs text-slate-400">
                    No activity history logged for this car yet.
                  </div>
                ) : (
                  auditLogs.map((log) => {
                    const diffs = parseAuditChanges(log.changes_json);
                    return (
                      <div key={log.id} className="rounded-xl border border-slate-200 bg-white p-3.5 text-xs">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold uppercase text-slate-700">
                              {log.action.replace(/_/g, ' ')}
                            </span>
                            <span className="font-bold text-slate-900">{log.summary}</span>
                          </div>
                          <div className="text-[11px] text-slate-500">
                            {log.actor_name ? `${log.actor_name} · ` : ''}
                            {new Date(log.created_at).toLocaleString()}
                          </div>
                        </div>
                        {diffs.length > 0 && (
                          <div className="mt-2 space-y-1 rounded-lg bg-slate-50 p-2 text-[11px]">
                            {diffs.map(([field, d]) => (
                              <div key={field} className="flex flex-wrap items-baseline gap-1.5">
                                <span className="font-mono font-semibold text-slate-600">{field}:</span>
                                <span className="text-red-700 line-through">
                                  {d?.from === null || d?.from === undefined || d?.from === '' ? 'empty' : String(d.from)}
                                </span>
                                <span className="text-slate-400">→</span>
                                <span className="font-semibold text-emerald-700">
                                  {d?.to === null || d?.to === undefined || d?.to === '' ? 'empty' : String(d.to)}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>
        </aside>
      </div>

      {/* Webcam Capture Modal rendered outside drawer backdrop */}
      {webcamOpen && (
        <WebcamCaptureModal
          dealId={deal.id}
          defaultCategory={docCategory}
          defaultLabel={docLabel}
          onClose={() => setWebcamOpen(false)}
          onSaved={(saved) => {
            setWebcamOpen(false);
            onDealChanged();
            void loadAllDetails();
            onNotify(`Captured & saved ${saved.label}`);
          }}
        />
      )}

      {/* In-App Image Preview Lightbox */}
      {lightboxAtt && previews[lightboxAtt.id] && (
        <div
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/85 p-3 backdrop-blur-xs sm:p-6"
          onClick={() => setLightboxAtt(null)}
        >
          <div
            className="flex max-h-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-4 py-3 text-white sm:px-5">
              <div className="min-w-0">
                <div className="truncate text-sm font-bold">{lightboxAtt.label || lightboxAtt.category}</div>
                <div className="truncate text-xs text-slate-400">{lightboxAtt.file_name}</div>
              </div>
              <div className="flex items-center gap-2">
                {isElectron ? (
                  <button
                    type="button"
                    onClick={() => void window.api?.showInFolder(lightboxAtt.file_path)}
                    className="rounded-lg border border-slate-700 px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-slate-800"
                  >
                    Open File Location
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => void handleDownloadAttachment(lightboxAtt)}
                    className="rounded-lg border border-slate-700 px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-slate-800"
                  >
                    Download
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setLightboxAtt(null)}
                  className="rounded-lg bg-slate-800 px-3 py-1 text-xs font-bold text-white hover:bg-slate-700"
                >
                  Close
                </button>
              </div>
            </div>
            <div className="flex flex-1 items-center justify-center overflow-auto bg-black p-4">
              <img
                src={previews[lightboxAtt.id]}
                alt={lightboxAtt.label}
                className="max-h-[75vh] max-w-full object-contain"
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
}