import { useCallback, useEffect, useState, type ChangeEvent } from 'react';
import Modal from './Modal';
import ConfirmDialog from './ConfirmDialog';
import type { BackupFileInfo, CloudBackupSettings } from '../types';
import {
  ELECTRON_OAUTH_REDIRECT_URI,
  MOBILE_OAUTH_REDIRECT_URI,
  getOAuthRedirectUri,
  type OAuthCloudProvider,
} from '../services/cloudSyncEngine';

interface Props {
  onClose: () => void;
  onRestored: (message: string) => void;
  onManualBackup: (kind: 'zip' | 'db' | 'csv') => void;
}

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

const PROVIDER_META: Record<
  OAuthCloudProvider,
  {
    label: string;
    shortLabel: string;
    idLabel: string;
    placeholder: string;
    portalHint: string;
  }
> = {
  ONEDRIVE: {
    label: 'Microsoft OneDrive',
    shortLabel: 'OneDrive',
    idLabel: 'OneDrive Application (Client) ID',
    placeholder: 'e.g. 9f8a12b3-4c5d-6e7f-8a9b-0c1d2e3f4a5b',
    portalHint: 'Azure Portal → App registrations → Application (client) ID',
  },
  DROPBOX: {
    label: 'Dropbox',
    shortLabel: 'Dropbox',
    idLabel: 'Dropbox App Key (Client ID)',
    placeholder: 'e.g. x7k9m2p4q8r1s5t',
    portalHint: 'dropbox.com/developers/apps → App folder → App key',
  },
  GOOGLE_DRIVE: {
    label: 'Google Drive',
    shortLabel: 'Google Drive',
    idLabel: 'Google OAuth Client ID',
    placeholder: 'e.g. 1234567890-abc.apps.googleusercontent.com',
    portalHint: 'console.cloud.google.com → Credentials → OAuth 2.0 Client ID',
  },
};

export default function BackupRestoreModal({ onClose, onRestored, onManualBackup }: Props) {
  const [backups, setBackups] = useState<BackupFileInfo[]>([]);
  const [folderPath, setFolderPath] = useState('');
  const [cloud, setCloud] = useState<CloudBackupSettings>({
    provider: 'NONE',
    cloud_backup_dir: '',
    last_local_backup_at: null,
    last_synced_at: null,
    last_error: null,
  });
  const [clientIds, setClientIds] = useState<Partial<Record<OAuthCloudProvider, string>>>({});
  const [draftIds, setDraftIds] = useState<Record<OAuthCloudProvider, string>>({
    ONEDRIVE: '',
    DROPBOX: '',
    GOOGLE_DRIVE: '',
  });
  const [activeProviderTab, setActiveProviderTab] = useState<OAuthCloudProvider>('ONEDRIVE');
  const [showSetupBox, setShowSetupBox] = useState(false);
  const [confirmTarget, setConfirmTarget] = useState<{ path?: string; label: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [savingId, setSavingId] = useState(false);
  const [syncingCloud, setSyncingCloud] = useState(false);
  const [pullingCloud, setPullingCloud] = useState(false);
  const [cloudStatusMsg, setCloudStatusMsg] = useState('');
  const [copiedUri, setCopiedUri] = useState('');
  const [error, setError] = useState('');

  const isElectron = Boolean(window.api?.isElectron);

  const load = useCallback(async () => {
    if (!window.api) return;
    const [list, dir, cloudSettings, savedIds] = await Promise.all([
      window.api.listAutoBackups(),
      window.api.autoBackupFolder(),
      window.api.getCloudBackupSettings(),
      window.api.getCloudClientIds ? window.api.getCloudClientIds() : Promise.resolve({}),
    ]);
    setBackups(list);
    setFolderPath(dir);
    setCloud(cloudSettings);
    setClientIds(savedIds);
    setDraftIds({
      ONEDRIVE: savedIds.ONEDRIVE ?? '',
      DROPBOX: savedIds.DROPBOX ?? '',
      GOOGLE_DRIVE: savedIds.GOOGLE_DRIVE ?? '',
    });
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const handleCompleted = (payload: { provider: string; accountEmail: string | null }) => {
      setCloudStatusMsg(
        `Connected to ${payload.provider.replace('_', ' ')}${payload.accountEmail ? ` (${payload.accountEmail})` : ''}! Click Sync Now or Pull from Cloud anytime.`,
      );
      setError('');
      void load();
    };
    const domListener = (e: Event) => {
      const detail = (e as CustomEvent<{ provider: string; accountEmail: string | null }>).detail;
      if (detail) handleCompleted(detail);
    };
    window.addEventListener('carbiz:oauth-completed', domListener);
    const unsubIpc = window.api?.onCloudOAuthCompleted?.(handleCompleted);
    return () => {
      window.removeEventListener('carbiz:oauth-completed', domListener);
      unsubIpc?.();
    };
  }, [load]);

  async function doRestore(chosenPath?: string) {
    if (!window.api) return;
    setBusy(true);
    setError('');
    try {
      const res = await window.api.restoreFromBackup(chosenPath);
      setConfirmTarget(null);
      if (res.restored) {
        onRestored(`Restored ${res.count ?? 0} car records from ${res.sourceName ?? 'backup'}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setConfirmTarget(null);
    } finally {
      setBusy(false);
    }
  }

  async function handleSaveClientId(provider: OAuthCloudProvider) {
    if (!window.api?.saveCloudClientId) return;
    setSavingId(true);
    setError('');
    setCloudStatusMsg('');
    try {
      const updatedIds = await window.api.saveCloudClientId(provider, draftIds[provider] ?? '');
      setClientIds(updatedIds);
      setCloudStatusMsg(`${PROVIDER_META[provider].label} ID saved! You can now click Connect ${PROVIDER_META[provider].shortLabel}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSavingId(false);
    }
  }

  async function handleConnectProvider(provider: OAuthCloudProvider) {
    if (!window.api?.connectCloudProvider) return;
    setError('');
    setCloudStatusMsg('');
    const candidateId = (draftIds[provider] || clientIds[provider] || '').trim();
    if (!candidateId) {
      setActiveProviderTab(provider);
      setShowSetupBox(true);
      setError(`Paste your ${PROVIDER_META[provider].idLabel} below first, then click Connect ${PROVIDER_META[provider].shortLabel}.`);
      return;
    }
    try {
      const updated = await window.api.connectCloudProvider(provider, candidateId);
      setCloud(updated);
      await load();
      setCloudStatusMsg(
        `Browser opened for ${PROVIDER_META[provider].label} sign-in. Complete login in your browser to finish linking.`,
      );
    } catch (err) {
      setActiveProviderTab(provider);
      setShowSetupBox(true);
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  async function handlePickCloudFolder() {
    if (!window.api) return;
    setError('');
    const updated = await window.api.pickCloudBackupFolder();
    setCloud(updated);
    if (updated.cloud_backup_dir) {
      await handleSyncNow();
    }
  }

  async function handleClearCloudFolder() {
    if (!window.api) return;
    const updated = window.api.disconnectCloudProvider
      ? await window.api.disconnectCloudProvider()
      : await window.api.clearCloudBackupFolder();
    setCloud(updated);
    setCloudStatusMsg('Cloud account unlinked.');
  }

  async function handleSyncNow() {
    if (!window.api) return;
    setSyncingCloud(true);
    setError('');
    setCloudStatusMsg('');
    try {
      const res = await window.api.syncBackupNow();
      await load();
      if (res.synced) {
        setCloudStatusMsg(
          res.cloudPath
            ? `Saved local backup first & synced live to ${res.cloudPath}!`
            : 'Saved local backup snapshot to device storage!',
        );
      } else if (res.error) {
        setError(res.error);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSyncingCloud(false);
    }
  }

  async function handlePullFromCloud() {
    if (!window.api?.pullLatestFromCloud) return;
    setPullingCloud(true);
    setError('');
    setCloudStatusMsg('');
    try {
      const res = await window.api.pullLatestFromCloud();
      if (res.restored) {
        onRestored(res.message ?? `Synced ${res.count ?? 0} car records from cloud!`);
      } else if (res.error) {
        setError(res.error);
      } else if (res.message) {
        setCloudStatusMsg(res.message);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setPullingCloud(false);
    }
  }

  async function handleShareMobileZip() {
    if (!window.api?.exportBrowserZipBlob) return;
    setBusy(true);
    setError('');
    try {
      const { blob, filename } = await window.api.exportBrowserZipBlob();
      const file = new File([blob], filename, { type: 'application/zip' });
      const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
      if (typeof nav.share === 'function' && (!nav.canShare || nav.canShare({ files: [file] }))) {
        await nav.share({
          files: [file],
          title: 'Car Deals Full Backup',
          text: 'Showroom ledger & vehicle document archive (.zip)',
        });
        setCloudStatusMsg('Backup shared successfully.');
      } else {
        onManualBackup('zip');
      }
    } catch (err) {
      if ((err as { name?: string })?.name !== 'AbortError') {
        onManualBackup('zip');
      }
    } finally {
      setBusy(false);
    }
  }

  async function handleBrowserFileRestore(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !window.api?.importBrowserZipFile) return;
    setBusy(true);
    setError('');
    try {
      const res = await window.api.importBrowserZipFile(file);
      if (res.restored) {
        onRestored(`Restored ${res.count} car records from ${res.sourceName}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  function copyText(value: string, label: string) {
    void navigator.clipboard?.writeText(value);
    setCopiedUri(label);
    setTimeout(() => setCopiedUri(''), 2000);
  }

  const currentRedirectUri = getOAuthRedirectUri();
  const isOAuthConnected =
    cloud.provider === 'ONEDRIVE' || cloud.provider === 'DROPBOX' || cloud.provider === 'GOOGLE_DRIVE';

  return (
    <>
      <Modal
        title="Backups, Cloud Sync & Restore"
        subtitle="Local-first storage always saves a full .zip backup on your device first, then syncs car-deals-live-sync.zip to OneDrive, Dropbox, or Google Drive."
        onClose={onClose}
        width="max-w-3xl"
        footer={
          <>
            {isElectron && folderPath && (
              <button
                type="button"
                className="btn btn-secondary sm:mr-auto"
                onClick={() => void window.api?.showInFolder(folderPath)}
              >
                Open Backup Folder
              </button>
            )}
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Close
            </button>
          </>
        }
      >
        {error && (
          <div className="mb-3 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
        )}
        {cloudStatusMsg && (
          <div className="mb-3 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
            {cloudStatusMsg}
          </div>
        )}

        {/* Unified Cloud Account & Switcher Card (Works in both Windows .exe and Android .apk without rebuilding) */}
        <div className="mb-5 rounded-xl border border-indigo-200 bg-indigo-50/50 p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-800">
                  Cloud Sync Account (OneDrive / Dropbox / Google Drive)
                </span>
                <button
                  type="button"
                  onClick={() => setShowSetupBox((v) => !v)}
                  className="rounded-full border border-indigo-300 bg-white px-2.5 py-0.5 text-[11px] font-semibold text-indigo-700 hover:bg-indigo-100"
                >
                  {showSetupBox ? 'Hide App IDs & Guide' : 'Configure App IDs / Switch Account'}
                </button>
              </div>

              <p className="mt-1 text-xs text-indigo-900/80">
                Connect your cloud account directly inside the app — switch between <strong>OneDrive</strong>,{' '}
                <strong>Dropbox</strong>, or <strong>Google Drive</strong> anytime on both your Laptop (.exe) and Mobile (.apk).
              </p>

              {cloud.cloud_backup_dir ? (
                <div className="mt-2.5 rounded-lg border border-indigo-200/80 bg-white px-3 py-2 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-semibold text-indigo-950">{cloud.cloud_backup_dir}</span>
                    <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold uppercase text-emerald-800">
                      Connected
                    </span>
                  </div>
                  <div className="mt-0.5 text-indigo-700">
                    {cloud.last_synced_at
                      ? `Last cloud sync: ${new Date(cloud.last_synced_at).toLocaleString()}`
                      : 'Ready — click Sync Now to push latest deals or Pull from Cloud to load from other device'}
                  </div>
                  {cloud.last_error && <div className="mt-1 font-semibold text-red-700">Error: {cloud.last_error}</div>}
                </div>
              ) : (
                <div className="mt-2 text-xs font-medium text-indigo-700">
                  No cloud account linked yet. Pick a provider below to connect:
                </div>
              )}
            </div>
          </div>

          {/* One-Click Connect / Switch Buttons (Available on BOTH Desktop .exe & Mobile .apk) */}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            {(['ONEDRIVE', 'DROPBOX', 'GOOGLE_DRIVE'] as OAuthCloudProvider[]).map((p) => {
              const isCurrent = cloud.provider === p;
              const hasId = Boolean((draftIds[p] || clientIds[p] || '').trim());
              return (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    setActiveProviderTab(p);
                    void handleConnectProvider(p);
                  }}
                  className={`btn btn-sm ${
                    isCurrent
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                      : 'btn-secondary'
                  }`}
                >
                  {isCurrent
                    ? `✓ ${PROVIDER_META[p].shortLabel} Connected`
                    : `Connect ${PROVIDER_META[p].shortLabel}${hasId ? '' : ' (Add ID)'}`}
                </button>
              );
            })}

            {isElectron && (
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => void handlePickCloudFolder()}
              >
                {cloud.provider === 'LOCAL_FOLDER' ? 'Change Sync Folder' : 'Or Link Local Sync Folder'}
              </button>
            )}
          </div>

          {/* Active Sync Actions */}
          {cloud.cloud_backup_dir && (
            <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-indigo-200/70 pt-3">
              <button
                type="button"
                disabled={syncingCloud}
                className="btn btn-primary btn-sm"
                onClick={() => void handleSyncNow()}
              >
                {syncingCloud ? 'Syncing…' : 'Sync Now (Push to Cloud)'}
              </button>
              {isOAuthConnected && (
                <button
                  type="button"
                  disabled={pullingCloud}
                  className="btn btn-secondary btn-sm"
                  onClick={() => void handlePullFromCloud()}
                >
                  {pullingCloud ? 'Pulling…' : 'Pull from Cloud (Load Other Device)'}
                </button>
              )}
              <button
                type="button"
                className="btn btn-secondary btn-sm text-red-600 hover:bg-red-50"
                onClick={() => void handleClearCloudFolder()}
              >
                Disconnect
              </button>
            </div>
          )}

          {/* In-App Client ID / App Key Manager + Redirect URI Helper */}
          {showSetupBox && (
            <div className="mt-4 rounded-lg border border-indigo-200 bg-white p-3.5 text-xs text-ink-700">
              <div className="mb-2.5 flex flex-wrap items-center justify-between gap-2 border-b border-ink-100 pb-2">
                <span className="font-bold text-ink-900">
                  In-App Cloud App ID Setup (Saved Permanently — No Rebuild Required)
                </span>
                <div className="flex gap-1">
                  {(['ONEDRIVE', 'DROPBOX', 'GOOGLE_DRIVE'] as OAuthCloudProvider[]).map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setActiveProviderTab(p)}
                      className={`rounded px-2.5 py-1 text-[11px] font-semibold ${
                        activeProviderTab === p
                          ? 'bg-indigo-600 text-white'
                          : 'bg-ink-100 text-ink-600 hover:bg-ink-200'
                      }`}
                    >
                      {PROVIDER_META[p].shortLabel}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="mb-1 block font-semibold text-ink-900">
                    {PROVIDER_META[activeProviderTab].idLabel}
                  </label>
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <input
                      type="text"
                      value={draftIds[activeProviderTab]}
                      onChange={(e) =>
                        setDraftIds((prev) => ({ ...prev, [activeProviderTab]: e.target.value }))
                      }
                      placeholder={PROVIDER_META[activeProviderTab].placeholder}
                      className="input flex-1 font-mono text-xs"
                    />
                    <button
                      type="button"
                      disabled={savingId}
                      onClick={() => void handleSaveClientId(activeProviderTab)}
                      className="btn btn-secondary btn-sm whitespace-nowrap"
                    >
                      {savingId ? 'Saving…' : 'Save ID'}
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleConnectProvider(activeProviderTab)}
                      className="btn btn-primary btn-sm whitespace-nowrap"
                    >
                      Save &amp; Sign In
                    </button>
                  </div>
                  <div className="mt-1 text-[11px] text-ink-500">
                    Where to copy it: <strong>{PROVIDER_META[activeProviderTab].portalHint}</strong>
                  </div>
                </div>

                {/* Redirect URIs to register once in Azure / Dropbox / Google */}
                <div className="rounded-lg border border-ink-200 bg-ink-50 p-2.5">
                  <div className="font-semibold text-ink-900">
                    Redirect URIs to add once in your {PROVIDER_META[activeProviderTab].shortLabel} App Settings:
                  </div>
                  <div className="mt-1.5 space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-2 rounded bg-white px-2.5 py-1.5 border border-ink-200">
                      <div>
                        <span className="font-semibold text-ink-700">Windows Laptop (.exe): </span>
                        <code className="font-mono text-[11px] text-indigo-700">{ELECTRON_OAUTH_REDIRECT_URI}</code>
                      </div>
                      <button
                        type="button"
                        onClick={() => copyText(ELECTRON_OAUTH_REDIRECT_URI, 'win')}
                        className="rounded bg-indigo-50 px-2 py-0.5 text-[11px] font-semibold text-indigo-700 hover:bg-indigo-100"
                      >
                        {copiedUri === 'win' ? 'Copied!' : 'Copy'}
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 rounded bg-white px-2.5 py-1.5 border border-ink-200">
                      <div>
                        <span className="font-semibold text-ink-700">Android Mobile (.apk): </span>
                        <code className="font-mono text-[11px] text-indigo-700">{MOBILE_OAUTH_REDIRECT_URI}</code>
                      </div>
                      <button
                        type="button"
                        onClick={() => copyText(MOBILE_OAUTH_REDIRECT_URI, 'apk')}
                        className="rounded bg-indigo-50 px-2 py-0.5 text-[11px] font-semibold text-indigo-700 hover:bg-indigo-100"
                      >
                        {copiedUri === 'apk' ? 'Copied!' : 'Copy'}
                      </button>
                    </div>

                    {!isElectron && currentRedirectUri !== MOBILE_OAUTH_REDIRECT_URI && (
                      <div className="flex flex-wrap items-center justify-between gap-2 rounded bg-white px-2.5 py-1.5 border border-ink-200">
                        <div>
                          <span className="font-semibold text-ink-700">Current Web Origin: </span>
                          <code className="font-mono text-[11px] text-indigo-700">{currentRedirectUri}</code>
                        </div>
                        <button
                          type="button"
                          onClick={() => copyText(currentRedirectUri, 'web')}
                          className="rounded bg-indigo-50 px-2 py-0.5 text-[11px] font-semibold text-indigo-700 hover:bg-indigo-100"
                        >
                          {copiedUri === 'web' ? 'Copied!' : 'Copy'}
                        </button>
                      </div>
                    )}
                  </div>

                  {activeProviderTab === 'ONEDRIVE' && (
                    <p className="mt-2 text-[11px] text-ink-600">
                      <strong>OneDrive Permissions:</strong> In Azure App Registration → <em>API permissions</em>, add Microsoft Graph delegated{' '}
                      <code className="font-mono">Files.ReadWrite.AppFolder</code>, <code className="font-mono">User.Read</code>, and{' '}
                      <code className="font-mono">offline_access</code>. Under <em>Authentication</em>, add both URIs above under{' '}
                      <strong>Mobile and desktop applications</strong>.
                    </p>
                  )}
                  {activeProviderTab === 'DROPBOX' && (
                    <p className="mt-2 text-[11px] text-ink-600">
                      <strong>Dropbox Permissions:</strong> In Dropbox App Console → <em>Permissions</em>, enable{' '}
                      <code className="font-mono">files.content.write</code>, <code className="font-mono">files.content.read</code>, and{' '}
                      <code className="font-mono">account_info.read</code>, then click Submit. Under <em>Settings → Redirect URIs</em>, add both URIs above.
                    </p>
                  )}
                  {activeProviderTab === 'GOOGLE_DRIVE' && (
                    <p className="mt-2 text-[11px] text-ink-600">
                      <strong>Google Drive Scope:</strong> Enable <strong>Google Drive API</strong> in Google Cloud Console, create an OAuth Client ID, and add the Redirect URI above.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {isElectron ? (
          <>
            {/* Quick Manual Export & Restore Actions */}
            <div className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-4">
              <button
                type="button"
                className="rounded-lg border border-emerald-200 bg-emerald-50/70 p-3.5 text-left transition hover:border-emerald-400 hover:bg-emerald-50"
                onClick={() => onManualBackup('zip')}
              >
                <div className="text-sm font-semibold text-emerald-900">Full Backup (.zip)</div>
                <div className="mt-0.5 text-xs text-emerald-700">Database + all CNICs &amp; docs</div>
              </button>

              <button
                type="button"
                className="rounded-lg border border-ink-200 bg-ink-50 p-3.5 text-left transition hover:border-brand-400 hover:bg-brand-50/40"
                onClick={() => onManualBackup('db')}
              >
                <div className="text-sm font-semibold text-ink-900">Database Only (.db)</div>
                <div className="mt-0.5 text-xs text-ink-500">Lightweight SQLite snapshot</div>
              </button>

              <button
                type="button"
                className="rounded-lg border border-ink-200 bg-ink-50 p-3.5 text-left transition hover:border-brand-400 hover:bg-brand-50/40"
                onClick={() => onManualBackup('csv')}
              >
                <div className="text-sm font-semibold text-ink-900">Export Excel (.csv)</div>
                <div className="mt-0.5 text-xs text-ink-500">Costs, payments &amp; profit sheet</div>
              </button>

              <button
                type="button"
                className="rounded-lg border border-brand-200 bg-brand-50 p-3.5 text-left transition hover:bg-brand-100/70"
                onClick={() => setConfirmTarget({ label: 'a chosen backup file' })}
              >
                <div className="text-sm font-semibold text-brand-700">Restore Backup…</div>
                <div className="mt-0.5 text-xs text-brand-600">Pick any .zip or .db backup</div>
              </button>
            </div>

            <div className="mb-2 flex items-center justify-between gap-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-ink-500">
                Recent Automatic Backups ({backups.length}/30)
              </h3>
              {folderPath && <span className="truncate font-mono text-[11px] text-ink-400">{folderPath}</span>}
            </div>

            <div className="overflow-x-auto rounded-lg border border-ink-200">
              <table className="w-full text-sm">
                <thead className="bg-ink-50 text-left text-xs uppercase tracking-wide text-ink-500">
                  <tr>
                    <th className="px-3.5 py-2 font-semibold">Backup File</th>
                    <th className="px-3.5 py-2 font-semibold">Contents</th>
                    <th className="px-3.5 py-2 font-semibold">Created</th>
                    <th className="px-3.5 py-2 text-right font-semibold">Size</th>
                    <th className="px-3.5 py-2 text-right font-semibold">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-100">
                  {backups.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-3.5 py-8 text-center text-ink-500">
                        No automatic backups yet — one is created automatically in your Documents folder on startup &amp; close.
                      </td>
                    </tr>
                  ) : (
                    backups.map((b) => (
                      <tr key={b.path} className="hover:bg-ink-50/70">
                        <td className="px-3.5 py-2.5 font-mono text-xs font-medium text-ink-900">{b.name}</td>
                        <td className="px-3.5 py-2.5 text-xs">
                          <span
                            className={`rounded px-1.5 py-0.5 text-[10px] font-bold uppercase ${
                              b.kind === 'zip' ? 'bg-emerald-50 text-emerald-700' : 'bg-ink-100 text-ink-600'
                            }`}
                          >
                            {b.kind === 'zip' ? 'DB + Docs' : 'DB Only'}
                          </span>
                        </td>
                        <td className="px-3.5 py-2.5 text-xs text-ink-600">{new Date(b.mtime).toLocaleString()}</td>
                        <td className="px-3.5 py-2.5 text-right text-xs tabular-nums text-ink-500">{fmtSize(b.size)}</td>
                        <td className="px-3.5 py-2.5 text-right">
                          <button
                            type="button"
                            className="btn btn-secondary btn-sm text-brand-700 hover:bg-brand-50"
                            onClick={() => setConfirmTarget({ path: b.path, label: b.name })}
                          >
                            Restore
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          /* Web & Mobile Backup / Share / Restore UI */
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <button
                type="button"
                disabled={busy}
                className="rounded-xl border border-emerald-200 bg-emerald-50/80 p-4 text-left transition hover:border-emerald-400 hover:bg-emerald-50"
                onClick={() => onManualBackup('zip')}
              >
                <div className="text-sm font-bold text-emerald-900">Save Local &amp; Download (.zip)</div>
                <div className="mt-1 text-xs text-emerald-700">
                  Saves to device storage first &amp; exports complete ledger + vehicle photos
                </div>
              </button>

              <button
                type="button"
                disabled={busy}
                className="rounded-xl border border-indigo-200 bg-indigo-50/80 p-4 text-left transition hover:border-indigo-400 hover:bg-indigo-50"
                onClick={() => void handleShareMobileZip()}
              >
                <div className="text-sm font-bold text-indigo-900">Share Backup to Drive / WhatsApp</div>
                <div className="mt-1 text-xs text-indigo-700">
                  1-tap mobile share sheet to send .zip to OneDrive, Dropbox, or Laptop
                </div>
              </button>

              <button
                type="button"
                disabled={busy}
                className="rounded-xl border border-ink-200 bg-ink-50 p-4 text-left transition hover:border-brand-400 hover:bg-brand-50/40"
                onClick={() => onManualBackup('csv')}
              >
                <div className="text-sm font-bold text-ink-900">Export Excel Spreadsheet (.csv)</div>
                <div className="mt-1 text-xs text-ink-500">All vehicles, costs, payments &amp; net profit</div>
              </button>

              <label className="cursor-pointer rounded-xl border border-brand-200 bg-brand-50 p-4 text-left transition hover:bg-brand-100/70">
                <div className="text-sm font-bold text-brand-700">Restore from Laptop/Mobile .zip</div>
                <div className="mt-1 text-xs text-brand-600">
                  Import a saved backup archive from phone storage or cloud drive
                </div>
                <input
                  type="file"
                  accept=".zip,.json"
                  className="hidden"
                  onChange={(e) => void handleBrowserFileRestore(e)}
                />
              </label>
            </div>
          </div>
        )}
      </Modal>

      {confirmTarget && (
        <ConfirmDialog
          title="Restore from backup?"
          tone="primary"
          confirmLabel="Restore Now"
          busy={busy}
          onCancel={() => setConfirmTarget(null)}
          onConfirm={() => void doRestore(confirmTarget.path)}
          message={
            <>
              <p>
                Your current records will be replaced with <strong>{confirmTarget.label}</strong>.
              </p>
              <p className="mt-2 text-ink-500">
                A full safety snapshot (.zip) of your current database and documents will be saved automatically first.
              </p>
            </>
          }
        />
      )}
    </>
  );
}
