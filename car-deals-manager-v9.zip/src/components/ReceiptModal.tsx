import { useEffect, useMemo, useState } from 'react';
import Modal, { Field } from './Modal';
import MoneyInput from './MoneyInput';
import type { BusinessProfile, DealWithTotals, Payment } from '../types';
import { DEFAULT_BUSINESS_PROFILE } from '../types';
import { buildReceiptHtml, type BayanaForfeitMode, type ReceiptKind } from '../receiptBuilder';
import { carTitle, formatCnic, formatPhone, moneyToInput, normalizeReg, parseNum, regOf, todayISO } from '../utils';

interface Props {
  deal: DealWithTotals;
  initialKind?: ReceiptKind;
  onClose: () => void;
  onSavedPdf: (path: string) => void;
}

export default function ReceiptModal({ deal, initialKind, onClose, onSavedPdf }: Props) {
  const defaultKind: ReceiptKind =
    initialKind ?? (deal.status === 'SOLD' ? 'sale' : deal.status === 'RESERVED' ? 'bayana' : 'buying');

  const [kind, setKind] = useState<ReceiptKind>(defaultKind);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [profile, setProfile] = useState<BusinessProfile>(DEFAULT_BUSINESS_PROFILE);
  const [editingOurDetails, setEditingOurDetails] = useState(false);

  // Sale / Purchase options
  const [vehicleType, setVehicleType] = useState<'Motor Cycle' | 'Scooter' | 'Car' | 'Bus'>('Car');
  const [paymentModeOverride, setPaymentModeOverride] = useState('');
  const [includeTikliNote, setIncludeTikliNote] = useState(true);
  const [extraTerms, setExtraTerms] = useState('');

  // Bayana options
  const [bayanaTokenAmount, setBayanaTokenAmount] = useState(moneyToInput(deal.reserved_token_amount));
  const [bayanaAgreedPrice, setBayanaAgreedPrice] = useState(moneyToInput(deal.sale_price));
  const [bayanaHoldDate, setBayanaHoldDate] = useState(deal.reserved_date ?? todayISO());
  const [bayanaExpiryDate, setBayanaExpiryDate] = useState(deal.reserved_expiry_date ?? '');
  const [bayanaBuyerName, setBayanaBuyerName] = useState(deal.reserved_buyer_name ?? deal.purchaser_name ?? '');
  const [bayanaBuyerContact, setBayanaBuyerContact] = useState(deal.reserved_buyer_contact ?? deal.purchaser_contact ?? '');
  const [bayanaForfeitMode, setBayanaForfeitMode] = useState<BayanaForfeitMode>('NON_REFUNDABLE');

  // Window Spec Card options (STRICTLY ZERO purchase price/cost/profit)
  const [askingPrice, setAskingPrice] = useState(moneyToInput(deal.sale_price));
  const [specShowMileage, setSpecShowMileage] = useState(true);
  const [specHighlightNote, setSpecHighlightNote] = useState('');

  const [saving, setSaving] = useState(false);
  const [profileSavedMsg, setProfileSavedMsg] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!window.api) return;
    void Promise.all([window.api.listPayments(deal.id), window.api.getBusinessProfile()]).then(([p, prof]) => {
      setPayments(p);
      setProfile({ ...DEFAULT_BUSINESS_PROFILE, ...prof });
      const tokenSum = p.filter((x) => x.direction === 'IN_FROM_BUYER' && x.payment_type === 'Token').reduce((s, x) => s + x.amount, 0);
      if (!deal.reserved_token_amount && tokenSum > 0) {
        setBayanaTokenAmount(moneyToInput(tokenSum));
      }
    });
  }, [deal.id, deal.reserved_token_amount]);

  const html = useMemo(
    () =>
      buildReceiptHtml({
        kind,
        deal,
        payments,
        profile,
        paymentModeOverride,
        vehicleType,
        includeTikliNote,
        extraTerms,
        bayanaTokenAmount: parseNum(bayanaTokenAmount),
        bayanaAgreedPrice: parseNum(bayanaAgreedPrice),
        bayanaHoldDate,
        bayanaExpiryDate,
        bayanaBuyerName,
        bayanaBuyerContact,
        bayanaForfeitMode,
        askingPrice: parseNum(askingPrice),
        specShowMileage,
        specHighlightNote,
      }),
    [
      kind,
      deal,
      payments,
      profile,
      paymentModeOverride,
      vehicleType,
      includeTikliNote,
      extraTerms,
      bayanaTokenAmount,
      bayanaAgreedPrice,
      bayanaHoldDate,
      bayanaExpiryDate,
      bayanaBuyerName,
      bayanaBuyerContact,
      bayanaForfeitMode,
      askingPrice,
      specShowMileage,
      specHighlightNote,
    ],
  );

  async function saveOurDetails() {
    if (!window.api) return;
    const saved = await window.api.setBusinessProfile(profile);
    setProfile({ ...DEFAULT_BUSINESS_PROFILE, ...saved });
    setProfileSavedMsg('Saved! These details will auto-fill future receipts.');
    setTimeout(() => setProfileSavedMsg(''), 3000);
    setEditingOurDetails(false);
  }

  async function exportPdf() {
    if (!window.api) return;
    setSaving(true);
    setError('');
    try {
      const regSlug = normalizeReg(deal.registration_number) || `car-${deal.id}`;
      const filenameMap: Record<ReceiptKind, string> = {
        buying: `Purchase-Receipt-Delivery-${regSlug}.pdf`,
        sale: `Sale-Receipt-Delivery-${regSlug}.pdf`,
        bayana: `Bayana-Token-Receipt-${regSlug}.pdf`,
        spec_card: `Showroom-Spec-Card-${regSlug}.pdf`,
      };
      const res = await window.api.saveReceiptPdf(html, filenameMap[kind]);
      if (res.saved && res.path) {
        onSavedPdf(res.path);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  }

  async function printNow() {
    if (!window.api) return;
    await window.api.printReceiptHtml(html);
  }

  const missingFields: string[] = [];
  if (kind === 'sale' || kind === 'buying') {
    if (!deal.horse_power) missingFields.push('Horse Power');
    if (kind === 'sale') {
      if (!deal.purchaser_father_name) missingFields.push('Purchaser S/O');
      if (!deal.purchaser_address) missingFields.push('Purchaser R/O Address');
      if (!deal.purchaser_cnic) missingFields.push('Purchaser CNIC');
    } else {
      if (!deal.seller_father_name) missingFields.push('Seller S/O');
      if (!deal.seller_address) missingFields.push('Seller R/O Address');
      if (!deal.seller_cnic) missingFields.push('Seller CNIC');
    }
  }

  const isElectron = Boolean(window.api?.isElectron);

  const kindMeta: Record<ReceiptKind, { tab: string; cta: string; previewTitle: string }> = {
    buying: {
      tab: 'Purchase Receipt',
      cta: 'Save Purchase PDF',
      previewTitle: 'A4 Print Preview — Purchase Receipt & Delivery Letter',
    },
    sale: {
      tab: 'Sale Receipt',
      cta: 'Save Sale PDF',
      previewTitle: 'A4 Print Preview — Sale Receipt & Delivery Letter',
    },
    bayana: {
      tab: 'Bayana / Token Receipt',
      cta: 'Save Bayana PDF',
      previewTitle: 'A4 Print Preview — Bayana / Token Hold Receipt',
    },
    spec_card: {
      tab: 'Window Spec Card',
      cta: 'Save Spec Card PDF',
      previewTitle: 'A4 Print Preview — Showroom Window Spec Sheet (Cost-Free)',
    },
  };

  return (
    <Modal
      title="Showroom Paperwork & PDFs"
      subtitle={`${carTitle(deal)} · ${regOf(deal)}`}
      onClose={onClose}
      width="max-w-5xl"
      footer={
        <>
          <button
            type="button"
            className="btn btn-secondary sm:mr-auto"
            onClick={() => setEditingOurDetails((v) => !v)}
          >
            {editingOurDetails
              ? 'Hide Showroom Details'
              : profile.owner_name.trim()
                ? `Edit Showroom Details (${profile.owner_name.trim()})`
                : 'Configure Showroom Details'}
          </button>
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Close
          </button>
          <button type="button" className="btn btn-secondary" onClick={() => void printNow()}>
            Print / Save PDF
          </button>
          {isElectron && (
            <button type="button" className="btn btn-primary" disabled={saving} onClick={() => void exportPdf()}>
              {saving ? 'Generating PDF…' : kindMeta[kind].cta}
            </button>
          )}
        </>
      }
    >
      {error && (
        <div className="mb-3 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
      )}
      {profileSavedMsg && (
        <div className="mb-3 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
          {profileSavedMsg}
        </div>
      )}

      {/* Document Type Switcher */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-ink-200 bg-ink-50 p-3">
        <div className="flex flex-wrap gap-1.5">
          {(['buying', 'sale', 'bayana', 'spec_card'] as ReceiptKind[]).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setKind(k)}
              className={`min-h-[36px] rounded-md border px-3 py-1.5 text-xs font-semibold transition ${
                kind === k
                  ? 'border-brand-600 bg-brand-600 text-white shadow-xs'
                  : 'border-ink-300 bg-white text-ink-700 hover:bg-ink-100'
              }`}
            >
              {kindMeta[k].tab}
            </button>
          ))}
        </div>

        <div className="text-xs text-ink-600">
          Identity:{' '}
          {profile.owner_name.trim() || profile.business_name.trim() ? (
            <strong>{profile.business_name.trim() || profile.owner_name.trim()}</strong>
          ) : (
            <button
              type="button"
              onClick={() => setEditingOurDetails(true)}
              className="font-semibold text-brand-700 underline"
            >
              Set showroom name &amp; CNIC
            </button>
          )}
        </div>
      </div>

      {!profile.owner_name.trim() && !editingOurDetails && kind !== 'spec_card' && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-md border border-blue-200 bg-blue-50 px-3 py-2 text-xs text-blue-900">
          <span>
            Your dealership/owner details are blank on receipts. Click <strong>Configure Showroom Details</strong> once to auto-fill.
          </span>
          <button
            type="button"
            onClick={() => setEditingOurDetails(true)}
            className="shrink-0 rounded border border-blue-300 bg-white px-2.5 py-1 font-semibold text-blue-800 hover:bg-blue-100"
          >
            Set Up Now
          </button>
        </div>
      )}

      {missingFields.length > 0 && (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
          <strong>Missing fields on this deal:</strong> {missingFields.join(', ')}.
        </div>
      )}

      {/* Editable Showroom / Owner Details */}
      {editingOurDetails && (
        <div className="mb-4 rounded-lg border border-brand-200 bg-brand-50/50 p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-brand-700">
                Showroom &amp; Owner Details
              </span>
              <p className="text-[11px] text-ink-500">
                Auto-fills Purchase/Sale receipts, Bayana tokens, and Window Spec Cards.
              </p>
            </div>
            <button type="button" className="btn btn-primary btn-sm" onClick={() => void saveOurDetails()}>
              Save Details
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-6">
            <Field label="Full Name" className="sm:col-span-2">
              <input
                className="input"
                value={profile.owner_name}
                onChange={(e) => setProfile((p) => ({ ...p, owner_name: e.target.value }))}
                placeholder="Your full name"
              />
            </Field>
            <Field label="S/O (Father's Name)" className="sm:col-span-2">
              <input
                className="input"
                value={profile.father_name}
                onChange={(e) => setProfile((p) => ({ ...p, father_name: e.target.value }))}
                placeholder="Father's name"
              />
            </Field>
            <Field label="Mobile Number" className="sm:col-span-2">
              <input
                className="input"
                value={profile.phone}
                onChange={(e) => setProfile((p) => ({ ...p, phone: formatPhone(e.target.value) }))}
                placeholder="03xx-xxxxxxx"
              />
            </Field>
            <Field label="CNIC Number" className="sm:col-span-2">
              <input
                className="input"
                value={profile.cnic}
                onChange={(e) => setProfile((p) => ({ ...p, cnic: formatCnic(e.target.value) }))}
                placeholder="xxxxx-xxxxxxx-x"
              />
            </Field>
            <Field label="Showroom / Office Address" className="sm:col-span-4">
              <input
                className="input"
                value={profile.address}
                onChange={(e) => setProfile((p) => ({ ...p, address: e.target.value }))}
                placeholder="Showroom / residential address"
              />
            </Field>
            <Field label="Showroom Banner Title" className="sm:col-span-3">
              <input
                className="input"
                value={profile.business_name}
                onChange={(e) => setProfile((p) => ({ ...p, business_name: e.target.value }))}
                placeholder="Showroom name"
              />
            </Field>
            <Field label="Tagline" className="sm:col-span-3">
              <input
                className="input"
                value={profile.tagline}
                onChange={(e) => setProfile((p) => ({ ...p, tagline: e.target.value }))}
                placeholder="Optional subtitle"
              />
            </Field>
          </div>
        </div>
      )}

      {/* Template-Specific Options */}
      {(kind === 'buying' || kind === 'sale') && (
        <div className="mb-4 grid grid-cols-1 gap-3 rounded-lg border border-ink-200 bg-white p-3 sm:grid-cols-6">
          <Field label="Vehicle Type" className="sm:col-span-2">
            <select
              className="input"
              value={vehicleType}
              onChange={(e) => setVehicleType(e.target.value as typeof vehicleType)}
            >
              <option value="Car">Car</option>
              <option value="Motor Cycle">Motor Cycle</option>
              <option value="Scooter">Scooter</option>
              <option value="Bus">Bus</option>
            </select>
          </Field>
          <Field label="Cash / Cheque No. (auto-fills from Payments if blank)" className="sm:col-span-4">
            <input
              className="input"
              value={paymentModeOverride}
              onChange={(e) => setPaymentModeOverride(e.target.value)}
              placeholder="e.g. Cash / Cheque No. 458912 (Meezan Bank)"
            />
          </Field>
          <Field label="Optional Remarks at Bottom" className="sm:col-span-4">
            <input
              className="input"
              value={extraTerms}
              onChange={(e) => setExtraTerms(e.target.value)}
              placeholder="Optional extra note"
            />
          </Field>
          <div className="flex items-end pb-1 sm:col-span-2">
            <label className="flex cursor-pointer items-center gap-2 text-xs font-medium text-ink-700">
              <input
                type="checkbox"
                className="h-4 w-4 rounded border-ink-300 text-brand-600"
                checked={includeTikliNote}
                onChange={(e) => setIncludeTikliNote(e.target.checked)}
              />
              Original file, tikli &amp; plates note
            </label>
          </div>
        </div>
      )}

      {kind === 'bayana' && (
        <div className="mb-4 grid grid-cols-1 gap-3 rounded-lg border border-amber-200 bg-amber-50/40 p-3 sm:grid-cols-6">
          <Field label="Token / Bayana Amount (Rs)" className="sm:col-span-2">
            <MoneyInput value={bayanaTokenAmount} onChange={setBayanaTokenAmount} placeholder="100,000" />
          </Field>
          <Field label="Agreed Total Price (Rs, optional)" className="sm:col-span-2">
            <MoneyInput value={bayanaAgreedPrice} onChange={setBayanaAgreedPrice} placeholder="3,650,000" />
          </Field>
          <Field label="Forfeit / Refund Policy" className="sm:col-span-2">
            <select
              className="input"
              value={bayanaForfeitMode}
              onChange={(e) => setBayanaForfeitMode(e.target.value as BayanaForfeitMode)}
            >
              <option value="NON_REFUNDABLE">Non-Refundable if Buyer Defaults</option>
              <option value="REFUNDABLE">Refundable Inspection Hold</option>
            </select>
          </Field>
          <Field label="Token Date" className="sm:col-span-2">
            <input type="date" className="input" value={bayanaHoldDate} onChange={(e) => setBayanaHoldDate(e.target.value)} />
          </Field>
          <Field label="Hold Expiry Date" className="sm:col-span-2">
            <input type="date" className="input" value={bayanaExpiryDate} onChange={(e) => setBayanaExpiryDate(e.target.value)} />
          </Field>
          <Field label="Payment Mode / Cheque Ref" className="sm:col-span-2">
            <input
              className="input"
              value={paymentModeOverride}
              onChange={(e) => setPaymentModeOverride(e.target.value)}
              placeholder="Cash / Online / Cheque #"
            />
          </Field>
          <Field label="Prospective Buyer Name" className="sm:col-span-3">
            <input className="input" value={bayanaBuyerName} onChange={(e) => setBayanaBuyerName(e.target.value)} />
          </Field>
          <Field label="Buyer Phone" className="sm:col-span-3">
            <input
              className="input"
              value={bayanaBuyerContact}
              onChange={(e) => setBayanaBuyerContact(formatPhone(e.target.value))}
              placeholder="03xx-xxxxxxx"
            />
          </Field>
        </div>
      )}

      {kind === 'spec_card' && (
        <div className="mb-4 grid grid-cols-1 gap-3 rounded-lg border border-blue-200 bg-blue-50/40 p-3 sm:grid-cols-6">
          <div className="text-xs font-medium text-blue-900 sm:col-span-6">
            Privacy safe for showroom windshields: purchase price, repair costs, seller details, and profit are strictly excluded.
          </div>
          <Field label="Asking Price / Demand (Rs, leave blank to hide price)" className="sm:col-span-2">
            <MoneyInput value={askingPrice} onChange={setAskingPrice} placeholder="3,750,000" />
          </Field>
          <Field label="Showroom Highlight Note" className="sm:col-span-3">
            <input
              className="input"
              value={specHighlightNote}
              onChange={(e) => setSpecHighlightNote(e.target.value)}
              placeholder="e.g. Bumper-to-bumper genuine, biometric available"
            />
          </Field>
          <div className="flex items-end pb-1 sm:col-span-1">
            <label className="flex cursor-pointer items-center gap-2 text-xs font-medium text-ink-700">
              <input
                type="checkbox"
                className="h-4 w-4 rounded border-ink-300 text-brand-600"
                checked={specShowMileage}
                onChange={(e) => setSpecShowMileage(e.target.checked)}
              />
              Show km
            </label>
          </div>
        </div>
      )}

      {/* Live A4 Preview */}
      <div className="overflow-hidden rounded-lg border border-ink-300 bg-ink-100 p-2 sm:p-3">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2 px-1 text-[11px] font-semibold uppercase tracking-wide text-ink-500">
          <span>{kindMeta[kind].previewTitle}</span>
          <span>A4 Print Ready</span>
        </div>
        <iframe
          title="Receipt preview"
          srcDoc={html}
          className="h-[420px] w-full rounded border border-ink-200 bg-white shadow-sm sm:h-[520px]"
        />
      </div>
    </Modal>
  );
}