import { useEffect, useMemo, useState } from 'react';
import Modal from './Modal';
import type { AuditLogEntry, DealWithTotals } from '../types';
import { carTitle, regOf } from '../utils';

interface Props {
  deals: DealWithTotals[];
  onClose: () => void;
  onInspectDealById: (dealId: number) => void;
}

const ACTION_OPTIONS = [
  'ALL',
  'CREATE',
  'UPDATE',
  'MARK_SOLD',
  'REVERT_SALE',
  'RESERVE',
  'CANCEL_RESERVE',
  'ADD_PAYMENT',
  'UPDATE_PAYMENT',
  'DELETE_PAYMENT',
  'CHEQUE_STATUS',
  'ADD_EXPENSE',
  'UPDATE_EXPENSE',
  'DELETE_EXPENSE',
  'TRANSFER',
  'CHECKLIST',
  'SOFT_DELETE',
  'RESTORE',
  'DELETE',
] as const;

type ParsedChanges = Record<string, { from: unknown; to: unknown }>;

function parseChanges(json: string | null): ParsedChanges | null {
  if (!json) return null;
  try {
    const parsed = JSON.parse(json) as unknown;
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as ParsedChanges;
    }
  } catch {
    /* ignore */
  }
  return null;
}

function formatVal(v: unknown): string {
  if (v === null || v === undefined || v === '') return 'empty';
  if (typeof v === 'boolean') return v ? 'Yes' : 'No';
  return String(v);
}

function actionBadgeClass(action: string): string {
  if (action.includes('DELETE') || action === 'REVERT_SALE' || action === 'CANCEL_RESERVE') {
    return 'bg-red-50 text-red-700 ring-red-200';
  }
  if (action === 'CREATE' || action === 'MARK_SOLD' || action === 'RESTORE') {
    return 'bg-emerald-50 text-emerald-700 ring-emerald-200';
  }
  if (action.includes('PAYMENT') || action === 'CHEQUE_STATUS') {
    return 'bg-brand-50 text-brand-700 ring-brand-200';
  }
  return 'bg-amber-50 text-amber-800 ring-amber-200';
}

export default function AuditLogModal({ deals, onClose, onInspectDealById }: Props) {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('ALL');

  const dealMap = useMemo(() => new Map(deals.map((d) => [d.id, d])), [deals]);

  useEffect(() => {
    let alive = true;
    (async () => {
      if (!window.api) {
        if (alive) setLoading(false);
        return;
      }
      try {
        const list = await window.api.listAuditLogs(undefined, 300);
        if (alive) setLogs(list);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return logs.filter((log) => {
      if (actionFilter !== 'ALL' && log.action !== actionFilter) return false;
      if (!q) return true;
      const deal = log.deal_id ? dealMap.get(log.deal_id) : undefined;
      const hay = [
        log.action,
        log.actor_name,
        log.summary,
        log.changes_json,
        deal ? `${carTitle(deal)} ${regOf(deal)}` : '',
      ]
        .filter(Boolean)
        .join(' | ')
        .toLowerCase();
      return q.split(/\s+/).every((token) => hay.includes(token));
    });
  }, [logs, actionFilter, query, dealMap]);

  return (
    <Modal
      title="Activity Audit Log"
      subtitle="Chronological history of deal edits, deletions, expenses, payments & cheque updates"
      onClose={onClose}
      width="max-w-4xl"
      footer={
        <button type="button" className="btn btn-secondary" onClick={onClose}>
          Close
        </button>
      }
    >
      <div className="mb-4 flex flex-col gap-2.5 sm:flex-row sm:items-center">
        <input
          type="text"
          className="input flex-1 text-xs"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search user, reg #, car, amount, or change…"
        />
        <select
          className="input sm:w-52 text-xs"
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          aria-label="Filter by audit action"
        >
          {ACTION_OPTIONS.map((a) => (
            <option key={a} value={a}>
              {a === 'ALL' ? 'All Actions' : a.replace(/_/g, ' ')}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="py-12 text-center text-sm text-ink-500">Loading audit trail…</div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-ink-300 py-10 text-center text-xs text-ink-500">
          No matching activity entries recorded yet.
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((log) => {
            const deal = log.deal_id ? dealMap.get(log.deal_id) : undefined;
            const changes = parseChanges(log.changes_json);
            const changeEntries = changes ? Object.entries(changes) : [];

            return (
              <div key={log.id} className="rounded-xl border border-ink-200 bg-white p-3.5 text-xs">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ring-1 ring-inset ${actionBadgeClass(
                        log.action,
                      )}`}
                    >
                      {log.action.replace(/_/g, ' ')}
                    </span>
                    <span className="font-bold text-ink-900">{log.summary}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-ink-500">
                    {log.actor_name && (
                      <span className="rounded bg-ink-100 px-1.5 py-0.5 font-semibold text-ink-700">
                        {log.actor_name}
                      </span>
                    )}
                    <span className="tabular-nums">{new Date(log.created_at).toLocaleString()}</span>
                  </div>
                </div>

                {deal && (
                  <div className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded-lg bg-ink-50 px-2.5 py-1.5">
                    <div className="text-[11px] text-ink-700">
                      <span className="font-mono font-bold text-ink-900">{regOf(deal)}</span> · {carTitle(deal)}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onInspectDealById(deal.id);
                      }}
                      className="text-[11px] font-bold text-brand-700 hover:underline"
                    >
                      Open Car →
                    </button>
                  </div>
                )}

                {changeEntries.length > 0 && (
                  <div className="mt-2 space-y-1 rounded-lg border border-ink-100 bg-ink-50/70 p-2.5 text-[11px]">
                    {changeEntries.map(([field, diff]) => (
                      <div key={field} className="flex flex-wrap items-baseline gap-1.5">
                        <span className="font-mono font-semibold text-ink-600">{field}:</span>
                        <span className="text-red-700 line-through">{formatVal(diff?.from)}</span>
                        <span className="text-ink-400">→</span>
                        <span className="font-semibold text-emerald-700">{formatVal(diff?.to)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </Modal>
  );
}
