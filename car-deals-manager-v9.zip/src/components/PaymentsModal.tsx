import { useCallback, useEffect, useState } from 'react';
import Modal, { Field } from './Modal';
import MoneyInput from './MoneyInput';
import { PAYMENT_METHODS, PAYMENT_TYPES } from '../types';
import type { ChequeStatus, DealWithTotals, Payment, PaymentDirection, PaymentMethod, PaymentType } from '../types';
import { carTitle, daysPastDue, fmtDate, fmtMoney, moneyToInput, parseNum, regOf, textOrNull, todayISO } from '../utils';

interface Props {
  deal: DealWithTotals;
  initialTab?: PaymentDirection;
  onClose: () => void;
  onChanged: () => void;
}

export default function PaymentsModal({ deal, initialTab, onClose, onChanged }: Props) {
  const [tab, setTab] = useState<PaymentDirection>(
    initialTab ?? (deal.status === 'SOLD' || deal.status === 'RESERVED' ? 'IN_FROM_BUYER' : 'OUT_TO_SELLER'),
  );
  const [payments, setPayments] = useState<Payment[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [paymentType, setPaymentType] = useState<PaymentType>('Advance');
  const [method, setMethod] = useState<PaymentMethod>('Cash');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(todayISO());
  const [notes, setNotes] = useState('');
  const [chequeNumber, setChequeNumber] = useState('');
  const [chequeDate, setChequeDate] = useState('');
  const [chequeStatus, setChequeStatus] = useState<ChequeStatus>('PENDING');
  const [sellerDueDate, setSellerDueDate] = useState(deal.seller_due_date ?? '');
  const [buyerDueDate, setBuyerDueDate] = useState(deal.buyer_due_date ?? '');
  const [savingDue, setSavingDue] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    if (!window.api) return;
    setPayments(await window.api.listPayments(deal.id));
  }, [deal.id]);

  useEffect(() => {
    void load();
  }, [load]);

  function resetForm() {
    setEditingId(null);
    setPaymentType('Installment');
    setMethod('Cash');
    setAmount('');
    setDate(todayISO());
    setNotes('');
    setChequeNumber('');
    setChequeDate('');
    setChequeStatus('PENDING');
  }

  function startEdit(p: Payment) {
    setTab(p.direction);
    setEditingId(p.id);
    setPaymentType(p.payment_type);
    setMethod(p.method);
    setAmount(moneyToInput(p.amount));
    setDate(p.date);
    setNotes(p.notes);
    setChequeNumber(p.cheque_number ?? '');
    setChequeDate(p.cheque_date ?? '');
    setChequeStatus(p.cheque_status ?? 'PENDING');
    setConfirmDeleteId(null);
  }

  async function saveDueDate(nextDate: string) {
    if (!window.api) return;
    setSavingDue(true);
    try {
      if (tab === 'OUT_TO_SELLER') {
        setSellerDueDate(nextDate);
        await window.api.updateDueDates(deal.id, { seller_due_date: nextDate || null });
      } else {
        setBuyerDueDate(nextDate);
        await window.api.updateDueDates(deal.id, { buyer_due_date: nextDate || null });
      }
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSavingDue(false);
    }
  }

  async function submit() {
    if (!window.api) return;
    const n = parseNum(amount);
    if (!n || n <= 0) {
      setError('Please enter a valid payment amount greater than 0.');
      return;
    }
    setError('');
    try {
      const input = {
        direction: tab,
        payment_type: paymentType,
        method,
        amount: n,
        date,
        notes,
        cheque_number: method === 'Cheque' ? textOrNull(chequeNumber) : null,
        cheque_date: method === 'Cheque' ? textOrNull(chequeDate) : null,
        cheque_status: method === 'Cheque' ? chequeStatus : null,
      };
      if (editingId !== null) await window.api.updatePayment(editingId, input);
      else await window.api.addPayment(deal.id, input);
      resetForm();
      await load();
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  async function setPaymentChequeStatus(id: number, status: ChequeStatus) {
    if (!window.api) return;
    setError('');
    try {
      await window.api.updateChequeStatus(id, status);
      await load();
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  async function remove(id: number) {
    if (!window.api) return;
    try {
      await window.api.deletePayment(id);
      setConfirmDeleteId(null);
      if (editingId === id) resetForm();
      await load();
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  const sellerPayments = payments.filter((p) => p.direction === 'OUT_TO_SELLER');
  const buyerPayments = payments.filter((p) => p.direction === 'IN_FROM_BUYER');
  const activeList = tab === 'OUT_TO_SELLER' ? sellerPayments : buyerPayments;

  const totalPaidSeller = sellerPayments.reduce((s, p) => s + p.amount, 0);
  const sellerSigned = deal.purchase_price !== null ? deal.purchase_price - totalPaidSeller : null;

  const totalReceivedBuyer = buyerPayments.reduce((s, p) => s + p.amount, 0);
  const buyerSigned = deal.sale_price !== null ? deal.sale_price - totalReceivedBuyer : null;

  const agreedPrice = tab === 'OUT_TO_SELLER' ? deal.purchase_price : deal.sale_price;
  const paidSoFar = tab === 'OUT_TO_SELLER' ? totalPaidSeller : totalReceivedBuyer;
  const signedBalance = tab === 'OUT_TO_SELLER' ? sellerSigned : buyerSigned;
  const activeDueDate = tab === 'OUT_TO_SELLER' ? sellerDueDate : buyerDueDate;
  const overdueDays = signedBalance !== null && signedBalance > 0 ? daysPastDue(activeDueDate) : null;

  return (
    <Modal
      title="Payments & Installments Ledger"
      subtitle={`${carTitle(deal)} · ${regOf(deal)}`}
      onClose={onClose}
      width="max-w-3xl"
      footer={
        <button type="button" className="btn btn-secondary" onClick={onClose}>
          Done
        </button>
      }
    >
      {error && <div className="mb-3 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}

      {/* Direction Switcher */}
      <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <button
          type="button"
          onClick={() => {
            setTab('OUT_TO_SELLER');
            resetForm();
          }}
          className={`rounded-lg border p-3.5 text-left transition ${
            tab === 'OUT_TO_SELLER'
              ? 'border-brand-500 bg-brand-50/60 ring-2 ring-brand-500/20'
              : 'border-ink-200 bg-white hover:bg-ink-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wide text-ink-500">Paid to Seller</span>
            <span className="rounded bg-ink-100 px-1.5 py-0.5 text-[11px] font-semibold text-ink-700">
              {sellerPayments.length} {sellerPayments.length === 1 ? 'entry' : 'entries'}
            </span>
          </div>
          <div className="mt-1 text-base font-bold tabular-nums text-ink-900">{fmtMoney(totalPaidSeller)}</div>
          <div className="mt-0.5 text-xs text-ink-500">
            {sellerSigned === null
              ? 'Purchase price not set'
              : sellerSigned === 0
              ? '✓ Fully paid to seller'
              : sellerSigned < 0
              ? <span className="font-semibold text-rose-700">Overpaid by {fmtMoney(Math.abs(sellerSigned))}</span>
              : `Balance due: ${fmtMoney(sellerSigned)}`}
          </div>
        </button>

        <button
          type="button"
          onClick={() => {
            setTab('IN_FROM_BUYER');
            resetForm();
          }}
          className={`rounded-lg border p-3.5 text-left transition ${
            tab === 'IN_FROM_BUYER'
              ? 'border-brand-500 bg-brand-50/60 ring-2 ring-brand-500/20'
              : 'border-ink-200 bg-white hover:bg-ink-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wide text-ink-500">Received from Buyer</span>
            <span className="rounded bg-ink-100 px-1.5 py-0.5 text-[11px] font-semibold text-ink-700">
              {buyerPayments.length} {buyerPayments.length === 1 ? 'entry' : 'entries'}
            </span>
          </div>
          <div className="mt-1 text-base font-bold tabular-nums text-ink-900">{fmtMoney(totalReceivedBuyer)}</div>
          <div className="mt-0.5 text-xs text-ink-500">
            {deal.sale_price === null
              ? deal.status === 'SOLD'
                ? 'Sale price not set'
                : deal.status === 'RESERVED'
                ? 'Reserved (Token received)'
                : 'Car not marked sold yet'
              : buyerSigned === 0
              ? '✓ Fully received from buyer'
              : buyerSigned !== null && buyerSigned < 0
              ? <span className="font-semibold text-rose-700">Excess received: {fmtMoney(Math.abs(buyerSigned))}</span>
              : `Balance due: ${fmtMoney(buyerSigned)}`}
          </div>
        </button>
      </div>

      {/* Balance Bar + Due Date */}
      <div className="mb-4 grid grid-cols-2 gap-3 rounded-lg border border-ink-200 bg-ink-50 p-3 text-center sm:grid-cols-4">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-500">
            {tab === 'OUT_TO_SELLER' ? 'Purchase Price' : 'Sale Price'}
          </div>
          <div className="mt-0.5 text-sm font-bold tabular-nums text-ink-900">{fmtMoney(agreedPrice)}</div>
        </div>
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-500">
            {tab === 'OUT_TO_SELLER' ? 'Total Paid' : 'Total Received'}
          </div>
          <div className="mt-0.5 text-sm font-bold tabular-nums text-emerald-700">{fmtMoney(paidSoFar)}</div>
        </div>
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-500">
            {signedBalance !== null && signedBalance < 0
              ? tab === 'OUT_TO_SELLER'
                ? 'Overpaid (Refund)'
                : 'Excess Received'
              : 'Remaining Due'}
          </div>
          <div
            className={`mt-0.5 text-sm font-bold tabular-nums ${
              signedBalance === null
                ? 'text-ink-500'
                : signedBalance < 0
                ? 'text-rose-700'
                : signedBalance > 0
                ? 'text-amber-700'
                : 'text-emerald-700'
            }`}
          >
            {signedBalance === null ? '—' : fmtMoney(Math.abs(signedBalance))}
          </div>
        </div>
        <div className="text-left">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-500">
            Due Date {overdueDays !== null && overdueDays > 0 && <span className="text-red-600">({overdueDays}d late)</span>}
          </div>
          <input
            type="date"
            disabled={savingDue}
            value={activeDueDate}
            onChange={(e) => void saveDueDate(e.target.value)}
            className="mt-0.5 w-full rounded border border-ink-300 bg-white px-2 py-1 text-xs text-ink-800"
          />
        </div>
      </div>

      {/* Add / Edit Payment Form */}
      <form
        noValidate
        onSubmit={(ev) => {
          ev.preventDefault();
          void submit();
        }}
        className="rounded-lg border border-ink-200 bg-ink-50 p-4"
      >
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600">
            {editingId !== null
              ? 'Edit Payment Entry'
              : tab === 'OUT_TO_SELLER'
              ? 'Record Payment Paid to Seller'
              : 'Record Payment Received from Buyer'}
          </span>
          {signedBalance !== null && signedBalance > 0 && editingId === null && (
            <button
              type="button"
              className="text-xs font-semibold text-brand-600 hover:underline"
              onClick={() => {
                setAmount(moneyToInput(signedBalance));
                setPaymentType('Final Balance');
              }}
            >
              Fill remaining balance ({fmtMoney(signedBalance)})
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 gap-x-3 gap-y-3 sm:grid-cols-6">
          <Field label="Payment Type" className="sm:col-span-2">
            <select className="input" value={paymentType} onChange={(e) => setPaymentType(e.target.value as PaymentType)} data-autofocus>
              {PAYMENT_TYPES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </Field>
          <Field label="Method" className="sm:col-span-2">
            <select className="input" value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
              {PAYMENT_METHODS.map((m) => (
                <option key={m}>{m}</option>
              ))}
            </select>
          </Field>
          <Field label="Date" className="sm:col-span-2">
            <input type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>

          {method === 'Cheque' && (
            <>
              <Field label="Cheque #" className="sm:col-span-2">
                <input
                  className="input font-mono"
                  value={chequeNumber}
                  onChange={(e) => setChequeNumber(e.target.value)}
                  placeholder="e.g. 449812"
                />
              </Field>
              <Field label="Cheque Date" className="sm:col-span-2">
                <input
                  type="date"
                  className="input"
                  value={chequeDate}
                  onChange={(e) => setChequeDate(e.target.value)}
                />
              </Field>
              <Field label="Clearance Status" className="sm:col-span-2">
                <select
                  className="input"
                  value={chequeStatus}
                  onChange={(e) => setChequeStatus(e.target.value as ChequeStatus)}
                >
                  <option value="PENDING">Pending Clearance</option>
                  <option value="CLEARED">Cleared</option>
                  <option value="BOUNCED">Bounced / Dishonored</option>
                </select>
              </Field>
            </>
          )}

          <Field label="Amount (Rs)" className="sm:col-span-2">
            <MoneyInput value={amount} onChange={setAmount} placeholder="500,000" />
          </Field>
          <Field label="Notes / Bank Ref" className="sm:col-span-3">
            <input
              className="input"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Bayana cash / HBL online ref #4912"
            />
          </Field>
          <div className="flex items-end sm:col-span-1">
            <button type="submit" className="btn btn-primary w-full">
              {editingId !== null ? 'Save' : '+ Add'}
            </button>
          </div>
        </div>
        {editingId !== null && (
          <div className="mt-2 flex justify-end">
            <button type="button" className="btn btn-secondary btn-sm" onClick={resetForm}>
              Cancel Edit
            </button>
          </div>
        )}
      </form>

      {/* Ledger Table */}
      <div className="mt-5 overflow-x-auto rounded-lg border border-ink-200">
        <table className="w-full text-sm">
          <thead className="bg-ink-50 text-left text-xs uppercase tracking-wide text-ink-500">
            <tr>
              <th className="px-3 py-2 font-semibold">Date</th>
              <th className="px-3 py-2 font-semibold">Type &amp; Method</th>
              <th className="px-3 py-2 font-semibold">Notes &amp; Cheque</th>
              <th className="px-3 py-2 text-right font-semibold">Amount</th>
              <th className="w-36 px-3 py-2" />
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-100">
            {activeList.length === 0 && (
              <tr>
                <td colSpan={5} className="px-3 py-8 text-center text-ink-500">
                  No payments recorded on this side yet.
                </td>
              </tr>
            )}
            {activeList.map((p) => (
              <tr key={p.id} className={editingId === p.id ? 'bg-brand-50' : ''}>
                <td className="whitespace-nowrap px-3 py-2 text-ink-700">{fmtDate(p.date)}</td>
                <td className="whitespace-nowrap px-3 py-2">
                  <div className="flex items-center gap-1.5">
                    <span className="rounded bg-brand-50 px-2 py-0.5 text-xs font-semibold text-brand-700">{p.payment_type}</span>
                    <span className="text-xs text-ink-600">{p.method}</span>
                  </div>
                </td>
                <td className="px-3 py-2 text-ink-700">
                  <div>{p.notes || <span className="text-ink-300">—</span>}</div>
                  {p.method === 'Cheque' && (
                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px]">
                      {p.cheque_number && <span className="font-mono font-semibold text-ink-700">#{p.cheque_number}</span>}
                      {p.cheque_date && <span className="text-ink-500">Due {fmtDate(p.cheque_date)}</span>}
                      <span
                        className={`rounded px-1.5 py-0.5 font-bold ${
                          p.cheque_status === 'CLEARED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : p.cheque_status === 'BOUNCED'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {p.cheque_status ?? 'PENDING'}
                      </span>
                      {(p.cheque_status ?? 'PENDING') !== 'CLEARED' && (
                        <button
                          type="button"
                          onClick={() => void setPaymentChequeStatus(p.id, 'CLEARED')}
                          className="font-semibold text-emerald-700 hover:underline"
                        >
                          Mark Cleared
                        </button>
                      )}
                      {p.cheque_status !== 'BOUNCED' && (
                        <button
                          type="button"
                          onClick={() => void setPaymentChequeStatus(p.id, 'BOUNCED')}
                          className="font-semibold text-red-700 hover:underline"
                        >
                          Bounced
                        </button>
                      )}
                    </div>
                  )}
                </td>
                <td className="whitespace-nowrap px-3 py-2 text-right font-semibold tabular-nums text-ink-900">{fmtMoney(p.amount)}</td>
                <td className="whitespace-nowrap px-3 py-2 text-right">
                  {confirmDeleteId === p.id ? (
                    <span className="inline-flex gap-1">
                      <button type="button" className="btn btn-danger btn-sm" onClick={() => void remove(p.id)}>
                        Yes
                      </button>
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => setConfirmDeleteId(null)}>
                        No
                      </button>
                    </span>
                  ) : (
                    <span className="inline-flex gap-1">
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => startEdit(p)}>
                        Edit
                      </button>
                      <button
                        type="button"
                        className="btn btn-secondary btn-sm text-red-600 hover:bg-red-50"
                        onClick={() => setConfirmDeleteId(p.id)}
                      >
                        Del
                      </button>
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Modal>
  );
}
