import { useEffect, useState } from 'react';
import Modal from './Modal';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export function useOnlineStatus(): boolean {
  const [online, setOnline] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine));

  useEffect(() => {
    const onUp = () => setOnline(true);
    const onDown = () => setOnline(false);
    window.addEventListener('online', onUp);
    window.addEventListener('offline', onDown);
    return () => {
      window.removeEventListener('online', onUp);
      window.removeEventListener('offline', onDown);
    };
  }, []);

  return online;
}

export function OfflineIndicator() {
  const online = useOnlineStatus();
  if (online || window.api?.isElectron) return null;

  return (
    <div
      role="status"
      className="flex items-center justify-center gap-2 border-b border-amber-200 bg-amber-50 px-3 py-1.5 text-xs font-semibold text-amber-900"
    >
      <span className="h-2 w-2 rounded-full bg-amber-600" />
      <span>Offline mode active — changes stay saved locally on this device</span>
    </div>
  );
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(() => {
    if (typeof window === 'undefined') return false;
    const nav = window.navigator as Navigator & { standalone?: boolean };
    return window.matchMedia('(display-mode: standalone)').matches || Boolean(nav.standalone);
  });

  const isIOS =
    typeof navigator !== 'undefined' &&
    /iPad|iPhone|iPod/.test(navigator.userAgent) &&
    !(window as unknown as { MSStream?: unknown }).MSStream;

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  async function triggerInstall(): Promise<'installed' | 'ios-hint' | 'unavailable'> {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
        return 'installed';
      }
      return 'unavailable';
    }
    if (isIOS) return 'ios-hint';
    return 'unavailable';
  }

  return {
    canPrompt: Boolean(deferredPrompt),
    isIOS,
    isInstalled,
    triggerInstall,
  };
}

export function PWAInstallButton({ compact = false }: { compact?: boolean }) {
  const { canPrompt, isIOS, isInstalled, triggerInstall } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (window.api?.isElectron || isInstalled) return null;
  if (!canPrompt && !isIOS) return null;

  async function onClick() {
    const res = await triggerInstall();
    if (res === 'ios-hint') {
      setShowIOSGuide(true);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => void onClick()}
        className={
          compact
            ? 'flex w-full items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-brand-700 hover:bg-brand-50'
            : 'btn btn-secondary btn-sm text-brand-700'
        }
      >
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="7 10 12 15 17 10" />
          <line x1="12" x2="12" y1="15" y2="3" />
        </svg>
        <span>Install Mobile App</span>
      </button>

      {showIOSGuide && (
        <Modal
          title="Install on iPhone / iPad"
          subtitle="Add Car Deals Manager to your Home Screen for full-screen offline access"
          onClose={() => setShowIOSGuide(false)}
          width="max-w-md"
          footer={
            <button type="button" className="btn btn-primary" onClick={() => setShowIOSGuide(false)}>
              Got It
            </button>
          }
        >
          <ol className="space-y-2.5 text-sm text-ink-700">
            <li>
              <strong>1.</strong> Tap the <strong>Share</strong> icon in Safari&apos;s toolbar.
            </li>
            <li>
              <strong>2.</strong> Scroll down and choose <strong>Add to Home Screen</strong>.
            </li>
            <li>
              <strong>3.</strong> Tap <strong>Add</strong> to launch Car Deals like a native mobile app.
            </li>
          </ol>
        </Modal>
      )}
    </>
  );
}
