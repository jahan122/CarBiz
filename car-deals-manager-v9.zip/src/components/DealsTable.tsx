import type { DealWithTotals } from '../types';
import {
  buyerBalanceDue,
  buyerOverpaid,
  checklistSummary,
  daysInStock,
  daysPastDue,
  fmtDate,
  fmtMoney,
  netProfit,
  regOf,
  sellerBalanceDue,
  sellerOverpaid,
  totalCost,
} from '../utils';

interface Props {
  deals: DealWithTotals[];
  canViewProfit?: boolean;
  canManagePayments?: boolean;
  canMarkSold?: boolean;
  canDelete?: boolean;
  onInspect: (d: DealWithTotals) => void;
  onWhatsApp: (d: DealWithTotals) => void;
  onExpense: (d: DealWithTotals) => void;
  onPayments: (d: DealWithTotals) => void;
  onReceipt: (d: DealWithTotals) => void;
  onReserve: (d: DealWithTotals) => void;
  onSold: (d: DealWithTotals) => void;
  onEdit: (d: DealWithTotals) => void;
  onDelete: (d: DealWithTotals) => void;
}

const th =
  'whitespace-nowrap border-b border-ink-200 bg-ink-50/95 px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wider text-ink-500 backdrop-blur-sm';
const td = 'border-b border-ink-100 px-3 py-3 align-top';
const dash = <span className="text-ink-300">—</span>;

function TransferBadge({ deal }: { deal: DealWithTotals }) {
  if (deal.transfer_status === 'COMPLETED') {
    return (
      <span
        className="inline-flex items-center rounded bg-emerald-50 px-1.5 py-0.5 text-[11px] font-semibold text-emerald-700 ring-1 ring-inset ring-emerald-200"
        title={deal.transfer_completed_date ? `Completed on ${fmtDate(deal.transfer_completed_date)}` : 'Transfer completed'}
      >
        ✓ Transfer Done{deal.transfer_completed_date ? ` (${fmtDate(deal.transfer_completed_date)})` : ''}
      </span>
    );
  }
  if (deal.transfer_status === 'WITH_AGENT') {
    return (
      <span
        className="inline-flex items-center rounded bg-amber-50 px-1.5 py-0.5 text-[11px] font-semibold text-amber-800 ring-1 ring-inset ring-amber-200"
        title={`Handed over on ${fmtDate(deal.file_handover_date)}`}
      >
        File w/ Agent{deal.transfer_agent_name ? `: ${deal.transfer_agent_name}` : ''}
        {deal.file_handover_date ? ` (${fmtDate(deal.file_handover_date)})` : ''}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center rounded bg-ink-100 px-1.5 py-0.5 text-[11px] font-medium text-ink-600">
      File w/ Us
    </span>
  );
}

function StatusOrProfitBadge({ deal, canViewProfit }: { deal: DealWithTotals; canViewProfit: boolean }) {
  if (deal.status === 'RESERVED') {
    const expired = (daysPastDue(deal.reserved_expiry_date) ?? -1) > 0;
    return (
      <div className="space-y-1">
        <span className="inline-flex whitespace-nowrap rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-700 ring-1 ring-inset ring-indigo-200">
          Reserved (Token)
        </span>
        {deal.reserved_token_amount !== null && deal.reserved_token_amount > 0 && (
          <div className="text-[11px] font-semibold text-indigo-700 tabular-nums">
            Token: {fmtMoney(deal.reserved_token_amount)}
          </div>
        )}
        {deal.reserved_expiry_date && (
          <div className={`text-[10px] font-semibold ${expired ? 'text-red-700' : 'text-ink-500'}`}>
            {expired ? 'Hold expired ' : 'Till '}
            {fmtDate(deal.reserved_expiry_date)}
          </div>
        )}
      </div>
    );
  }

  if (deal.status === 'ACTIVE') {
    return (
      <span className="inline-flex whitespace-nowrap rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700 ring-1 ring-inset ring-amber-200">
        Active / Unsold
      </span>
    );
  }

  if (!canViewProfit) {
    return (
      <span className="inline-flex whitespace-nowrap rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 ring-1 ring-inset ring-emerald-200">
        Sold
      </span>
    );
  }

  const p = netProfit(deal);
  if (p === null) {
    return (
      <span
        className="inline-flex whitespace-nowrap rounded-full bg-ink-100 px-2.5 py-1 text-xs font-semibold text-ink-700 ring-1 ring-inset ring-ink-200"
        title="Purchase price or sale price not recorded"
      >
        Sold · profit n/a
      </span>
    );
  }
  const good = p >= 0;
  return (
    <span
      className={`inline-flex whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-bold tabular-nums ring-1 ring-inset ${
        good ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : 'bg-red-50 text-red-700 ring-red-200'
      }`}
    >
      {good ? '+' : '−'} {fmtMoney(Math.abs(p))}
    </span>
  );
}

function DueTag({ dueDate }: { dueDate: string | null }) {
  const past = daysPastDue(dueDate);
  if (past === null) return null;
  if (past > 0) {
    return <span className="mt-0.5 block text-[10px] font-bold text-red-700">Overdue {past}d</span>;
  }
  if (past === 0) {
    return <span className="mt-0.5 block text-[10px] font-bold text-amber-800">Due today</span>;
  }
  return <span className="mt-0.5 block text-[10px] text-ink-500">Due {fmtDate(dueDate)}</span>;
}

export default function DealsTable({
  deals,
  canViewProfit = true,
  canManagePayments = true,
  canMarkSold = true,
  canDelete = true,
  onInspect,
  onWhatsApp,
  onExpense,
  onPayments,
  onReceipt,
  onReserve,
  onSold,
  onEdit,
  onDelete,
}: Props) {
  return (
    <>
      {/* Mobile Touch Card View */}
      <div className="divide-y divide-ink-200 md:hidden">
        {deals.map((d) => {
          const sold = d.status === 'SOLD';
          const reserved = d.status === 'RESERVED';
          const title = [d.year, d.make, d.model].filter(Boolean).join(' ');
          const sDue = sellerBalanceDue(d) ?? 0;
          const bDue = buyerBalanceDue(d) ?? 0;
          const stockDays = daysInStock(d);

          return (
            <div
              key={d.id}
              onClick={() => onInspect(d)}
              className="space-y-3 bg-white p-4 active:bg-ink-50"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="rounded border border-ink-300 bg-ink-50 px-2 py-0.5 font-mono text-xs font-bold text-ink-900">
                      {regOf(d)}
                    </span>
                    {stockDays !== null && !sold && (
                      <span
                        className={`rounded px-1.5 py-0.5 text-[10px] font-bold tabular-nums ${
                          stockDays >= 60
                            ? 'bg-red-100 text-red-800'
                            : stockDays >= 30
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-ink-100 text-ink-600'
                        }`}
                      >
                        {stockDays}d
                      </span>
                    )}
                    {(d.trade_in_deal_id || d.trade_in_for_deal_id) && (
                      <span className="rounded bg-purple-100 px-1.5 py-0.5 text-[10px] font-bold text-purple-800">
                        Exchange
                      </span>
                    )}
                  </div>
                  <div className="mt-1.5 text-sm font-bold text-ink-900">
                    {title || 'Unnamed car'}
                    {d.variant && <span className="font-normal text-ink-500"> {d.variant}</span>}
                  </div>
                </div>
                <div className="shrink-0 text-right">
                  <StatusOrProfitBadge deal={d} canViewProfit={canViewProfit} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 rounded-lg bg-ink-50 p-2.5 text-xs tabular-nums">
                <div>
                  <div className="text-[10px] font-semibold uppercase text-ink-500">
                    {sold ? 'Buyer' : reserved ? 'Token Hold' : 'Seller'}
                  </div>
                  <div className="truncate font-semibold text-ink-900">
                    {sold
                      ? d.purchaser_name || '—'
                      : reserved
                        ? d.reserved_buyer_name || 'Reserved'
                        : d.seller_name || '—'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-semibold uppercase text-ink-500">
                    {sold ? 'Sale Price' : canViewProfit ? 'Total Cost' : 'Transfer'}
                  </div>
                  <div className="font-bold text-ink-900">
                    {sold
                      ? fmtMoney(d.sale_price)
                      : canViewProfit
                        ? fmtMoney(totalCost(d))
                        : d.transfer_status}
                  </div>
                </div>
                {((sold && bDue > 0) || (!sold && canViewProfit && sDue > 0)) && (
                  <div className="col-span-2 flex items-center justify-between border-t border-ink-200/80 pt-1.5 text-[11px] font-bold">
                    <span className={sold ? 'text-emerald-700' : 'text-amber-700'}>
                      {sold ? `Due from Buyer: ${fmtMoney(bDue)}` : `Due to Seller: ${fmtMoney(sDue)}`}
                    </span>
                    <TransferBadge deal={d} />
                  </div>
                )}
              </div>

              <div className="flex flex-wrap gap-1.5" onClick={(e) => e.stopPropagation()}>
                <button
                  type="button"
                  onClick={() => onInspect(d)}
                  className="btn btn-secondary min-h-[40px] flex-1 text-xs font-semibold"
                >
                  Open
                </button>
                <button
                  type="button"
                  onClick={() => onWhatsApp(d)}
                  className="btn min-h-[40px] bg-[#25D366] px-3 text-xs font-bold text-white hover:bg-[#1ebe5d]"
                >
                  WhatsApp
                </button>
                {canManagePayments && (
                  <button
                    type="button"
                    onClick={() => onPayments(d)}
                    className="btn btn-secondary min-h-[40px] px-3 text-xs"
                  >
                    Payments
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onReceipt(d)}
                  className="btn btn-secondary min-h-[40px] px-3 text-xs"
                >
                  Receipt
                </button>
                {!sold && canMarkSold && (
                  <button
                    type="button"
                    onClick={() => onSold(d)}
                    className="btn btn-primary min-h-[40px] px-3 text-xs"
                  >
                    Sold
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Desktop Ledger Table */}
      <div className="hidden md:block">
        <table className="w-full border-separate border-spacing-0 text-sm">
          <thead className="sticky top-0 z-10">
            <tr>
              <th className={th}>Car &amp; File Status</th>
              <th className={th}>Bought From</th>
              <th className={th}>Seller</th>
              {canViewProfit && <th className={`${th} text-right`}>Purchase &amp; Paid</th>}
              {canViewProfit && <th className={`${th} text-right`}>Expenses</th>}
              {canViewProfit && <th className={`${th} text-right`}>Transfer Cost</th>}
              {canViewProfit && <th className={`${th} text-right`}>Total Cost</th>}
              <th className={th}>Buyer / Hold &amp; Received</th>
              <th className={`${th} min-w-[140px]`}>{canViewProfit ? 'Status / Net Profit' : 'Status'}</th>
              <th className={`${th} sticky right-0 z-20 shadow-[-8px_0_8px_-8px_rgba(15,23,42,0.12)]`}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {deals.map((d) => {
              const sold = d.status === 'SOLD';
              const reserved = d.status === 'RESERVED';
              const title = [d.year, d.make, d.model].filter(Boolean).join(' ');
              const sDue = sellerBalanceDue(d);
              const sOver = sellerOverpaid(d);
              const bDue = buyerBalanceDue(d);
              const bOver = buyerOverpaid(d);
              const transferCost = d.transfer_cost ?? 0;
              const stockDays = daysInStock(d);
              const docs = checklistSummary(d);

              return (
                <tr
                  key={d.id}
                  onClick={() => onInspect(d)}
                  title="Click row to open quick inspection drawer"
                  className="group cursor-pointer transition-colors hover:bg-brand-50/40"
                >
                  <td className={td}>
                    <div className="font-semibold text-ink-900 group-hover:text-brand-700">
                      {title || <span className="text-ink-500">Unnamed car</span>}
                      {d.variant && <span className="font-normal text-ink-500"> {d.variant}</span>}
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-ink-500">
                      {d.color && <span>{d.color}</span>}
                      {d.registration_number ? (
                        <span className="rounded border border-ink-300 bg-ink-50 px-1.5 py-px font-mono font-bold tracking-wide text-ink-800">
                          {d.registration_number}
                        </span>
                      ) : (
                        <span className="text-ink-300">No reg #</span>
                      )}
                      {stockDays !== null && !sold && (
                        <span
                          className={`rounded px-1.5 py-px text-[10px] font-bold tabular-nums ${
                            stockDays >= 60
                              ? 'bg-red-100 text-red-800'
                              : stockDays >= 30
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-ink-100 text-ink-600'
                          }`}
                        >
                          {stockDays}d
                        </span>
                      )}
                      {stockDays !== null && sold && (
                        <span className="rounded bg-ink-100 px-1.5 py-px text-[10px] font-medium text-ink-500 tabular-nums">
                          Sold in {stockDays}d
                        </span>
                      )}
                      {(d.trade_in_deal_id || d.trade_in_for_deal_id) && (
                        <span className="rounded bg-purple-100 px-1.5 py-px text-[10px] font-bold text-purple-800">
                          Exchange
                        </span>
                      )}
                      {d.attachment_count > 0 && (
                        <span className="rounded bg-blue-50 px-1.5 py-px text-[11px] font-semibold text-blue-700">
                          📎 {d.attachment_count}
                        </span>
                      )}
                      <span
                        className={`rounded px-1.5 py-px text-[10px] font-semibold ${
                          docs.missingCriticalDocs.length === 0
                            ? 'bg-emerald-50 text-emerald-700'
                            : 'bg-amber-50 text-amber-800'
                        }`}
                        title={
                          docs.missingCriticalDocs.length > 0
                            ? `Missing key docs: ${docs.missingCriticalDocs.join(', ')}`
                            : 'All key documents verified'
                        }
                      >
                        Docs {docs.docsChecked}/{docs.docsTotal}
                      </span>
                    </div>
                    <div className="mt-1.5">
                      <TransferBadge deal={d} />
                    </div>
                    {(d.chassis_number || d.engine_number) && (
                      <div className="mt-1 font-mono text-[11px] text-ink-500">
                        {d.chassis_number && <span>Ch: {d.chassis_number}</span>}
                        {d.chassis_number && d.engine_number && <span> · </span>}
                        {d.engine_number && <span>En: {d.engine_number}</span>}
                      </div>
                    )}
                  </td>

                  <td className={td}>
                    <div className="font-medium text-ink-900">{d.bought_from_location || dash}</div>
                    <div className="mt-0.5 text-xs text-ink-500">{fmtDate(d.purchase_date)}</div>
                  </td>

                  <td className={td}>
                    <div className="font-medium text-ink-900">
                      {d.seller_name || dash}
                      {d.seller_father_name && <span className="font-normal text-ink-500"> S/O {d.seller_father_name}</span>}
                    </div>
                    {d.seller_contact && <div className="mt-0.5 text-xs text-ink-500">{d.seller_contact}</div>}
                    {d.seller_address && <div className="mt-0.5 max-w-[190px] text-xs leading-snug text-ink-500">{d.seller_address}</div>}
                  </td>

                  {canViewProfit && (
                    <td className={`${td} whitespace-nowrap text-right tabular-nums`}>
                      <div className="font-medium text-ink-900">{d.purchase_price === null ? dash : fmtMoney(d.purchase_price)}</div>
                      {d.purchase_price !== null && (
                        <div className="mt-0.5 text-[11px]">
                          {sOver > 0 ? (
                            <span className="font-bold text-red-700">Overpaid {fmtMoney(sOver)}</span>
                          ) : sDue === 0 ? (
                            <span className="font-medium text-emerald-700">Paid in full</span>
                          ) : (
                            <>
                              <span className="font-medium text-amber-700">Due: {fmtMoney(sDue)}</span>
                              <DueTag dueDate={d.seller_due_date} />
                            </>
                          )}
                        </div>
                      )}
                    </td>
                  )}

                  {canViewProfit && (
                    <td className={`${td} whitespace-nowrap text-right tabular-nums text-ink-700`}>
                      {d.total_expenses > 0 ? fmtMoney(d.total_expenses) : dash}
                    </td>
                  )}

                  {canViewProfit && (
                    <td className={`${td} whitespace-nowrap text-right tabular-nums text-indigo-700`}>
                      {transferCost > 0 ? fmtMoney(transferCost) : dash}
                    </td>
                  )}

                  {canViewProfit && (
                    <td className={`${td} whitespace-nowrap text-right font-semibold tabular-nums text-ink-900`}>
                      {fmtMoney(totalCost(d))}
                    </td>
                  )}

                  <td className={td}>
                    {sold ? (
                      <>
                        <div className="font-semibold tabular-nums text-ink-900">
                          {d.sale_price === null ? <span className="font-normal text-ink-500">Price not entered</span> : fmtMoney(d.sale_price)}
                        </div>
                        {d.sale_price !== null && (
                          <div className="mt-0.5 text-[11px]">
                            {bOver > 0 ? (
                              <span className="font-bold text-indigo-700">Excess +{fmtMoney(bOver)}</span>
                            ) : bDue === 0 ? (
                              <span className="font-medium text-emerald-700">Received in full</span>
                            ) : (
                              <>
                                <span className="font-medium text-amber-700">Due: {fmtMoney(bDue)}</span>
                                <DueTag dueDate={d.buyer_due_date} />
                              </>
                            )}
                          </div>
                        )}
                        {d.purchaser_name && (
                          <div className="mt-0.5 text-xs font-medium text-ink-700">
                            {d.purchaser_name}
                            {d.purchaser_father_name && <span className="font-normal text-ink-500"> S/O {d.purchaser_father_name}</span>}
                          </div>
                        )}
                        <div className="text-xs text-ink-500">
                          {[d.purchaser_contact, d.sale_date ? fmtDate(d.sale_date) : null].filter(Boolean).join(' · ')}
                        </div>
                        {d.purchaser_address && (
                          <div className="mt-0.5 max-w-[190px] text-xs leading-snug text-ink-500">{d.purchaser_address}</div>
                        )}
                      </>
                    ) : reserved ? (
                      <div className="text-xs">
                        <div className="font-semibold text-indigo-800">{d.reserved_buyer_name || 'Reserved'}</div>
                        {d.reserved_buyer_contact && <div className="text-ink-500">{d.reserved_buyer_contact}</div>}
                        {d.received_from_buyer > 0 && (
                          <div className="mt-0.5 font-medium text-indigo-700 tabular-nums">
                            Token: {fmtMoney(d.received_from_buyer)}
                          </div>
                        )}
                      </div>
                    ) : (
                      dash
                    )}
                  </td>

                  <td className={`${td} min-w-[140px]`}>
                    <StatusOrProfitBadge deal={d} canViewProfit={canViewProfit} />
                  </td>

                  <td
                    onClick={(e) => e.stopPropagation()}
                    className={`${td} sticky right-0 cursor-default bg-white shadow-[-8px_0_8px_-8px_rgba(15,23,42,0.12)] group-hover:bg-brand-50/40`}
                  >
                    <div className="flex flex-wrap gap-1">
                      <button
                        type="button"
                        className="btn btn-sm bg-[#25D366] text-white hover:bg-[#1ebe5d]"
                        onClick={() => onWhatsApp(d)}
                        title="Choose recipient & share receipt via WhatsApp"
                      >
                        WhatsApp
                      </button>
                      {canManagePayments && (
                        <button
                          type="button"
                          className="btn btn-secondary btn-sm"
                          onClick={() => onPayments(d)}
                          title="Track advance & installments"
                        >
                          Payments
                        </button>
                      )}
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => onExpense(d)}>
                        + Expense
                      </button>
                      <button
                        type="button"
                        className="btn btn-secondary btn-sm"
                        onClick={() => onReceipt(d)}
                        title="Print PDF Receipt"
                      >
                        Receipt
                      </button>
                      {!sold && canMarkSold && (
                        <button
                          type="button"
                          className="btn btn-secondary btn-sm text-indigo-700"
                          onClick={() => onReserve(d)}
                          title="Hold vehicle with Bayana / Token"
                        >
                          {reserved ? 'Hold' : 'Reserve'}
                        </button>
                      )}
                      {canMarkSold && (
                        <button
                          type="button"
                          className={`btn btn-sm ${sold ? 'btn-secondary' : 'btn-primary'}`}
                          onClick={() => onSold(d)}
                        >
                          {sold ? 'Edit Sale' : 'Sold'}
                        </button>
                      )}
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => onEdit(d)}>
                        Edit
                      </button>
                      {canDelete && (
                        <button
                          type="button"
                          className="btn btn-secondary btn-sm text-red-600 hover:bg-red-50"
                          onClick={() => onDelete(d)}
                        >
                          Delete
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}