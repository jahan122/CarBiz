import { useMemo, useState } from 'react';
import Modal, { Field } from './Modal';
import {
  PAYMENT_METHODS,
  PAYMENT_TYPES,
  type DealWithTotals,
  type PaymentMethod,
  type PaymentType,
  type TradeInInput,
} from '../types';
import MoneyInput from './MoneyInput';
import {
  buildPartyDirectory,
  carTitle,
  fmtMoney,
  formatCnic,
  formatPhone,
  moneyToInput,
  parseNum,
  regOf,
  textOrNull,
  todayISO,
  totalCost,
} from '../utils';

interface Props {
  deal: DealWithTotals;
  deals?: DealWithTotals[];
  canViewProfit?: boolean;
  canManagePayments?: boolean;
  onClose: () => void;
  onSaved: (message: string) => void;
}

export default function SoldModal({
  deal,
  deals = [],
  canViewProfit = true,
  canManagePayments = true,
  onClose,
  onSaved,
}: Props) {
  const editing = deal.status === 'SOLD';
  const fromReserved = deal.status === 'RESERVED';

  const [salePrice, setSalePrice] = useState(moneyToInput(deal.sale_price));
  const [saleDate, setSaleDate] = useState(editing ? deal.sale_date ?? '' : todayISO());
  const [buyerDueDate, setBuyerDueDate] = useState(deal.buyer_due_date ?? '');
  const [name, setName] = useState(deal.purchaser_name ?? deal.reserved_buyer_name ?? '');
  const [fatherName, setFatherName] = useState(deal.purchaser_father_name ?? '');
  const [contact, setContact] = useState(deal.purchaser_contact ?? deal.reserved_buyer_contact ?? '');
  const [cnic, setCnic] = useState(deal.purchaser_cnic ?? '');
  const [address, setAddress] = useState(deal.purchaser_address ?? '');

  // Initial Buyer Payment when marking sold
  const [initAmount, setInitAmount] = useState('');
  const [initType, setInitType] = useState<PaymentType>('Final Balance');
  const [initMethod, setInitMethod] = useState<PaymentMethod>('Cash');
  const [initNotes, setInitNotes] = useState('');
  const [initChequeNumber, setInitChequeNumber] = useState('');
  const [initChequeDate, setInitChequeDate] = useState('');

  // Trade-In / Part-Exchange Car
  const [hasTradeIn, setHasTradeIn] = useState(false);
  const [tiValuation, setTiValuation] = useState('');
  const [tiMake, setTiMake] = useState('');
  const [tiModel, setTiModel] = useState('');
  const [tiVariant, setTiVariant] = useState('');
  const [tiYear, setTiYear] = useState('');
  const [tiColor, setTiColor] = useState('');
  const [tiHorsePower, setTiHorsePower] = useState('');
  const [tiReg, setTiReg] = useState('');
  const [tiChassis, setTiChassis] = useState('');
  const [tiEngine, setTiEngine] = useState('');
  const [tiMileage, setTiMileage] = useState('');
  const [tiNotes, setTiNotes] = useState('');

  // Revert confirmation state
  const [confirmRevert, setConfirmRevert] = useState(false);
  const [deleteBuyerPaymentsOnRevert, setDeleteBuyerPaymentsOnRevert] = useState(false);

  const [serverError, setServerError] = useState('');
  const [busy, setBusy] = useState(false);

  const parties = useMemo(() => buildPartyDirectory(deals), [deals]);

  const cost = totalCost(deal);
  const price = parseNum(salePrice);
  const costKnown = deal.purchase_price !== null;
  const profit = price !== null && costKnown ? price - cost : null;
  const tiValNumeric = hasTradeIn ? parseNum(tiValuation) ?? 0 : 0;
  const remainingCashDue =
    price !== null ? Math.max(0, price - (deal.received_from_buyer ?? 0) - tiValNumeric) : null;

  function handleNameChange(val: string) {
    setName(val);
    const match = parties.find((p) => p.name.toLowerCase() === val.trim().toLowerCase());
    if (match) {
      if (!fatherName && match.father_name) setFatherName(match.father_name);
      if (!contact && match.contact) setContact(formatPhone(match.contact));
      if (!cnic && match.cnic) setCnic(formatCnic(match.cnic));
      if (!address && match.address) setAddress(match.address);
    }
  }

  async function submit() {
    if (!window.api) return;
    if (hasTradeIn && (!tiMake.trim() && !tiModel.trim() && !tiReg.trim())) {
      setServerError('Please enter at least Make, Model, or Registration # for the Trade-In vehicle.');
      return;
    }
    setBusy(true);
    setServerError('');
    try {
      const pAmt = parseNum(initAmount);
      const initialPayment =
        !editing && canManagePayments && pAmt !== null && pAmt > 0
          ? {
              amount: pAmt,
              payment_type: initType,
              method: initMethod,
              date: textOrNull(saleDate) ?? todayISO(),
              notes: initNotes.trim() || 'Initial payment on sale',
              cheque_number: initMethod === 'Cheque' ? textOrNull(initChequeNumber) : null,
              cheque_date: initMethod === 'Cheque' ? textOrNull(initChequeDate) : null,
              cheque_status: initMethod === 'Cheque' ? ('PENDING' as const) : null,
            }
          : null;

      const tradeIn: TradeInInput | null =
        !editing && !deal.trade_in_deal_id && hasTradeIn
          ? {
              valuation: parseNum(tiValuation) ?? 0,
              make: textOrNull(tiMake),
              model: textOrNull(tiModel),
              variant: textOrNull(tiVariant),
              year: textOrNull(tiYear),
              color: textOrNull(tiColor),
              horse_power: textOrNull(tiHorsePower),
              registration_number: textOrNull(tiReg),
              chassis_number: textOrNull(tiChassis),
              engine_number: textOrNull(tiEngine),
              mileage: textOrNull(tiMileage),
              notes: textOrNull(tiNotes),
            }
          : null;

      const updated = await window.api.markSold(
        deal.id,
        {
          sale_price: price,
          sale_date: textOrNull(saleDate),
          purchaser_name: textOrNull(name),
          purchaser_father_name: textOrNull(fatherName),
          purchaser_contact: textOrNull(contact),
          purchaser_cnic: textOrNull(cnic),
          purchaser_address: textOrNull(address),
          buyer_due_date: textOrNull(buyerDueDate),
          tradeIn,
        },
        initialPayment,
      );

      const p =
        canViewProfit && updated.sale_price !== null && updated.purchase_price !== null
          ? updated.sale_price - totalCost(updated)
          : null;
      onSaved(
        `${carTitle(updated)} sold${tradeIn ? ' (Trade-In car added to Stock)' : ''}${p === null ? '' : ` — net ${p >= 0 ? 'profit' : 'loss'} ${fmtMoney(Math.abs(p))}`}`,
      );
    } catch (err) {
      setServerError(err instanceof Error ? err.message : String(err));
      setBusy(false);
    }
  }

  async function performRevert() {
    if (!window.api) return;
    setBusy(true);
    setServerError('');
    try {
      await window.api.revertSale(deal.id, deleteBuyerPaymentsOnRevert);
      onSaved(
        `${carTitle(deal)} moved back to Active${
          deleteBuyerPaymentsOnRevert ? ' (buyer payments cleared)' : ''
        }`,
      );
    } catch (err) {
      setServerError(err instanceof Error ? err.message : String(err));
      setBusy(false);
    }
  }

  return (
    <Modal
      title={editing ? 'Edit Sale' : fromReserved ? 'Convert Reserved Car to Sold' : 'Mark Car as Sold'}
      subtitle={`${carTitle(deal)} · ${regOf(deal)}`}
      onClose={onClose}
      onSubmit={() => void submit()}
      width="max-w-2xl"
      footer={
        <>
          {editing && !confirmRevert && (
            <button
              type="button"
              className="btn btn-secondary text-red-600 hover:bg-red-50 sm:mr-auto"
              onClick={() => {
                if ((deal.received_from_buyer ?? 0) > 0) {
                  setConfirmRevert(true);
                } else {
                  void performRevert();
                }
              }}
              disabled={busy}
            >
              Revert to Unsold
            </button>
          )}
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={busy}>
            {editing ? 'Save Sale' : 'Confirm Sale'}
          </button>
        </>
      }
    >
      {serverError && (
        <div className="mb-4 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{serverError}</div>
      )}

      {confirmRevert && (
        <div className="mb-4 rounded-xl border border-red-200 bg-red-50 p-4 text-xs">
          <div className="font-bold text-red-900">
            This vehicle has {fmtMoney(deal.received_from_buyer)} recorded in Buyer Payments
          </div>
          <p className="mt-1 text-red-700">Choose what to do with those recorded buyer payments when reverting to Active Stock:</p>
          <div className="mt-2 space-y-1.5">
            <label className="flex cursor-pointer items-center gap-2 font-medium text-ink-800">
              <input
                type="radio"
                name="revertPayAction"
                checked={!deleteBuyerPaymentsOnRevert}
                onChange={() => setDeleteBuyerPaymentsOnRevert(false)}
              />
              <span>Keep buyer payment entries (e.g. forfeited token or audit trail)</span>
            </label>
            <label className="flex cursor-pointer items-center gap-2 font-medium text-ink-800">
              <input
                type="radio"
                name="revertPayAction"
                checked={deleteBuyerPaymentsOnRevert}
                onChange={() => setDeleteBuyerPaymentsOnRevert(true)}
              />
              <span>Delete all buyer payments on this car (full refund / mistake)</span>
            </label>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" className="btn btn-danger btn-sm" disabled={busy} onClick={() => void performRevert()}>
              Confirm Revert to Active
            </button>
            <button type="button" className="btn btn-secondary btn-sm" onClick={() => setConfirmRevert(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {fromReserved && (
        <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
          Pre-filled from reservation for <strong>{deal.reserved_buyer_name || 'Buyer'}</strong>
          {deal.received_from_buyer > 0 ? ` · Token already received: ${fmtMoney(deal.received_from_buyer)}` : ''}.
        </div>
      )}

      {canViewProfit && (
        <div className="mb-5 grid grid-cols-2 gap-3 rounded-md border border-ink-200 bg-ink-50 p-3 text-center sm:grid-cols-4">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-500">Purchase</div>
            <div className="mt-0.5 text-sm font-semibold tabular-nums">{fmtMoney(deal.purchase_price)}</div>
          </div>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-500">Expenses</div>
            <div className="mt-0.5 text-sm font-semibold tabular-nums">{fmtMoney(deal.total_expenses)}</div>
          </div>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-500">Transfer Cost</div>
            <div className="mt-0.5 text-sm font-semibold tabular-nums">{fmtMoney(deal.transfer_cost ?? 0)}</div>
          </div>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-500">Total Cost</div>
            <div className="mt-0.5 text-sm font-bold tabular-nums">{costKnown ? fmtMoney(cost) : '—'}</div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-x-4 gap-y-3 sm:grid-cols-2">
        <Field label="Sale Price (Rs)">
          <MoneyInput value={salePrice} onChange={setSalePrice} placeholder="3,900,000" data-autofocus />
        </Field>
        <Field label="Sale Date">
          <input type="date" className="input" value={saleDate} onChange={(e) => setSaleDate(e.target.value)} />
        </Field>
        <Field label="Purchaser Name">
          <input
            className="input"
            list="sold-party-list"
            value={name}
            onChange={(e) => handleNameChange(e.target.value)}
          />
          <datalist id="sold-party-list">
            {parties.map((p) => (
              <option key={`${p.name}-${p.cnic || p.contact}`} value={p.name}>
                {[p.contact, p.cnic].filter(Boolean).join(' · ')}
              </option>
            ))}
          </datalist>
        </Field>
        <Field label="Purchaser S/O (Father's Name)">
          <input
            className="input"
            value={fatherName}
            onChange={(e) => setFatherName(e.target.value)}
            placeholder="Printed on receipt S/O line"
          />
        </Field>
        <Field label="Purchaser Contact">
          <input
            className="input"
            inputMode="tel"
            value={contact}
            onChange={(e) => setContact(formatPhone(e.target.value))}
            placeholder="03xx-xxxxxxx"
          />
        </Field>
        <Field label="Purchaser CNIC">
          <input
            className="input"
            inputMode="numeric"
            value={cnic}
            onChange={(e) => setCnic(formatCnic(e.target.value))}
            placeholder="xxxxx-xxxxxxx-x"
          />
        </Field>
        <Field label="Purchaser Address (R/O)">
          <input
            className="input"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="House / street / area / city"
          />
        </Field>
        <Field label="Balance Due Date (if installments)">
          <input type="date" className="input" value={buyerDueDate} onChange={(e) => setBuyerDueDate(e.target.value)} />
        </Field>
      </div>

      {/* Trade-In / Part-Exchange Vehicle Section */}
      {!editing && !deal.trade_in_deal_id && (
        <div className="mt-4 rounded-xl border border-indigo-200 bg-indigo-50/40 p-3.5">
          <label className="flex cursor-pointer items-center gap-2 text-xs font-bold text-indigo-900">
            <input
              type="checkbox"
              className="h-4 w-4 rounded border-indigo-300 text-indigo-600"
              checked={hasTradeIn}
              onChange={(e) => setHasTradeIn(e.target.checked)}
            />
            Buyer is trading in an old car as part-payment (Exchange Deal)
          </label>
          <p className="mt-0.5 text-[11px] text-indigo-700">
            Automatically credits the trade-in valuation toward this car&apos;s payments and adds the incoming car to Active Stock.
          </p>

          {hasTradeIn && (
            <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Trade-In Valuation (Rs) *</label>
                <MoneyInput value={tiValuation} onChange={setTiValuation} placeholder="1,850,000" className="input text-xs tabular-nums" />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Incoming Make *</label>
                <input className="input text-xs" placeholder="e.g. Suzuki" value={tiMake} onChange={(e) => setTiMake(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Incoming Model *</label>
                <input className="input text-xs" placeholder="e.g. Cultus" value={tiModel} onChange={(e) => setTiModel(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Variant / Grade</label>
                <input className="input text-xs" placeholder="e.g. VXL" value={tiVariant} onChange={(e) => setTiVariant(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Year</label>
                <input type="number" className="input text-xs" placeholder="e.g. 2019" value={tiYear} onChange={(e) => setTiYear(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Registration #</label>
                <input className="input font-mono text-xs uppercase" placeholder="e.g. BPL-204" value={tiReg} onChange={(e) => setTiReg(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Color</label>
                <input className="input text-xs" placeholder="White" value={tiColor} onChange={(e) => setTiColor(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Engine CC</label>
                <input className="input text-xs" placeholder="1000 CC" value={tiHorsePower} onChange={(e) => setTiHorsePower(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Mileage (km)</label>
                <input type="number" className="input text-xs" placeholder="52000" value={tiMileage} onChange={(e) => setTiMileage(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Chassis #</label>
                <input className="input font-mono text-xs uppercase" value={tiChassis} onChange={(e) => setTiChassis(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Engine #</label>
                <input className="input font-mono text-xs uppercase" value={tiEngine} onChange={(e) => setTiEngine(e.target.value)} />
              </div>
              <div>
                <label className="mb-1 block text-[11px] font-semibold text-ink-700">Trade-In Notes</label>
                <input className="input text-xs" placeholder="Condition / file note" value={tiNotes} onChange={(e) => setTiNotes(e.target.value)} />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Initial Payment Received Today */}
      {!editing && canManagePayments && (
        <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50/50 p-3.5">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
              Cash / Bank / Cheque Received Today (Optional)
            </span>
            {remainingCashDue !== null && remainingCashDue > 0 && (
              <button
                type="button"
                className="text-[11px] font-semibold text-emerald-700 hover:underline"
                onClick={() => {
                  setInitAmount(moneyToInput(remainingCashDue));
                  setInitType('Final Balance');
                }}
              >
                Fill {hasTradeIn || deal.received_from_buyer > 0 ? 'Remaining Cash Due' : 'Full Sale Price'} ({fmtMoney(remainingCashDue)})
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-4">
            <MoneyInput
              value={initAmount}
              onChange={setInitAmount}
              placeholder="Amount (Rs)"
              className="input text-xs tabular-nums"
            />
            <select
              className="input text-xs"
              value={initType}
              onChange={(e) => setInitType(e.target.value as PaymentType)}
            >
              {PAYMENT_TYPES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
            <select
              className="input text-xs"
              value={initMethod}
              onChange={(e) => setInitMethod(e.target.value as PaymentMethod)}
            >
              {PAYMENT_METHODS.map((m) => (
                <option key={m}>{m}</option>
              ))}
            </select>
            <input
              type="text"
              className="input text-xs"
              placeholder="Notes / ref"
              value={initNotes}
              onChange={(e) => setInitNotes(e.target.value)}
            />
          </div>
          {initMethod === 'Cheque' && (
            <div className="mt-2.5 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <input
                type="text"
                className="input text-xs font-mono"
                placeholder="Cheque Number"
                value={initChequeNumber}
                onChange={(e) => setInitChequeNumber(e.target.value)}
              />
              <input
                type="date"
                className="input text-xs"
                value={initChequeDate}
                onChange={(e) => setInitChequeDate(e.target.value)}
              />
            </div>
          )}
        </div>
      )}

      {canViewProfit && (
        <div
          className={`mt-5 flex flex-wrap items-center justify-between gap-2 rounded-md border px-4 py-3 ${
            profit === null
              ? 'border-ink-200 bg-ink-50'
              : profit >= 0
              ? 'border-emerald-200 bg-emerald-50'
              : 'border-red-200 bg-red-50'
          }`}
        >
          <span className="text-sm font-medium text-ink-700">
            {!costKnown
              ? 'No purchase price recorded, so profit cannot be calculated'
              : `Net ${profit !== null && profit < 0 ? 'loss' : 'profit'} on this deal`}
          </span>
          <span
            className={`text-lg font-bold tabular-nums ${
              profit === null ? 'text-ink-300' : profit >= 0 ? 'text-emerald-700' : 'text-red-700'
            }`}
          >
            {profit === null ? '—' : `${profit < 0 ? '−' : '+'} ${fmtMoney(Math.abs(profit))}`}
          </span>
        </div>
      )}
    </Modal>
  );
}