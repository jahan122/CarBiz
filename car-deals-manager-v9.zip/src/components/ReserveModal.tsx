import { useMemo, useState } from 'react';
import Modal, { Field } from './Modal';
import MoneyInput from './MoneyInput';
import { PAYMENT_METHODS, type DealWithTotals, type PaymentMethod } from '../types';
import { buildPartyDirectory, carTitle, fmtMoney, formatPhone, moneyToInput, parseNum, regOf, todayISO } from '../utils';

interface Props {
  deal: DealWithTotals;
  deals?: DealWithTotals[];
  onClose: () => void;
  onSaved: (message: string) => void;
}

function defaultExpiryDate(): string {
  const d = new Date();
  d.setDate(d.getDate() + 7);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export default function ReserveModal({ deal, deals = [], onClose, onSaved }: Props) {
  const isReserved = deal.status === 'RESERVED';
  const [buyerName, setBuyerName] = useState(deal.reserved_buyer_name ?? '');
  const [buyerContact, setBuyerContact] = useState(deal.reserved_buyer_contact ?? '');
  const [tokenAmount, setTokenAmount] = useState(moneyToInput(deal.reserved_token_amount));
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [reservedDate, setReservedDate] = useState(deal.reserved_date ?? todayISO());
  const [expiryDate, setExpiryDate] = useState(deal.reserved_expiry_date ?? defaultExpiryDate());
  const [notes, setNotes] = useState(deal.reserved_notes ?? '');
  const [refundOnCancel, setRefundOnCancel] = useState(false);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const parties = useMemo(() => buildPartyDirectory(deals), [deals]);

  function applyParty(nameVal: string) {
    setBuyerName(nameVal);
    const match = parties.find((p) => p.name.toLowerCase() === nameVal.trim().toLowerCase());
    if (match && !buyerContact) {
      setBuyerContact(formatPhone(match.contact));
    }
  }

  async function submit() {
    if (!window.api) return;
    setBusy(true);
    setError('');
    try {
      const updated = await window.api.reserveDeal(deal.id, {
        reserved_buyer_name: buyerName,
        reserved_buyer_contact: buyerContact,
        reserved_token_amount: parseNum(tokenAmount),
        reserved_date: reservedDate || todayISO(),
        reserved_expiry_date: expiryDate || null,
        reserved_notes: notes,
        payment_method: paymentMethod,
      });
      onSaved(
        `${carTitle(updated)} placed on Token / Reserved${
          updated.reserved_buyer_name ? ` for ${updated.reserved_buyer_name}` : ''
        }`,
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setBusy(false);
    }
  }

  async function handleCancelReservation() {
    if (!window.api) return;
    setBusy(true);
    setError('');
    try {
      await window.api.cancelReservation(deal.id, refundOnCancel);
      onSaved(
        `${carTitle(deal)} reservation cancelled (${refundOnCancel ? 'token payment removed/refunded' : 'token kept as forfeited'})`,
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setBusy(false);
    }
  }

  return (
    <Modal
      title={isReserved ? 'Edit Token / Hold Details' : 'Reserve Car (Bayana / Token Hold)'}
      subtitle={`${carTitle(deal)} · ${regOf(deal)}`}
      onClose={onClose}
      onSubmit={() => void submit()}
      width="max-w-lg"
      footer={
        <>
          {isReserved && !confirmCancel && (
            <button
              type="button"
              className="btn btn-secondary mr-auto text-red-600 hover:bg-red-50"
              onClick={() => setConfirmCancel(true)}
              disabled={busy}
            >
              Cancel Reservation
            </button>
          )}
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Close
          </button>
          <button type="submit" className="btn btn-primary" disabled={busy}>
            {isReserved ? 'Update Hold' : 'Confirm Token Hold'}
          </button>
        </>
      }
    >
      {error && <div className="mb-3 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}

      {confirmCancel && (
        <div className="mb-4 rounded-xl border border-red-200 bg-red-50 p-4 text-xs">
          <div className="font-bold text-red-900">Release this car back to Active Stock?</div>
          <p className="mt-1 text-red-700">
            Choose what happened to the buyer&apos;s token ({fmtMoney(deal.reserved_token_amount ?? deal.received_from_buyer)}):
          </p>
          <div className="mt-2.5 space-y-1.5">
            <label className="flex cursor-pointer items-center gap-2 font-medium text-ink-800">
              <input
                type="radio"
                name="tokenAction"
                checked={!refundOnCancel}
                onChange={() => setRefundOnCancel(false)}
              />
              <span>Forfeited / Keep recorded token payment in ledger</span>
            </label>
            <label className="flex cursor-pointer items-center gap-2 font-medium text-ink-800">
              <input
                type="radio"
                name="tokenAction"
                checked={refundOnCancel}
                onChange={() => setRefundOnCancel(true)}
              />
              <span>Refunded to buyer (delete Token payment entry)</span>
            </label>
          </div>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              className="btn btn-danger btn-sm"
              disabled={busy}
              onClick={() => void handleCancelReservation()}
            >
              Confirm Release to Stock
            </button>
            <button type="button" className="btn btn-secondary btn-sm" onClick={() => setConfirmCancel(false)}>
              Keep Reserved
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-x-4 gap-y-3">
        <Field label="Buyer Name">
          <input
            className="input"
            list="reserve-party-list"
            value={buyerName}
            onChange={(e) => applyParty(e.target.value)}
            placeholder="Who gave token / bayana?"
            data-autofocus
          />
          <datalist id="reserve-party-list">
            {parties.map((p) => (
              <option key={`${p.name}-${p.contact}`} value={p.name}>
                {p.contact ? `${p.contact} (${p.roles.join('/')})` : p.roles.join('/')}
              </option>
            ))}
          </datalist>
        </Field>
        <Field label="Buyer Contact">
          <input
            className="input"
            inputMode="tel"
            value={buyerContact}
            onChange={(e) => setBuyerContact(formatPhone(e.target.value))}
            placeholder="03xx-xxxxxxx"
          />
        </Field>

        <Field label="Token / Bayana Amount (Rs)">
          <MoneyInput
            value={tokenAmount}
            onChange={setTokenAmount}
            placeholder="100,000"
            disabled={isReserved}
          />
        </Field>
        <Field label="Payment Method">
          <select
            className="input"
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
            disabled={isReserved}
          >
            {PAYMENT_METHODS.map((m) => (
              <option key={m}>{m}</option>
            ))}
          </select>
        </Field>

        <Field label="Token Received Date">
          <input type="date" className="input" value={reservedDate} onChange={(e) => setReservedDate(e.target.value)} />
        </Field>
        <Field label="Hold Expiry / Final Payment Date">
          <input type="date" className="input" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} />
        </Field>

        <Field label="Reservation Notes" className="col-span-2">
          <textarea
            rows={2}
            className="input"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. Agreed final price Rs 3,650,000 if cleared by Friday; otherwise token forfeited."
          />
        </Field>
      </div>

      {!isReserved && (
        <p className="mt-3 text-xs text-ink-500">
          Saving a Token Amount automatically logs an incoming <strong>Token</strong> payment in the deal&apos;s Payments Ledger.
        </p>
      )}
    </Modal>
  );
}
