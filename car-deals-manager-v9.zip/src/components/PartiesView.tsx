import { useEffect, useMemo, useState } from 'react';
import type { DealWithTotals, Expense, PartyLedgerEntry, PartyRole, Payment } from '../types';
import { buildPartyLedger, carTitle, fmtDate, fmtMoney, regOf } from '../utils';

interface Props {
  deals: DealWithTotals[];
  canViewProfit?: boolean;
  canManagePayments?: boolean;
  onInspectDeal: (deal: DealWithTotals) => void;
  onPayments: (deal: DealWithTotals) => void;
  onWhatsApp: (deal: DealWithTotals, mode: 'SPECS' | 'RECEIPT') => void;
}

type RoleFilter = 'ALL' | PartyRole | 'OPEN_BALANCE';

export default function PartiesView({
  deals,
  canViewProfit = true,
  canManagePayments = true,
  onInspectDeal,
  onPayments,
  onWhatsApp,
}: Props) {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<RoleFilter>('ALL');
  const [expandedKey, setExpandedKey] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      if (!window.api) {
        if (alive) setLoading(false);
        return;
      }
      try {
        const [exps, pays] = await Promise.all([window.api.listAllExpenses(), window.api.listAllPayments()]);
        if (alive) {
          setExpenses(exps);
          setPayments(pays);
        }
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [deals]);

  const parties = useMemo<PartyLedgerEntry[]>(
    () => buildPartyLedger(deals, expenses, payments),
    [deals, expenses, payments],
  );

  const summary = useMemo(() => {
    let receivables = 0;
    let payables = 0;
    let commissions = 0;
    let pendingCheques = 0;
    for (const p of parties) {
      receivables += p.receivableDue;
      payables += p.payableDue;
      commissions += p.commissionTotal;
      pendingCheques += p.pendingCheques;
    }
    return {
      totalContacts: parties.length,
      receivables,
      payables,
      commissions,
      pendingCheques,
    };
  }, [parties]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return parties.filter((p) => {
      if (roleFilter === 'OPEN_BALANCE') {
        if (p.receivableDue <= 0 && p.payableDue <= 0 && p.pendingCheques <= 0) return false;
      } else if (roleFilter !== 'ALL' && !p.roles.includes(roleFilter)) {
        return false;
      }
      if (!q) return true;
      const hay = [
        p.name,
        p.father_name,
        p.contact,
        p.cnic,
        p.address,
        p.roles.join(' '),
        ...p.items.map((it) => `${carTitle(it.deal)} ${regOf(it.deal)}`),
      ]
        .filter(Boolean)
        .join(' | ')
        .toLowerCase();
      return q.split(/\s+/).every((token) => hay.includes(token));
    });
  }, [parties, query, roleFilter]);

  const roleBadgeClass = (role: PartyRole) => {
    if (role === 'Buyer') return 'bg-emerald-50 text-emerald-700 ring-emerald-200';
    if (role === 'Seller') return 'bg-amber-50 text-amber-800 ring-amber-200';
    if (role === 'Broker') return 'bg-purple-50 text-purple-700 ring-purple-200';
    return 'bg-indigo-50 text-indigo-700 ring-indigo-200';
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto pb-4">
      {/* KPI Strip */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-ink-200 bg-white p-4 shadow-sm">
          <div className="text-[11px] font-bold uppercase tracking-wider text-ink-500">Total Directory Contacts</div>
          <div className="mt-1.5 text-2xl font-bold tabular-nums text-ink-900">{summary.totalContacts}</div>
          <div className="mt-0.5 text-xs text-ink-500">Buyers, sellers, agents &amp; brokers</div>
        </div>

        <div className="rounded-xl border border-ink-200 bg-white p-4 shadow-sm">
          <div className="text-[11px] font-bold uppercase tracking-wider text-ink-500">Combined Receivables</div>
          <div className="mt-1.5 text-2xl font-bold tabular-nums text-emerald-700">{fmtMoney(summary.receivables)}</div>
          <div className="mt-0.5 text-xs text-ink-500">Total due from all buyers</div>
        </div>

        <div className="rounded-xl border border-ink-200 bg-white p-4 shadow-sm">
          <div className="text-[11px] font-bold uppercase tracking-wider text-ink-500">Combined Payables</div>
          <div className="mt-1.5 text-2xl font-bold tabular-nums text-amber-700">
            {canViewProfit ? fmtMoney(summary.payables) : 'Restricted'}
          </div>
          <div className="mt-0.5 text-xs text-ink-500">
            {summary.pendingCheques > 0
              ? `${summary.pendingCheques} pending/bounced cheque${summary.pendingCheques === 1 ? '' : 's'}`
              : 'Total due to all sellers'}
          </div>
        </div>

        <div className="rounded-xl border border-ink-200 bg-white p-4 shadow-sm">
          <div className="text-[11px] font-bold uppercase tracking-wider text-ink-500">Broker Commissions</div>
          <div className="mt-1.5 text-2xl font-bold tabular-nums text-purple-700">
            {canViewProfit ? fmtMoney(summary.commissions) : 'Restricted'}
          </div>
          <div className="mt-0.5 text-xs text-ink-500">Total commission payouts tracked</div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col gap-3 rounded-xl border border-ink-200 bg-white p-3.5 shadow-2xs sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-1.5">
          {(
            [
              { id: 'ALL', label: 'All Parties' },
              { id: 'Buyer', label: 'Buyers' },
              { id: 'Seller', label: 'Sellers' },
              { id: 'Broker', label: 'Brokers' },
              { id: 'Agent', label: 'Agents / Mechanics' },
              { id: 'OPEN_BALANCE', label: 'Open Balances' },
            ] as { id: RoleFilter; label: string }[]
          ).map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setRoleFilter(f.id)}
              className={`min-h-[36px] rounded-lg border px-3 py-1.5 text-xs font-semibold transition ${
                roleFilter === f.id
                  ? 'border-brand-600 bg-brand-600 text-white shadow-2xs'
                  : 'border-ink-200 bg-ink-50 text-ink-700 hover:bg-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-80">
          <input
            type="text"
            className="input pr-8 text-xs"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search person, phone, CNIC, reg #…"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="Clear search"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded px-1.5 py-0.5 text-xs font-bold text-ink-500 hover:bg-ink-100"
            >
              ×
            </button>
          )}
        </div>
      </div>

      {/* Directory List */}
      <div className="rounded-xl border border-ink-200 bg-white shadow-2xs">
        {loading ? (
          <div className="py-12 text-center text-sm text-ink-500">Loading parties &amp; commission ledger…</div>
        ) : filtered.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <div className="text-sm font-semibold text-ink-900">No contacts matched</div>
            <p className="mt-1 text-xs text-ink-500">
              Buyers, sellers, transfer agents, and broker/mechanic payees from your deals appear here automatically.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-ink-100">
            {filtered.map((party) => {
              const isOpen = expandedKey === party.key;
              return (
                <div key={party.key} className="transition-colors hover:bg-ink-50/40">
                  <button
                    type="button"
                    onClick={() => setExpandedKey(isOpen ? null : party.key)}
                    className="flex w-full flex-col gap-3 px-4 py-3.5 text-left sm:flex-row sm:items-center sm:justify-between sm:px-5"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-bold text-ink-900">{party.name}</span>
                        {party.father_name && (
                          <span className="text-xs text-ink-500">S/O {party.father_name}</span>
                        )}
                        {party.roles.map((r) => (
                          <span
                            key={r}
                            className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ring-1 ring-inset ${roleBadgeClass(r)}`}
                          >
                            {r}
                          </span>
                        ))}
                        {party.pendingCheques > 0 && (
                          <span className="rounded-full bg-red-50 px-2 py-0.5 text-[10px] font-bold text-red-700 ring-1 ring-inset ring-red-200">
                            {party.pendingCheques} Pending Cheque{party.pendingCheques === 1 ? '' : 's'}
                          </span>
                        )}
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-ink-500">
                        {party.contact && <span className="font-mono">{party.contact}</span>}
                        {party.cnic && <span className="font-mono">CNIC: {party.cnic}</span>}
                        {party.address && <span className="truncate">{party.address}</span>}
                        <span className="font-semibold text-ink-600">
                          {party.items.length} deal interaction{party.items.length === 1 ? '' : 's'}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-4 sm:justify-end">
                      <div className="flex flex-wrap items-center gap-4 text-right tabular-nums">
                        {party.receivableDue > 0 && (
                          <div>
                            <div className="text-[10px] font-bold uppercase text-emerald-700">Receivable</div>
                            <div className="text-sm font-extrabold text-emerald-700">{fmtMoney(party.receivableDue)}</div>
                          </div>
                        )}
                        {canViewProfit && party.payableDue > 0 && (
                          <div>
                            <div className="text-[10px] font-bold uppercase text-amber-700">Payable</div>
                            <div className="text-sm font-extrabold text-amber-700">{fmtMoney(party.payableDue)}</div>
                          </div>
                        )}
                        {canViewProfit && party.commissionTotal > 0 && (
                          <div>
                            <div className="text-[10px] font-bold uppercase text-purple-700">Commission</div>
                            <div className="text-sm font-extrabold text-purple-700">{fmtMoney(party.commissionTotal)}</div>
                          </div>
                        )}
                        {canViewProfit && party.otherPayeeTotal > 0 && (
                          <div>
                            <div className="text-[10px] font-bold uppercase text-ink-500">Service Paid</div>
                            <div className="text-sm font-bold text-ink-700">{fmtMoney(party.otherPayeeTotal)}</div>
                          </div>
                        )}
                        {party.receivableDue === 0 &&
                          (!canViewProfit || (party.payableDue === 0 && party.commissionTotal === 0 && party.otherPayeeTotal === 0)) && (
                            <span className="rounded bg-ink-100 px-2 py-0.5 text-[11px] font-semibold text-ink-600">
                              Settled
                            </span>
                          )}
                      </div>
                      <span className="text-xs font-bold text-brand-600">{isOpen ? 'Hide ▲' : 'Details ▼'}</span>
                    </div>
                  </button>

                  {isOpen && (
                    <div className="border-t border-ink-100 bg-ink-50/70 px-4 py-3 sm:px-5">
                      <div className="space-y-2">
                        {party.items.map((item, idx) => (
                          <div
                            key={`${item.deal.id}-${item.role}-${idx}`}
                            className="flex flex-col justify-between gap-2 rounded-lg border border-ink-200 bg-white p-3 text-xs sm:flex-row sm:items-center"
                          >
                            <div className="min-w-0">
                              <div className="flex flex-wrap items-center gap-2">
                                <span
                                  className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ring-1 ring-inset ${roleBadgeClass(item.role)}`}
                                >
                                  {item.role}
                                </span>
                                <span className="rounded border border-ink-300 bg-ink-50 px-1.5 py-px font-mono font-bold text-ink-800">
                                  {regOf(item.deal)}
                                </span>
                                <span className="font-bold text-ink-900">{carTitle(item.deal)}</span>
                                {item.date && <span className="text-ink-400">· {fmtDate(item.date)}</span>}
                              </div>
                              <div className="mt-1 flex flex-wrap gap-3 text-[11px] text-ink-600 tabular-nums">
                                {(item.role === 'Buyer' || (canViewProfit && item.role === 'Seller')) && item.amount > 0 && (
                                  <span>
                                    Deal Amount: <strong>{fmtMoney(item.amount)}</strong>
                                  </span>
                                )}
                                {item.balanceDue > 0 && (item.role === 'Buyer' || canViewProfit) && (
                                  <span className={item.role === 'Buyer' ? 'font-bold text-emerald-700' : 'font-bold text-amber-700'}>
                                    Balance Due: {fmtMoney(item.balanceDue)}
                                  </span>
                                )}
                                {canViewProfit && item.commissionAmount > 0 && (
                                  <span className="font-bold text-purple-700">
                                    Payout: {fmtMoney(item.commissionAmount)}
                                  </span>
                                )}
                                {item.role === 'Agent' && item.amount > 0 && (
                                  <span>Transfer Fee: {fmtMoney(item.amount)}</span>
                                )}
                              </div>
                            </div>

                            <div className="flex flex-wrap items-center gap-1.5">
                              <button
                                type="button"
                                className="btn btn-secondary btn-sm"
                                onClick={() => onInspectDeal(item.deal)}
                              >
                                Inspect Car
                              </button>
                              {canManagePayments && (
                                <button
                                  type="button"
                                  className="btn btn-secondary btn-sm"
                                  onClick={() => onPayments(item.deal)}
                                >
                                  Payments
                                </button>
                              )}
                              <button
                                type="button"
                                className="btn btn-sm bg-[#25D366] text-white hover:bg-[#1ebe5d]"
                                onClick={() =>
                                  onWhatsApp(item.deal, item.deal.status === 'SOLD' ? 'RECEIPT' : 'SPECS')
                                }
                              >
                                WhatsApp
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
