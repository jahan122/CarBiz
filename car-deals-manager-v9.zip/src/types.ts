export type DealStatus = 'ACTIVE' | 'RESERVED' | 'SOLD';
export type TransferStatus = 'PENDING' | 'WITH_AGENT' | 'COMPLETED';
export type UserRole = 'OWNER' | 'STAFF';
export type ChequeStatus = 'PENDING' | 'CLEARED' | 'BOUNCED';

export interface AppUser {
  id: number;
  name: string;
  role: UserRole;
  can_view_profit: boolean;
  can_manage_payments: boolean;
  can_mark_sold: boolean;
  can_delete: boolean;
  created_at: string;
}

export interface CreateUserInput {
  name: string;
  pin: string;
  role: UserRole;
  can_view_profit?: boolean;
  can_manage_payments?: boolean;
  can_mark_sold?: boolean;
  can_delete?: boolean;
}

export interface UpdateUserInput {
  name?: string;
  pin?: string;
  role?: UserRole;
  can_view_profit?: boolean;
  can_manage_payments?: boolean;
  can_mark_sold?: boolean;
  can_delete?: boolean;
}

export type AttachmentCategory =
  | 'CNIC_FRONT'
  | 'CNIC_BACK'
  | 'REGISTRATION_BOOK'
  | 'SMART_CARD'
  | 'OTHER';

export const ATTACHMENT_CATEGORY_LABELS: Record<AttachmentCategory, string> = {
  CNIC_FRONT: 'CNIC (Front)',
  CNIC_BACK: 'CNIC (Back)',
  REGISTRATION_BOOK: 'Registration Book',
  SMART_CARD: 'Smart Card',
  OTHER: 'Other Document / Photo',
};

export const EXPENSE_CATEGORIES = [
  'Mechanic/Repair',
  'Denting/Painting',
  'Parts',
  'Detailing',
  'Commission',
  'Documentation/Tax',
  'Other',
] as const;
export type ExpenseCategory = (typeof EXPENSE_CATEGORIES)[number];

export type PaymentDirection = 'OUT_TO_SELLER' | 'IN_FROM_BUYER';
export type PaymentType = 'Advance' | 'Installment' | 'Final Balance' | 'Token' | 'Other';
export type PaymentMethod = 'Cash' | 'Bank Transfer' | 'Cheque' | 'Online/JazzCash/EasyPaisa' | 'Other';

export const PAYMENT_TYPES: readonly PaymentType[] = ['Advance', 'Installment', 'Final Balance', 'Token', 'Other'];
export const PAYMENT_METHODS: readonly PaymentMethod[] = ['Cash', 'Bank Transfer', 'Cheque', 'Online/JazzCash/EasyPaisa', 'Other'];

export const CHECKLIST_ITEMS = [
  { key: 'original_file', label: 'Original File', group: 'DOCS', critical: true },
  { key: 'smart_card_book', label: 'Smart Card / Reg Book', group: 'DOCS', critical: true },
  { key: 'biometric_slip', label: 'Biometric / Owner Ready', group: 'DOCS', critical: true },
  { key: 'token_tax_paid', label: 'Token Tax Paid', group: 'DOCS', critical: false },
  { key: 'number_plates', label: 'Original Plates (2)', group: 'DOCS', critical: true },
  { key: 'sale_deed_signed', label: 'Transfer / Sale Letter', group: 'DOCS', critical: false },
  { key: 'excise_cplc_ok', label: 'Excise / CPLC Verified', group: 'DOCS', critical: true },
  { key: 'engine_checked', label: 'Engine / Mechanical OK', group: 'COND', critical: false },
  { key: 'body_paint_checked', label: 'Body / Paint Checked', group: 'COND', critical: false },
  { key: 'suspension_tyres', label: 'Suspension & Tyres OK', group: 'COND', critical: false },
  { key: 'ac_electronics', label: 'AC & Electronics OK', group: 'COND', critical: false },
  { key: 'spare_tools', label: 'Spare Wheel & Tools', group: 'COND', critical: false },
] as const;

export type ChecklistKey = (typeof CHECKLIST_ITEMS)[number]['key'];
export type DealChecklist = Partial<Record<ChecklistKey, boolean>>;

export interface CarDeal {
  id: number;
  status: DealStatus;
  make: string | null;
  model: string | null;
  variant: string | null;
  year: number | null;
  color: string | null;
  horse_power: string | null;
  registration_number: string | null;
  chassis_number: string | null;
  engine_number: string | null;
  mileage: number | null;
  bought_from_location: string | null;
  purchase_date: string | null;
  purchase_price: number | null;
  seller_name: string | null;
  seller_father_name: string | null;
  seller_contact: string | null;
  seller_cnic: string | null;
  seller_address: string | null;
  seller_due_date: string | null;
  reserved_date: string | null;
  reserved_expiry_date: string | null;
  reserved_token_amount: number | null;
  reserved_buyer_name: string | null;
  reserved_buyer_contact: string | null;
  reserved_notes: string | null;
  sale_date: string | null;
  sale_price: number | null;
  purchaser_name: string | null;
  purchaser_father_name: string | null;
  purchaser_contact: string | null;
  purchaser_cnic: string | null;
  purchaser_address: string | null;
  buyer_due_date: string | null;
  transfer_status: TransferStatus;
  transfer_agent_name: string | null;
  transfer_agent_contact: string | null;
  file_handover_date: string | null;
  transfer_completed_date: string | null;
  transfer_cost: number;
  transfer_notes: string | null;
  token_tax_paid_till: string | null;
  checklist_json: string | null;
  trade_in_deal_id: number | null;
  trade_in_for_deal_id: number | null;
  notes: string | null;
  created_by: string | null;
  deleted_at: string | null;
  created_at: string;
}

export interface DealWithTotals extends CarDeal {
  total_expenses: number;
  paid_to_seller: number;
  received_from_buyer: number;
  attachment_count: number;
}

export interface Expense {
  id: number;
  car_deal_id: number;
  category: ExpenseCategory;
  description: string;
  payee_name?: string | null;
  amount: number;
  date: string;
  created_by?: string | null;
}

export interface Payment {
  id: number;
  car_deal_id: number;
  direction: PaymentDirection;
  payment_type: PaymentType;
  method: PaymentMethod;
  amount: number;
  date: string;
  notes: string;
  cheque_number?: string | null;
  cheque_date?: string | null;
  cheque_status?: ChequeStatus | null;
  created_by?: string | null;
}

export interface DealAttachment {
  id: number;
  car_deal_id: number;
  category: AttachmentCategory;
  label: string;
  file_name: string;
  file_path: string;
  created_at: string;
}

export interface AuditLogEntry {
  id: number;
  entity_type: string;
  entity_id: number;
  deal_id: number | null;
  action: string;
  actor_name: string | null;
  summary: string;
  changes_json: string | null;
  created_at: string;
}

export type CloudProviderId = 'NONE' | 'LOCAL_FOLDER' | 'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE';

export interface CloudBackupSettings {
  provider?: CloudProviderId;
  cloud_backup_dir: string;
  account_email?: string | null;
  auto_sync_live?: boolean;
  last_local_backup_at?: string | null;
  last_synced_at: string | null;
  last_error: string | null;
}

export interface BusinessProfile {
  business_name: string;
  tagline: string;
  owner_name: string;
  father_name: string;
  cnic: string;
  phone: string;
  address: string;
}

export const DEFAULT_BUSINESS_PROFILE: BusinessProfile = {
  business_name: '',
  tagline: '',
  owner_name: '',
  father_name: '',
  cnic: '',
  phone: '',
  address: '',
};

export interface BackupFileInfo {
  name: string;
  path: string;
  size: number;
  mtime: string;
  kind: 'zip' | 'db';
}

export interface NewDealInput {
  make?: string | null;
  model?: string | null;
  variant?: string | null;
  year?: number | string | null;
  color?: string | null;
  horse_power?: string | null;
  registration_number?: string | null;
  chassis_number?: string | null;
  engine_number?: string | null;
  mileage?: number | string | null;
  bought_from_location?: string | null;
  purchase_date?: string | null;
  purchase_price?: number | string | null;
  seller_name?: string | null;
  seller_father_name?: string | null;
  seller_contact?: string | null;
  seller_cnic?: string | null;
  seller_address?: string | null;
  seller_due_date?: string | null;
  token_tax_paid_till?: string | null;
  checklist_json?: string | null;
  notes?: string | null;
  created_by?: string | null;
}

export interface TradeInInput {
  valuation: number | string;
  make?: string | null;
  model?: string | null;
  variant?: string | null;
  year?: number | string | null;
  color?: string | null;
  horse_power?: string | null;
  registration_number?: string | null;
  chassis_number?: string | null;
  engine_number?: string | null;
  mileage?: number | string | null;
  notes?: string | null;
}

export interface SaleInput {
  sale_date?: string | null;
  sale_price?: number | string | null;
  purchaser_name?: string | null;
  purchaser_father_name?: string | null;
  purchaser_contact?: string | null;
  purchaser_cnic?: string | null;
  purchaser_address?: string | null;
  buyer_due_date?: string | null;
  tradeIn?: TradeInInput | null;
}

export interface ReserveInput {
  reserved_date?: string | null;
  reserved_expiry_date?: string | null;
  reserved_token_amount?: number | string | null;
  reserved_buyer_name?: string | null;
  reserved_buyer_contact?: string | null;
  reserved_notes?: string | null;
  payment_method?: PaymentMethod;
  payment_notes?: string;
}

export interface InitialPaymentInput {
  amount: number | string;
  payment_type?: PaymentType;
  method?: PaymentMethod;
  date?: string;
  notes?: string;
  cheque_number?: string | null;
  cheque_date?: string | null;
  cheque_status?: ChequeStatus | null;
}

export interface TransferInput {
  transfer_status?: TransferStatus;
  transfer_agent_name?: string | null;
  transfer_agent_contact?: string | null;
  file_handover_date?: string | null;
  transfer_completed_date?: string | null;
  transfer_cost?: number | string | null;
  transfer_notes?: string | null;
}

export interface DueDatesInput {
  seller_due_date?: string | null;
  buyer_due_date?: string | null;
}

export type PartyRole = 'Seller' | 'Buyer' | 'Agent' | 'Broker';

export interface SavedParty {
  name: string;
  father_name: string;
  contact: string;
  cnic: string;
  address: string;
  roles: ('Seller' | 'Buyer' | 'Agent')[];
  dealCount: number;
}

export interface PartyLedgerDealItem {
  deal: DealWithTotals;
  role: PartyRole;
  amount: number;
  balanceDue: number;
  commissionAmount: number;
  date: string | null;
}

export interface PartyLedgerEntry {
  key: string;
  name: string;
  father_name: string;
  contact: string;
  cnic: string;
  address: string;
  roles: PartyRole[];
  dealCount: number;
  receivableDue: number;
  payableDue: number;
  commissionTotal: number;
  otherPayeeTotal: number;
  pendingCheques: number;
  items: PartyLedgerDealItem[];
}

export type DealFormData = NewDealInput;
export type SaleFormData = SaleInput;
export type TransferFormData = TransferInput;

export interface CarDealsApi {
  isElectron?: boolean;
  listDeals(): Promise<DealWithTotals[]>;
  listDeletedDeals(): Promise<DealWithTotals[]>;
  getDeal(id: number): Promise<DealWithTotals>;
  createDeal(
    input: NewDealInput,
    sale?: SaleInput | null,
    initialPayments?: {
      sellerPayment?: InitialPaymentInput | null;
      buyerPayment?: InitialPaymentInput | null;
    } | null,
  ): Promise<DealWithTotals>;
  updateDeal(id: number, input: NewDealInput): Promise<DealWithTotals>;
  softDeleteDeal(id: number): Promise<void>;
  restoreDeal(id: number): Promise<DealWithTotals>;
  deleteDeal(id: number): Promise<void>;
  emptyRecycleBin(): Promise<void>;
  reserveDeal(id: number, input: ReserveInput): Promise<DealWithTotals>;
  cancelReservation(id: number, refundToken?: boolean): Promise<DealWithTotals>;
  markSold(id: number, sale: SaleInput, initialBuyerPayment?: InitialPaymentInput | null): Promise<DealWithTotals>;
  revertSale(id: number, deleteBuyerPayments?: boolean): Promise<DealWithTotals>;
  updateTransfer(id: number, input: TransferInput): Promise<DealWithTotals>;
  updateDueDates(id: number, input: DueDatesInput): Promise<DealWithTotals>;
  updateChecklist(id: number, checklistJson: string, tokenTaxPaidTill?: string | null): Promise<DealWithTotals>;
  listAttachments(dealId: number): Promise<DealAttachment[]>;
  pickAndAddAttachment(dealId: number, category: AttachmentCategory, label?: string): Promise<DealAttachment | null>;
  pickAndSaveAttachment(dealId: number, category: AttachmentCategory, label?: string): Promise<DealAttachment | null>;
  saveWebcamAttachment(dealId: number, category: AttachmentCategory, label: string, dataUrl: string): Promise<DealAttachment>;
  saveAttachmentData(
    dealId: number,
    category: AttachmentCategory,
    label: string,
    fileName: string,
    dataUrl: string,
  ): Promise<DealAttachment>;
  readAttachmentDataUrl(filePath: string): Promise<string | null>;
  getAttachmentDataUrl(filePath: string): Promise<string | null>;
  deleteAttachment(id: number): Promise<void>;
  listExpenses(dealId: number): Promise<Expense[]>;
  listAllExpenses(): Promise<Expense[]>;
  addExpense(
    dealId: number,
    input: { category: ExpenseCategory; description: string; payee_name?: string | null; amount: string | number; date: string; created_by?: string },
  ): Promise<Expense>;
  updateExpense(
    id: number,
    input: { category: ExpenseCategory; description: string; payee_name?: string | null; amount: string | number; date: string },
  ): Promise<Expense>;
  deleteExpense(id: number): Promise<void>;
  listPayments(dealId: number): Promise<Payment[]>;
  listAllPayments(): Promise<Payment[]>;
  addPayment(
    dealId: number,
    input: {
      direction: PaymentDirection;
      payment_type: PaymentType;
      method: PaymentMethod;
      amount: string | number;
      date: string;
      notes: string;
      cheque_number?: string | null;
      cheque_date?: string | null;
      cheque_status?: ChequeStatus | null;
      created_by?: string;
    },
  ): Promise<Payment>;
  updatePayment(
    id: number,
    input: {
      direction: PaymentDirection;
      payment_type: PaymentType;
      method: PaymentMethod;
      amount: string | number;
      date: string;
      notes: string;
      cheque_number?: string | null;
      cheque_date?: string | null;
      cheque_status?: ChequeStatus | null;
    },
  ): Promise<Payment>;
  updateChequeStatus(id: number, status: ChequeStatus): Promise<Payment>;
  deletePayment(id: number): Promise<void>;
  listAuditLogs(dealId?: number, limit?: number): Promise<AuditLogEntry[]>;
  hasUsers(): Promise<boolean>;
  listUsers(): Promise<AppUser[]>;
  createUser(input: CreateUserInput): Promise<AppUser>;
  updateUser(id: number, input: UpdateUserInput): Promise<AppUser>;
  deleteUser(id: number): Promise<void>;
  authenticatePin(pin: string, userId?: number): Promise<AppUser | null>;
  lockApp(): Promise<void>;
  getAutoLockMinutes(): Promise<number>;
  setAutoLockMinutes(minutes: number): Promise<number>;
  getBusinessProfile(): Promise<BusinessProfile>;
  setBusinessProfile(profile: Partial<BusinessProfile>): Promise<BusinessProfile>;
  listAutoBackups(): Promise<BackupFileInfo[]>;
  autoBackupFolder(): Promise<string>;
  getCloudBackupSettings(): Promise<CloudBackupSettings>;
  pickCloudBackupFolder(): Promise<CloudBackupSettings>;
  clearCloudBackupFolder(): Promise<CloudBackupSettings>;
  getCloudClientIds?(): Promise<Partial<Record<'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE', string>>>;
  saveCloudClientId?(
    provider: 'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE',
    clientId: string,
  ): Promise<Partial<Record<'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE', string>>>;
  connectCloudProvider?(
    provider: 'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE',
    clientId?: string,
  ): Promise<CloudBackupSettings>;
  disconnectCloudProvider?(): Promise<CloudBackupSettings>;
  onCloudOAuthCompleted?(
    callback: (payload: { provider: string; accountEmail: string | null }) => void,
  ): () => void;
  pullLatestFromCloud?(): Promise<{ pulled: boolean; restored?: boolean; count?: number; message?: string; error?: string }>;
  syncBackupNow(): Promise<{ synced: boolean; localPath?: string; cloudPath?: string; error?: string }>;
  backupOrExport(kind: 'zip' | 'db' | 'csv'): Promise<{ saved: boolean; path?: string }>;
  restoreFromPath(backupPath: string): Promise<{ restored: boolean; count?: number; sourceName?: string }>;
  restoreFromBackup(backupPath?: string): Promise<{ restored: boolean; count?: number; sourceName?: string }>;
  pickAndRestore(): Promise<{ restored: boolean; count?: number; sourceName?: string }>;
  exportBrowserZipBlob?(): Promise<{ blob: Blob; filename: string }>;
  importBrowserZipFile?(file: File): Promise<{ restored: boolean; count: number; sourceName: string }>;
  saveReceiptPdf(html: string, defaultFileName: string): Promise<{ saved: boolean; path?: string }>;
  printReceiptHtml(html: string): Promise<void>;
  showInFolder(filePath: string): Promise<void>;
  openExternalUrl(url: string): Promise<void>;
}

declare global {
  interface Window {
    api?: CarDealsApi;
  }
}