import {
  CHECKLIST_ITEMS,
  type DealChecklist,
  type DealWithTotals,
  type Expense,
  type PartyLedgerEntry,
  type PartyRole,
  type Payment,
  type SavedParty,
} from './types';

export const fmtMoney = (n: number | null | undefined): string =>
  n === null || n === undefined ? '—' : 'Rs ' + Math.round(n).toLocaleString('en-US');

export function fmtDate(s: string | null | undefined): string {
  if (!s) return '—';
  const [y, m, d] = s.split('-').map(Number);
  if (!y || !m || !d) return s;
  return new Date(y, m - 1, d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function parseNum(s: string): number | null {
  const t = s.replace(/[^0-9.\-]/g, '');
  if (t === '' || t === '-' || t === '.') return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

export function parseIntOrNull(s: string): number | null {
  const n = parseNum(s);
  return n === null ? null : Math.trunc(n);
}

export const textOrNull = (s: string): string | null => (s.trim() === '' ? null : s.trim());

export function formatCnic(v: string): string {
  const d = v.replace(/\D/g, '').slice(0, 13);
  if (d.length <= 5) return d;
  if (d.length <= 12) return `${d.slice(0, 5)}-${d.slice(5)}`;
  return `${d.slice(0, 5)}-${d.slice(5, 12)}-${d.slice(12)}`;
}

export function formatPhone(v: string): string {
  let d = v.replace(/\D/g, '');
  if (d.startsWith('92') && d.length >= 12) d = '0' + d.slice(2);
  else if (d.startsWith('3') && d.length >= 10) d = '0' + d;
  d = d.slice(0, 11);
  return d.length <= 4 ? d : `${d.slice(0, 4)}-${d.slice(4)}`;
}

export const normalizeReg = (s: string | null | undefined): string => (s ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');
export const regOf = (d: Pick<DealWithTotals, 'registration_number'>): string => d.registration_number || 'No reg #';

export function totalCost(d: DealWithTotals): number {
  return (d.purchase_price ?? 0) + (d.total_expenses ?? 0) + (d.transfer_cost ?? 0);
}

export function netProfit(d: DealWithTotals): number | null {
  if (d.status !== 'SOLD' || d.sale_price === null || d.purchase_price === null) return null;
  return d.sale_price - totalCost(d);
}

export function sellerBalanceSigned(d: Pick<DealWithTotals, 'purchase_price' | 'paid_to_seller'>): number | null {
  if (d.purchase_price === null) return null;
  return d.purchase_price - (d.paid_to_seller ?? 0);
}

export function sellerBalanceDue(d: Pick<DealWithTotals, 'purchase_price' | 'paid_to_seller'>): number | null {
  const s = sellerBalanceSigned(d);
  return s === null ? null : Math.max(0, s);
}

export function sellerOverpaid(d: Pick<DealWithTotals, 'purchase_price' | 'paid_to_seller'>): number {
  const s = sellerBalanceSigned(d);
  return s !== null && s < 0 ? Math.abs(s) : 0;
}

export function buyerBalanceSigned(d: Pick<DealWithTotals, 'status' | 'sale_price' | 'received_from_buyer'>): number | null {
  if (d.status !== 'SOLD' || d.sale_price === null) return null;
  return d.sale_price - (d.received_from_buyer ?? 0);
}

export function buyerBalanceDue(d: Pick<DealWithTotals, 'status' | 'sale_price' | 'received_from_buyer'>): number | null {
  const b = buyerBalanceSigned(d);
  return b === null ? null : Math.max(0, b);
}

export function buyerOverpaid(d: Pick<DealWithTotals, 'status' | 'sale_price' | 'received_from_buyer'>): number {
  const b = buyerBalanceSigned(d);
  return b !== null && b < 0 ? Math.abs(b) : 0;
}

export const carTitle = (d: Pick<DealWithTotals, 'make' | 'model' | 'variant' | 'year'>): string =>
  [d.year, d.make, d.model, d.variant].filter(Boolean).join(' ') || 'Unnamed car';

export function matchesQuery(d: DealWithTotals, q: string): boolean {
  const needle = q.trim().toLowerCase();
  if (!needle) return true;
  const squash = (s: string) => s.replace(/[\s\-]/g, '');
  const hay = [
    d.registration_number,
    `${d.make ?? ''} ${d.model ?? ''}`,
    d.variant,
    d.bought_from_location,
    d.seller_name,
    d.seller_contact,
    d.seller_address,
    d.reserved_buyer_name,
    d.reserved_buyer_contact,
    d.purchaser_name,
    d.purchaser_contact,
    d.purchaser_address,
    d.chassis_number,
    d.engine_number,
  ]
    .filter(Boolean)
    .join(' | ')
    .toLowerCase();
  return needle.split(/\s+/).every((w) => hay.includes(w) || squash(hay).includes(squash(w)));
}

export function daysBetween(startIso: string | null | undefined, endIso?: string | null): number | null {
  if (!startIso) return null;
  const [sy, sm, sd] = startIso.slice(0, 10).split('-').map(Number);
  if (!sy || !sm || !sd) return null;
  const startMs = new Date(sy, sm - 1, sd).getTime();
  let endMs: number;
  if (endIso) {
    const [ey, em, ed] = endIso.slice(0, 10).split('-').map(Number);
    if (!ey || !em || !ed) return null;
    endMs = new Date(ey, em - 1, ed).getTime();
  } else {
    const now = new Date();
    endMs = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  }
  return Math.max(0, Math.round((endMs - startMs) / 86400000));
}

export function daysInStock(d: Pick<DealWithTotals, 'status' | 'purchase_date' | 'sale_date'>): number | null {
  if (!d.purchase_date) return null;
  if (d.status === 'SOLD' && d.sale_date) {
    return daysBetween(d.purchase_date, d.sale_date);
  }
  return daysBetween(d.purchase_date);
}

/** Positive = overdue by N days; 0 = due today; negative = N days remaining. */
export function daysPastDue(dueDateIso: string | null | undefined): number | null {
  if (!dueDateIso) return null;
  const [y, m, d] = dueDateIso.slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return null;
  const dueMs = new Date(y, m - 1, d).getTime();
  const now = new Date();
  const todayMs = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  return Math.round((todayMs - dueMs) / 86400000);
}

export function parseChecklist(json: string | null | undefined): DealChecklist {
  if (!json) return {};
  try {
    const parsed = JSON.parse(json) as unknown;
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as DealChecklist;
    }
  } catch {
    /* ignore */
  }
  return {};
}

export function checklistSummary(d: Pick<DealWithTotals, 'checklist_json'>): {
  checkedCount: number;
  totalCount: number;
  docsChecked: number;
  docsTotal: number;
  missingCriticalDocs: string[];
} {
  const map = parseChecklist(d.checklist_json);
  let checkedCount = 0;
  let docsChecked = 0;
  let docsTotal = 0;
  const missingCriticalDocs: string[] = [];

  for (const item of CHECKLIST_ITEMS) {
    const checked = Boolean(map[item.key]);
    if (checked) checkedCount++;
    if (item.group === 'DOCS') {
      docsTotal++;
      if (checked) docsChecked++;
      else if (item.critical) missingCriticalDocs.push(item.label);
    }
  }

  return {
    checkedCount,
    totalCount: CHECKLIST_ITEMS.length,
    docsChecked,
    docsTotal,
    missingCriticalDocs,
  };
}

function partyKey(name: string, contact?: string | null, cnic?: string | null): string {
  const cleanCnic = (cnic ?? '').replace(/\D/g, '');
  if (cleanCnic.length >= 13) return `cnic:${cleanCnic}`;
  const cleanPhone = (contact ?? '').replace(/\D/g, '');
  if (cleanPhone.length >= 9) return `phone:${cleanPhone}|${name.trim().toLowerCase()}`;
  return `name:${name.trim().toLowerCase()}`;
}

export function buildPartyDirectory(deals: DealWithTotals[]): SavedParty[] {
  const map = new Map<string, SavedParty>();

  const add = (
    role: 'Seller' | 'Buyer' | 'Agent',
    name: string | null | undefined,
    fatherName: string | null | undefined,
    contact: string | null | undefined,
    cnic: string | null | undefined,
    address: string | null | undefined,
  ) => {
    const cleanName = (name ?? '').trim();
    const cleanPhone = (contact ?? '').trim();
    const cleanCnic = (cnic ?? '').trim();
    if (!cleanName) return;

    const key = partyKey(cleanName, cleanPhone, cleanCnic);
    const existing = map.get(key);
    if (existing) {
      if (!existing.roles.includes(role)) existing.roles.push(role);
      if (!existing.father_name && fatherName) existing.father_name = fatherName.trim();
      if (!existing.contact && cleanPhone) existing.contact = cleanPhone;
      if (!existing.cnic && cleanCnic) existing.cnic = cleanCnic;
      if (!existing.address && address) existing.address = address.trim();
      existing.dealCount += 1;
    } else {
      map.set(key, {
        name: cleanName,
        father_name: (fatherName ?? '').trim(),
        contact: cleanPhone,
        cnic: cleanCnic,
        address: (address ?? '').trim(),
        roles: [role],
        dealCount: 1,
      });
    }
  };

  for (const d of deals) {
    add('Seller', d.seller_name, d.seller_father_name, d.seller_contact, d.seller_cnic, d.seller_address);
    add('Buyer', d.purchaser_name, d.purchaser_father_name, d.purchaser_contact, d.purchaser_cnic, d.purchaser_address);
    if (d.reserved_buyer_name) {
      add('Buyer', d.reserved_buyer_name, null, d.reserved_buyer_contact, null, null);
    }
    if (d.transfer_agent_name) {
      add('Agent', d.transfer_agent_name, null, d.transfer_agent_contact, null, null);
    }
  }

  return Array.from(map.values()).sort((a, b) => b.dealCount - a.dealCount || a.name.localeCompare(b.name));
}

export function buildPartyLedger(
  deals: DealWithTotals[],
  expenses: Expense[],
  payments: Payment[],
): PartyLedgerEntry[] {
  const map = new Map<string, PartyLedgerEntry>();
  const dealMap = new Map(deals.map((d) => [d.id, d]));

  const ensureEntry = (
    name: string,
    fatherName?: string | null,
    contact?: string | null,
    cnic?: string | null,
    address?: string | null,
  ): PartyLedgerEntry => {
    const cleanName = name.trim();
    const k = partyKey(cleanName, contact, cnic);
    let entry = map.get(k);
    if (!entry) {
      entry = {
        key: k,
        name: cleanName,
        father_name: (fatherName ?? '').trim(),
        contact: (contact ?? '').trim(),
        cnic: (cnic ?? '').trim(),
        address: (address ?? '').trim(),
        roles: [],
        dealCount: 0,
        receivableDue: 0,
        payableDue: 0,
        commissionTotal: 0,
        otherPayeeTotal: 0,
        pendingCheques: 0,
        items: [],
      };
      map.set(k, entry);
    } else {
      if (!entry.father_name && fatherName) entry.father_name = fatherName.trim();
      if (!entry.contact && contact) entry.contact = contact.trim();
      if (!entry.cnic && cnic) entry.cnic = cnic.trim();
      if (!entry.address && address) entry.address = address.trim();
    }
    return entry;
  };

  const pushRole = (entry: PartyLedgerEntry, role: PartyRole) => {
    if (!entry.roles.includes(role)) entry.roles.push(role);
  };

  for (const d of deals) {
    const pendingChequesIn = payments.filter(
      (p) => p.car_deal_id === d.id && p.method === 'Cheque' && (p.cheque_status === 'PENDING' || p.cheque_status === 'BOUNCED'),
    );

    if (d.seller_name?.trim()) {
      const entry = ensureEntry(d.seller_name, d.seller_father_name, d.seller_contact, d.seller_cnic, d.seller_address);
      pushRole(entry, 'Seller');
      const due = sellerBalanceDue(d) ?? 0;
      entry.payableDue += due;
      entry.dealCount += 1;
      entry.pendingCheques += pendingChequesIn.filter((p) => p.direction === 'OUT_TO_SELLER').length;
      entry.items.push({
        deal: d,
        role: 'Seller',
        amount: d.purchase_price ?? 0,
        balanceDue: due,
        commissionAmount: 0,
        date: d.purchase_date,
      });
    }

    if (d.purchaser_name?.trim()) {
      const entry = ensureEntry(
        d.purchaser_name,
        d.purchaser_father_name,
        d.purchaser_contact,
        d.purchaser_cnic,
        d.purchaser_address,
      );
      pushRole(entry, 'Buyer');
      const due = buyerBalanceDue(d) ?? 0;
      entry.receivableDue += due;
      entry.dealCount += 1;
      entry.pendingCheques += pendingChequesIn.filter((p) => p.direction === 'IN_FROM_BUYER').length;
      entry.items.push({
        deal: d,
        role: 'Buyer',
        amount: d.sale_price ?? 0,
        balanceDue: due,
        commissionAmount: 0,
        date: d.sale_date,
      });
    } else if (d.status === 'RESERVED' && d.reserved_buyer_name?.trim()) {
      const entry = ensureEntry(d.reserved_buyer_name, null, d.reserved_buyer_contact, null, null);
      pushRole(entry, 'Buyer');
      entry.dealCount += 1;
      entry.items.push({
        deal: d,
        role: 'Buyer',
        amount: d.reserved_token_amount ?? d.received_from_buyer ?? 0,
        balanceDue: 0,
        commissionAmount: 0,
        date: d.reserved_date,
      });
    }

    if (d.transfer_agent_name?.trim()) {
      const entry = ensureEntry(d.transfer_agent_name, null, d.transfer_agent_contact, null, null);
      pushRole(entry, 'Agent');
      entry.dealCount += 1;
      entry.items.push({
        deal: d,
        role: 'Agent',
        amount: d.transfer_cost ?? 0,
        balanceDue: 0,
        commissionAmount: 0,
        date: d.file_handover_date ?? d.transfer_completed_date,
      });
    }
  }

  for (const exp of expenses) {
    const deal = dealMap.get(exp.car_deal_id);
    if (!deal) continue;
    const rawPayee = exp.payee_name?.trim() || (exp.category === 'Commission' ? exp.description.trim() : '');
    if (!rawPayee) continue;
    const entry = ensureEntry(rawPayee);
    const isComm = exp.category === 'Commission';
    pushRole(entry, isComm ? 'Broker' : 'Agent');
    if (isComm) entry.commissionTotal += exp.amount;
    else entry.otherPayeeTotal += exp.amount;

    const existingItem = entry.items.find((it) => it.deal.id === deal.id && it.role === (isComm ? 'Broker' : 'Agent'));
    if (existingItem) {
      existingItem.commissionAmount += exp.amount;
    } else {
      entry.dealCount += 1;
      entry.items.push({
        deal,
        role: isComm ? 'Broker' : 'Agent',
        amount: 0,
        balanceDue: 0,
        commissionAmount: exp.amount,
        date: exp.date,
      });
    }
  }

  return Array.from(map.values()).sort((a, b) => {
    const balA = a.receivableDue + a.payableDue + a.commissionTotal;
    const balB = b.receivableDue + b.payableDue + b.commissionTotal;
    return balB - balA || b.dealCount - a.dealCount || a.name.localeCompare(b.name);
  });
}

export function formatMoneyInput(v: string): string {
  const digits = v.replace(/\D/g, '').slice(0, 13).replace(/^0+(?=\d)/, '');
  return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export const moneyToInput = (n: number | null | undefined): string =>
  n === null || n === undefined ? '' : formatMoneyInput(String(Math.round(n)));

const ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
const TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
const below100 = (n: number): string => (n < 20 ? ONES[n] : TENS[Math.floor(n / 10)] + (n % 10 ? ' ' + ONES[n % 10] : ''));
const below1000 = (n: number): string =>
  [Math.floor(n / 100) ? ONES[Math.floor(n / 100)] + ' Hundred' : '', n % 100 ? below100(n % 100) : ''].filter(Boolean).join(' ');

export function numberToWords(value: number): string {
  let n = Math.floor(Math.abs(value));
  if (!Number.isFinite(n) || n === 0) return '';
  const units: [number, string, string][] = [
    [1e11, 'Kharab', 'Kharab'], [1e9, 'Arab', 'Arab'], [1e7, 'Crore', 'Crore'], [1e5, 'Lac', 'Lacs'], [1e3, 'Thousand', 'Thousand'],
  ];
  const parts: string[] = [];
  for (const [size, one, many] of units) {
    const q = Math.floor(n / size);
    n %= size;
    if (q > 0) parts.push(`${below1000(q)} ${q === 1 ? one : many}`);
  }
  if (n > 0) parts.push(below1000(n));
  return parts.join(' ');
}
