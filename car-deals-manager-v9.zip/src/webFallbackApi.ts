import {
  DEFAULT_BUSINESS_PROFILE,
  type AppUser,
  type AttachmentCategory,
  type AuditLogEntry,
  type BackupFileInfo,
  type BusinessProfile,
  type CarDealsApi,
  type ChequeStatus,
  type CloudBackupSettings,
  type CreateUserInput,
  type DealAttachment,
  type DealWithTotals,
  type DueDatesInput,
  type Expense,
  type InitialPaymentInput,
  type NewDealInput,
  type Payment,
  type ReserveInput,
  type SaleInput,
  type TransferInput,
  type UpdateUserInput,
} from './types';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { buildBrowserZipBlob, readBrowserZipBuffer, type BrowserZipEntry } from './utils/browserZip';
import {
  disconnectCloudAccount,
  downloadLatestFromCloud,
  getProviderClientId,
  hydrateClientIdsFromPreferences,
  loadCloudConfig,
  pushLocalThenCloud,
  saveCloudConfig,
  saveProviderClientId,
  startCloudOAuthFlow,
  writeLocalBackupFirst,
  type OAuthCloudProvider,
} from './services/cloudSyncEngine';

const STORAGE_KEY = 'carbiz_web_store_v1';

type StoredDeal = Omit<DealWithTotals, 'total_expenses' | 'paid_to_seller' | 'received_from_buyer' | 'attachment_count'>;

interface WebStore {
  nextDealId: number;
  nextExpenseId: number;
  nextPaymentId: number;
  nextAttId: number;
  nextUserId: number;
  nextAuditId: number;
  deals: StoredDeal[];
  expenses: Expense[];
  payments: Payment[];
  attachments: DealAttachment[];
  attachmentData: Record<string, string>;
  auditLogs: AuditLogEntry[];
  users: (AppUser & { pin: string })[];
  profile: BusinessProfile;
  currentUser: AppUser | null;
  autoLockMinutes: number;
  lastWebBackupAt: string | null;
}

const daysAgo = (n: number): string => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const toNum = (v: unknown): number | null => {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(String(v).replace(/[^0-9.\-]/g, ''));
  return Number.isFinite(n) ? n : null;
};

const toInt = (v: unknown): number | null => {
  const n = toNum(v);
  return n === null ? null : Math.trunc(n);
};

const toStr = (v: unknown): string | null => {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  return s === '' ? null : s;
};

function dealTitleLabel(d: Pick<StoredDeal, 'id' | 'year' | 'make' | 'model' | 'registration_number'>): string {
  const title = [d.year, d.make, d.model].filter(Boolean).join(' ').trim() || `Deal #${d.id}`;
  return d.registration_number ? `${title} (${d.registration_number})` : title;
}

function appendAudit(
  s: WebStore,
  entry: {
    entity_type: string;
    entity_id: number;
    deal_id: number | null;
    action: string;
    actor_name?: string | null;
    summary: string;
    changes?: Record<string, [unknown, unknown]> | null;
  },
): void {
  if (!Array.isArray(s.auditLogs)) s.auditLogs = [];
  if (!s.nextAuditId) s.nextAuditId = 1;
  s.auditLogs.unshift({
    id: s.nextAuditId++,
    entity_type: entry.entity_type,
    entity_id: entry.entity_id,
    deal_id: entry.deal_id,
    action: entry.action,
    actor_name: entry.actor_name ?? s.currentUser?.name ?? null,
    summary: entry.summary,
    changes_json: entry.changes && Object.keys(entry.changes).length > 0 ? JSON.stringify(entry.changes) : null,
    created_at: new Date().toISOString(),
  });
  if (s.auditLogs.length > 1000) {
    s.auditLogs.length = 1000;
  }
}

function createSeedStore(): WebStore {
  return {
    nextDealId: 3,
    nextExpenseId: 5,
    nextPaymentId: 6,
    nextAttId: 1,
    nextUserId: 1,
    nextAuditId: 3,
    deals: [
      {
        id: 1,
        status: 'ACTIVE',
        make: 'Toyota',
        model: 'Corolla',
        variant: 'GLi 1.3',
        year: 2018,
        color: 'White',
        horse_power: '1300 CC',
        registration_number: 'BXK-482',
        chassis_number: 'NZE141-9034521',
        engine_number: '1NZ-3318842',
        mileage: 68000,
        bought_from_location: 'Karachi',
        purchase_date: daysAgo(12),
        purchase_price: 3450000,
        seller_name: 'Imran Siddiqui',
        seller_father_name: 'Khalid Siddiqui',
        seller_contact: '0321-5550148',
        seller_cnic: '42101-1234567-1',
        seller_address: 'House 12, Block 5, Gulshan-e-Iqbal, Karachi',
        seller_due_date: daysAgo(-4),
        reserved_date: null,
        reserved_expiry_date: null,
        reserved_token_amount: null,
        reserved_buyer_name: null,
        reserved_buyer_contact: null,
        reserved_notes: null,
        sale_date: null,
        sale_price: null,
        purchaser_name: null,
        purchaser_father_name: null,
        purchaser_contact: null,
        purchaser_cnic: null,
        purchaser_address: null,
        buyer_due_date: null,
        transfer_status: 'WITH_AGENT',
        transfer_agent_name: 'Tariq Excise Agent',
        transfer_agent_contact: '0300-8214490',
        file_handover_date: daysAgo(4),
        transfer_completed_date: null,
        transfer_cost: 18500,
        transfer_notes: 'Complete file & biometric slip handed over for transfer',
        token_tax_paid_till: 'Jun 2027',
        checklist_json: JSON.stringify({
          original_file: true,
          smart_card_book: true,
          biometric_slip: true,
          token_tax_paid: true,
          number_plates: true,
          excise_cplc_ok: true,
          engine_checked: true,
          body_paint_checked: true,
        }),
        trade_in_deal_id: null,
        trade_in_for_deal_id: null,
        notes: 'Original paint, one owner. Needs minor suspension work.',
        created_by: 'System Seed',
        deleted_at: null,
        created_at: new Date().toISOString(),
      },
      {
        id: 2,
        status: 'SOLD',
        make: 'Suzuki',
        model: 'Alto',
        variant: 'VXR',
        year: 2020,
        color: 'Silver',
        horse_power: '660 CC',
        registration_number: 'AHN-917',
        chassis_number: 'HA36S-8821764',
        engine_number: 'R06A-2209137',
        mileage: 41000,
        bought_from_location: 'Lahore',
        purchase_date: daysAgo(60),
        purchase_price: 2050000,
        seller_name: 'Usman Tariq',
        seller_father_name: 'Tariq Mahmood',
        seller_contact: '0333-5550192',
        seller_cnic: '35202-7654321-3',
        seller_address: '45-B, Model Town, Lahore',
        seller_due_date: null,
        reserved_date: null,
        reserved_expiry_date: null,
        reserved_token_amount: null,
        reserved_buyer_name: null,
        reserved_buyer_contact: null,
        reserved_notes: null,
        sale_date: daysAgo(30),
        sale_price: 2300000,
        purchaser_name: 'Hamza Qureshi',
        purchaser_father_name: 'Naveed Qureshi',
        purchaser_contact: '0300-5550177',
        purchaser_cnic: '42201-9988776-5',
        purchaser_address: 'Flat 4-B, Clifton Block 2, Karachi',
        buyer_due_date: null,
        transfer_status: 'COMPLETED',
        transfer_agent_name: 'Tariq Excise Agent',
        transfer_agent_contact: '0300-8214490',
        file_handover_date: daysAgo(29),
        transfer_completed_date: daysAgo(21),
        transfer_cost: 22000,
        transfer_notes: 'Smart card & transfer cleared',
        token_tax_paid_till: 'Dec 2026',
        checklist_json: JSON.stringify({
          original_file: true,
          smart_card_book: true,
          biometric_slip: true,
          token_tax_paid: true,
          number_plates: true,
          sale_deed_signed: true,
          excise_cplc_ok: true,
          engine_checked: true,
          body_paint_checked: true,
          suspension_tyres: true,
          ac_electronics: true,
          spare_tools: true,
        }),
        trade_in_deal_id: null,
        trade_in_for_deal_id: null,
        notes: 'Bought through dealer contact in Lahore.',
        created_by: 'System Seed',
        deleted_at: null,
        created_at: new Date().toISOString(),
      },
    ],
    expenses: [
      { id: 1, car_deal_id: 1, category: 'Mechanic/Repair', description: 'Front suspension bushes & oil service', payee_name: 'Ustad Akram Workshop', amount: 38000, date: daysAgo(9) },
      { id: 2, car_deal_id: 1, category: 'Detailing', description: 'Full interior/exterior detailing', payee_name: 'Shine Pro Studio', amount: 12000, date: daysAgo(5) },
      { id: 3, car_deal_id: 2, category: 'Denting/Painting', description: 'Rear bumper touch-up', payee_name: 'Babar Denter', amount: 15000, date: daysAgo(52) },
      { id: 4, car_deal_id: 2, category: 'Commission', description: 'Sale brokerage commission', payee_name: 'Salman Broker', amount: 25000, date: daysAgo(30) },
    ],
    payments: [
      { id: 1, car_deal_id: 1, direction: 'OUT_TO_SELLER', payment_type: 'Advance', method: 'Bank Transfer', amount: 2000000, date: daysAgo(12), notes: 'Token & initial advance via HBL', cheque_number: null, cheque_date: null, cheque_status: null },
      { id: 2, car_deal_id: 2, direction: 'OUT_TO_SELLER', payment_type: 'Final Balance', method: 'Bank Transfer', amount: 2050000, date: daysAgo(60), notes: 'Full payment on delivery', cheque_number: null, cheque_date: null, cheque_status: null },
      { id: 3, car_deal_id: 2, direction: 'IN_FROM_BUYER', payment_type: 'Advance', method: 'Cash', amount: 500000, date: daysAgo(32), notes: 'Bayana / token received', cheque_number: null, cheque_date: null, cheque_status: null },
      { id: 4, car_deal_id: 2, direction: 'IN_FROM_BUYER', payment_type: 'Final Balance', method: 'Bank Transfer', amount: 1500000, date: daysAgo(30), notes: 'Bank transfer cleared at transfer', cheque_number: null, cheque_date: null, cheque_status: null },
      { id: 5, car_deal_id: 2, direction: 'IN_FROM_BUYER', payment_type: 'Final Balance', method: 'Cheque', amount: 300000, date: daysAgo(30), notes: 'Post-dated balance cheque', cheque_number: '449812', cheque_date: daysAgo(-3), cheque_status: 'PENDING' },
    ],
    attachments: [],
    attachmentData: {},
    auditLogs: [
      {
        id: 1,
        entity_type: 'deal',
        entity_id: 1,
        deal_id: 1,
        action: 'CREATE',
        actor_name: 'System Seed',
        summary: 'Added vehicle 2018 Toyota Corolla (BXK-482)',
        changes_json: null,
        created_at: new Date().toISOString(),
      },
      {
        id: 2,
        entity_type: 'deal',
        entity_id: 2,
        deal_id: 2,
        action: 'MARK_SOLD',
        actor_name: 'System Seed',
        summary: 'Sold 2020 Suzuki Alto (AHN-917) to Hamza Qureshi for 2300000',
        changes_json: null,
        created_at: new Date().toISOString(),
      },
    ],
    users: [],
    profile: { ...DEFAULT_BUSINESS_PROFILE },
    currentUser: null,
    autoLockMinutes: 0,
    lastWebBackupAt: null,
  };
}

function loadStore(): WebStore {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<WebStore>;
      return {
        nextDealId: parsed.nextDealId ?? 1,
        nextExpenseId: parsed.nextExpenseId ?? 1,
        nextPaymentId: parsed.nextPaymentId ?? 1,
        nextAttId: parsed.nextAttId ?? 1,
        nextUserId: parsed.nextUserId ?? 1,
        nextAuditId: parsed.nextAuditId ?? 1,
        deals: (parsed.deals ?? []).map((d) => ({
          ...d,
          trade_in_deal_id: d.trade_in_deal_id ?? null,
          trade_in_for_deal_id: d.trade_in_for_deal_id ?? null,
        })),
        expenses: (parsed.expenses ?? []).map((e) => ({ ...e, payee_name: e.payee_name ?? null })),
        payments: (parsed.payments ?? []).map((p) => ({
          ...p,
          cheque_number: p.cheque_number ?? null,
          cheque_date: p.cheque_date ?? null,
          cheque_status: p.cheque_status ?? null,
        })),
        attachments: parsed.attachments ?? [],
        attachmentData: parsed.attachmentData ?? {},
        auditLogs: parsed.auditLogs ?? [],
        users: parsed.users ?? [],
        profile: parsed.profile ?? { ...DEFAULT_BUSINESS_PROFILE },
        currentUser: parsed.currentUser ?? null,
        autoLockMinutes: parsed.autoLockMinutes ?? 0,
        lastWebBackupAt: parsed.lastWebBackupAt ?? null,
      };
    }
  } catch {
    /* ignore */
  }
  const seed = createSeedStore();
  saveStore(seed);
  return seed;
}

let liveSyncTimer: ReturnType<typeof setTimeout> | null = null;

function scheduleLiveLocalAndCloudBackup(s: WebStore): void {
  if (typeof window === 'undefined') return;
  if (liveSyncTimer) clearTimeout(liveSyncTimer);
  liveSyncTimer = setTimeout(() => {
    void (async () => {
      try {
        const { blob, filename } = await buildWebZipArchive(s);
        await pushLocalThenCloud(blob, filename);
      } catch {
        /* Keep local state intact if offline; next mutation or manual sync retries */
      }
    })();
  }, 4000);
}

function saveStore(s: WebStore, skipLiveSync = false): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  if (!skipLiveSync) {
    scheduleLiveLocalAndCloudBackup(s);
  }
}

function hydrateDeal(s: WebStore, d: StoredDeal): DealWithTotals {
  const total_expenses = s.expenses.filter((e) => e.car_deal_id === d.id).reduce((sum, e) => sum + e.amount, 0);
  const paid_to_seller = s.payments
    .filter((p) => p.car_deal_id === d.id && p.direction === 'OUT_TO_SELLER')
    .reduce((sum, p) => sum + p.amount, 0);
  const received_from_buyer = s.payments
    .filter((p) => p.car_deal_id === d.id && p.direction === 'IN_FROM_BUYER')
    .reduce((sum, p) => sum + p.amount, 0);
  const attachment_count = s.attachments.filter((a) => a.car_deal_id === d.id).length;
  return { ...d, total_expenses, paid_to_seller, received_from_buyer, attachment_count };
}

function applySaleWithTradeIn(
  s: WebStore,
  deal: StoredDeal,
  sale: SaleInput,
  initialBuyerPayment?: InitialPaymentInput | null,
): void {
  Object.assign(deal, {
    status: 'SOLD' as const,
    sale_date: toStr(sale.sale_date),
    sale_price: toNum(sale.sale_price),
    purchaser_name: toStr(sale.purchaser_name),
    purchaser_father_name: toStr(sale.purchaser_father_name),
    purchaser_contact: toStr(sale.purchaser_contact),
    purchaser_cnic: toStr(sale.purchaser_cnic),
    purchaser_address: toStr(sale.purchaser_address),
    buyer_due_date: toStr(sale.buyer_due_date),
    reserved_date: null,
    reserved_expiry_date: null,
    reserved_token_amount: null,
    reserved_buyer_name: null,
    reserved_buyer_contact: null,
    reserved_notes: null,
  });

  appendAudit(s, {
    entity_type: 'deal',
    entity_id: deal.id,
    deal_id: deal.id,
    action: 'MARK_SOLD',
    summary: `Sold ${dealTitleLabel(deal)} to ${deal.purchaser_name ?? 'buyer'}${deal.sale_price ? ` for ${deal.sale_price}` : ''}`,
  });

  const bp = initialBuyerPayment;
  const bpAmt = bp ? toNum(bp.amount) : null;
  if (bp && bpAmt && bpAmt > 0) {
    const method = bp.method ?? 'Cash';
    s.payments.push({
      id: s.nextPaymentId++,
      car_deal_id: deal.id,
      direction: 'IN_FROM_BUYER',
      payment_type: bp.payment_type ?? 'Advance',
      method,
      amount: bpAmt,
      date: bp.date ?? deal.sale_date ?? daysAgo(0),
      notes: bp.notes ?? 'Initial payment on sale',
      cheque_number: method === 'Cheque' ? toStr(bp.cheque_number) : null,
      cheque_date: method === 'Cheque' ? toStr(bp.cheque_date) : null,
      cheque_status: method === 'Cheque' ? (bp.cheque_status ?? 'PENDING') : null,
      created_by: s.currentUser?.name ?? null,
    });
  }

  const ti = sale.tradeIn;
  const tiVal = ti ? toNum(ti.valuation) : null;
  const hasTradeIn = Boolean(ti && ((tiVal !== null && tiVal > 0) || toStr(ti.make) || toStr(ti.model) || toStr(ti.registration_number)));
  if (ti && hasTradeIn && !deal.trade_in_deal_id) {
    const val = tiVal ?? 0;
    const incomingId = s.nextDealId++;
    const incoming: StoredDeal = {
      id: incomingId,
      status: 'ACTIVE',
      make: toStr(ti.make),
      model: toStr(ti.model),
      variant: toStr(ti.variant),
      year: toInt(ti.year),
      color: toStr(ti.color),
      horse_power: toStr(ti.horse_power),
      registration_number: toStr(ti.registration_number)?.toUpperCase() ?? null,
      chassis_number: toStr(ti.chassis_number),
      engine_number: toStr(ti.engine_number),
      mileage: toInt(ti.mileage),
      bought_from_location: null,
      purchase_date: deal.sale_date ?? daysAgo(0),
      purchase_price: val,
      seller_name: deal.purchaser_name,
      seller_father_name: deal.purchaser_father_name,
      seller_contact: deal.purchaser_contact,
      seller_cnic: deal.purchaser_cnic,
      seller_address: deal.purchaser_address,
      seller_due_date: null,
      reserved_date: null,
      reserved_expiry_date: null,
      reserved_token_amount: null,
      reserved_buyer_name: null,
      reserved_buyer_contact: null,
      reserved_notes: null,
      sale_date: null,
      sale_price: null,
      purchaser_name: null,
      purchaser_father_name: null,
      purchaser_contact: null,
      purchaser_cnic: null,
      purchaser_address: null,
      buyer_due_date: null,
      transfer_status: 'PENDING',
      transfer_agent_name: null,
      transfer_agent_contact: null,
      file_handover_date: null,
      transfer_completed_date: null,
      transfer_cost: 0,
      transfer_notes: null,
      token_tax_paid_till: null,
      checklist_json: null,
      trade_in_deal_id: null,
      trade_in_for_deal_id: deal.id,
      notes: toStr(ti.notes) ?? `Trade-in exchange against sale of ${dealTitleLabel(deal)}`,
      created_by: s.currentUser?.name ?? null,
      deleted_at: null,
      created_at: new Date().toISOString(),
    };
    s.deals.push(incoming);
    deal.trade_in_deal_id = incomingId;
    const incomingLabel = dealTitleLabel(incoming);

    appendAudit(s, {
      entity_type: 'deal',
      entity_id: incomingId,
      deal_id: incomingId,
      action: 'TRADE_IN_CREATED',
      summary: `Added trade-in vehicle ${incomingLabel} (exchange for ${dealTitleLabel(deal)})`,
    });

    if (val > 0) {
      s.payments.push({
        id: s.nextPaymentId++,
        car_deal_id: deal.id,
        direction: 'IN_FROM_BUYER',
        payment_type: 'Other',
        method: 'Other',
        amount: val,
        date: deal.sale_date ?? daysAgo(0),
        notes: `Trade-in exchange: ${incomingLabel}`,
        cheque_number: null,
        cheque_date: null,
        cheque_status: null,
        created_by: s.currentUser?.name ?? null,
      });
      s.payments.push({
        id: s.nextPaymentId++,
        car_deal_id: incomingId,
        direction: 'OUT_TO_SELLER',
        payment_type: 'Final Balance',
        method: 'Other',
        amount: val,
        date: deal.sale_date ?? daysAgo(0),
        notes: `Trade-in exchange credit against sold ${dealTitleLabel(deal)}`,
        cheque_number: null,
        cheque_date: null,
        cheque_status: null,
        created_by: s.currentUser?.name ?? null,
      });
    }
  }
}

function dataUrlToBytes(dataUrl: string): { mime: string; bytes: Uint8Array } | null {
  const match = /^data:([^;]+);base64,(.+)$/i.exec(dataUrl);
  if (!match) return null;
  const bin = atob(match[2]);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return { mime: match[1].toLowerCase(), bytes };
}

function bytesToDataUrl(bytes: Uint8Array, mime: string): string {
  let bin = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return `data:${mime};base64,${btoa(bin)}`;
}

async function buildWebZipArchive(s: WebStore): Promise<{ blob: Blob; filename: string }> {
  const encoder = new TextEncoder();
  const entries: BrowserZipEntry[] = [];
  const manifestStore = { ...s, exportedAt: new Date().toISOString(), sourcePlatform: Capacitor.isNativePlatform() ? 'mobile' : 'web' };
  const serialized = encoder.encode(JSON.stringify(manifestStore, null, 2));
  entries.push({
    name: 'web-backup.json',
    data: serialized,
    mtime: new Date(),
  });
  entries.push({
    name: 'sync-manifest.json',
    data: serialized,
    mtime: new Date(),
  });
  for (const att of s.attachments) {
    const dataUrl = s.attachmentData[att.file_path];
    if (!dataUrl) continue;
    const parsed = dataUrlToBytes(dataUrl);
    if (!parsed) continue;
    entries.push({
      name: `attachments/deal-${att.car_deal_id}/${att.id}-${att.file_name.replace(/[^a-zA-Z0-9._-]/g, '_')}`,
      data: parsed.bytes,
      mtime: new Date(),
    });
  }
  const blob = await buildBrowserZipBlob(entries);
  const filename = `car-deals-backup-${new Date().toISOString().slice(0, 10)}.zip`;
  return { blob, filename };
}

export function installWebFallbackApi(): void {
  if (typeof window === 'undefined' || window.api) return;

  const api: CarDealsApi = {
    isElectron: false,
    async listDeals() {
      const s = loadStore();
      return s.deals
        .filter((d) => !d.deleted_at)
        .sort((a, b) => (b.purchase_date ?? '').localeCompare(a.purchase_date ?? '') || b.id - a.id)
        .map((d) => hydrateDeal(s, d));
    },
    async listDeletedDeals() {
      const s = loadStore();
      return s.deals
        .filter((d) => Boolean(d.deleted_at))
        .map((d) => hydrateDeal(s, d));
    },
    async getDeal(id: number) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      return hydrateDeal(s, d);
    },
    async createDeal(input: NewDealInput, sale?: SaleInput | null, initialPayments?: { sellerPayment?: InitialPaymentInput | null; buyerPayment?: InitialPaymentInput | null } | null) {
      const s = loadStore();
      const id = s.nextDealId++;
      const deal: StoredDeal = {
        id,
        status: 'ACTIVE',
        make: toStr(input.make),
        model: toStr(input.model),
        variant: toStr(input.variant),
        year: toInt(input.year),
        color: toStr(input.color),
        horse_power: toStr(input.horse_power),
        registration_number: toStr(input.registration_number)?.toUpperCase() ?? null,
        chassis_number: toStr(input.chassis_number),
        engine_number: toStr(input.engine_number),
        mileage: toInt(input.mileage),
        bought_from_location: toStr(input.bought_from_location),
        purchase_date: toStr(input.purchase_date),
        purchase_price: toNum(input.purchase_price),
        seller_name: toStr(input.seller_name),
        seller_father_name: toStr(input.seller_father_name),
        seller_contact: toStr(input.seller_contact),
        seller_cnic: toStr(input.seller_cnic),
        seller_address: toStr(input.seller_address),
        seller_due_date: toStr(input.seller_due_date),
        reserved_date: null,
        reserved_expiry_date: null,
        reserved_token_amount: null,
        reserved_buyer_name: null,
        reserved_buyer_contact: null,
        reserved_notes: null,
        sale_date: null,
        sale_price: null,
        purchaser_name: null,
        purchaser_father_name: null,
        purchaser_contact: null,
        purchaser_cnic: null,
        purchaser_address: null,
        buyer_due_date: null,
        transfer_status: 'PENDING',
        transfer_agent_name: null,
        transfer_agent_contact: null,
        file_handover_date: null,
        transfer_completed_date: null,
        transfer_cost: 0,
        transfer_notes: null,
        token_tax_paid_till: toStr(input.token_tax_paid_till),
        checklist_json: toStr(input.checklist_json),
        trade_in_deal_id: null,
        trade_in_for_deal_id: null,
        notes: toStr(input.notes),
        created_by: toStr(input.created_by) ?? s.currentUser?.name ?? null,
        deleted_at: null,
        created_at: new Date().toISOString(),
      };
      s.deals.push(deal);
      appendAudit(s, {
        entity_type: 'deal',
        entity_id: id,
        deal_id: id,
        action: 'CREATE',
        actor_name: deal.created_by,
        summary: `Added vehicle ${dealTitleLabel(deal)}`,
      });
      const sp = initialPayments?.sellerPayment;
      const spAmt = sp ? toNum(sp.amount) : null;
      if (sp && spAmt && spAmt > 0) {
        const method = sp.method ?? 'Cash';
        s.payments.push({
          id: s.nextPaymentId++,
          car_deal_id: id,
          direction: 'OUT_TO_SELLER',
          payment_type: sp.payment_type ?? 'Advance',
          method,
          amount: spAmt,
          date: sp.date ?? deal.purchase_date ?? daysAgo(0),
          notes: sp.notes ?? 'Initial payment on purchase',
          cheque_number: method === 'Cheque' ? toStr(sp.cheque_number) : null,
          cheque_date: method === 'Cheque' ? toStr(sp.cheque_date) : null,
          cheque_status: method === 'Cheque' ? (sp.cheque_status ?? 'PENDING') : null,
          created_by: s.currentUser?.name ?? null,
        });
      }
      if (sale) {
        applySaleWithTradeIn(s, deal, sale, initialPayments?.buyerPayment ?? null);
      }
      saveStore(s);
      return hydrateDeal(s, deal);
    },
    async updateDeal(id: number, input: NewDealInput) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      const before = { ...d };
      const nextFields = {
        make: toStr(input.make),
        model: toStr(input.model),
        variant: toStr(input.variant),
        year: toInt(input.year),
        color: toStr(input.color),
        horse_power: toStr(input.horse_power),
        registration_number: toStr(input.registration_number)?.toUpperCase() ?? null,
        chassis_number: toStr(input.chassis_number),
        engine_number: toStr(input.engine_number),
        mileage: toInt(input.mileage),
        bought_from_location: toStr(input.bought_from_location),
        purchase_date: toStr(input.purchase_date),
        purchase_price: toNum(input.purchase_price),
        seller_name: toStr(input.seller_name),
        seller_father_name: toStr(input.seller_father_name),
        seller_contact: toStr(input.seller_contact),
        seller_cnic: toStr(input.seller_cnic),
        seller_address: toStr(input.seller_address),
        seller_due_date: toStr(input.seller_due_date),
        token_tax_paid_till: toStr(input.token_tax_paid_till),
        checklist_json: toStr(input.checklist_json),
        notes: toStr(input.notes),
      };
      const changes: Record<string, [unknown, unknown]> = {};
      for (const [k, v] of Object.entries(nextFields)) {
        const oldV = before[k as keyof StoredDeal] ?? null;
        if (oldV !== (v ?? null)) changes[k] = [oldV, v ?? null];
      }
      Object.assign(d, nextFields);
      if (Object.keys(changes).length > 0) {
        appendAudit(s, {
          entity_type: 'deal',
          entity_id: id,
          deal_id: id,
          action: 'UPDATE',
          summary: `Updated ${Object.keys(changes).length} field(s) on ${dealTitleLabel(d)}`,
          changes,
        });
      }
      saveStore(s);
      return hydrateDeal(s, d);
    },
    async softDeleteDeal(id: number) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (d) {
        d.deleted_at = new Date().toISOString();
        appendAudit(s, {
          entity_type: 'deal',
          entity_id: id,
          deal_id: id,
          action: 'SOFT_DELETE',
          summary: `Moved ${dealTitleLabel(d)} to Recycle Bin`,
        });
      }
      saveStore(s);
    },
    async restoreDeal(id: number) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      d.deleted_at = null;
      appendAudit(s, {
        entity_type: 'deal',
        entity_id: id,
        deal_id: id,
        action: 'RESTORE',
        summary: `Restored ${dealTitleLabel(d)} from Recycle Bin`,
      });
      saveStore(s);
      return hydrateDeal(s, d);
    },
    async deleteDeal(id: number) {
      const s = loadStore();
      const target = s.deals.find((x) => x.id === id);
      for (const other of s.deals) {
        if (other.trade_in_deal_id === id) other.trade_in_deal_id = null;
        if (other.trade_in_for_deal_id === id) other.trade_in_for_deal_id = null;
      }
      s.deals = s.deals.filter((x) => x.id !== id);
      s.expenses = s.expenses.filter((x) => x.car_deal_id !== id);
      s.payments = s.payments.filter((x) => x.car_deal_id !== id);
      s.attachments = s.attachments.filter((x) => x.car_deal_id !== id);
      if (target) {
        appendAudit(s, {
          entity_type: 'deal',
          entity_id: id,
          deal_id: null,
          action: 'PERMANENT_DELETE',
          summary: `Permanently deleted ${dealTitleLabel(target)}`,
        });
      }
      saveStore(s);
    },
    async emptyRecycleBin() {
      const s = loadStore();
      const deletedIds = new Set(s.deals.filter((x) => x.deleted_at).map((x) => x.id));
      for (const other of s.deals) {
        if (other.trade_in_deal_id && deletedIds.has(other.trade_in_deal_id)) other.trade_in_deal_id = null;
        if (other.trade_in_for_deal_id && deletedIds.has(other.trade_in_for_deal_id)) other.trade_in_for_deal_id = null;
      }
      s.deals = s.deals.filter((x) => !deletedIds.has(x.id));
      s.expenses = s.expenses.filter((x) => !deletedIds.has(x.car_deal_id));
      s.payments = s.payments.filter((x) => !deletedIds.has(x.car_deal_id));
      s.attachments = s.attachments.filter((x) => !deletedIds.has(x.car_deal_id));
      if (deletedIds.size > 0) {
        appendAudit(s, {
          entity_type: 'system',
          entity_id: 0,
          deal_id: null,
          action: 'EMPTY_RECYCLE_BIN',
          summary: `Permanently emptied ${deletedIds.size} vehicle(s) from Recycle Bin`,
        });
      }
      saveStore(s);
    },
    async reserveDeal(id: number, input: ReserveInput) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      const wasReserved = d.status === 'RESERVED';
      const tokenAmt = toNum(input.reserved_token_amount);
      const rDate = toStr(input.reserved_date) ?? daysAgo(0);
      Object.assign(d, {
        status: 'RESERVED',
        reserved_date: rDate,
        reserved_expiry_date: toStr(input.reserved_expiry_date),
        reserved_token_amount: tokenAmt,
        reserved_buyer_name: toStr(input.reserved_buyer_name),
        reserved_buyer_contact: toStr(input.reserved_buyer_contact),
        reserved_notes: toStr(input.reserved_notes),
      });
      appendAudit(s, {
        entity_type: 'deal',
        entity_id: id,
        deal_id: id,
        action: 'RESERVE',
        summary: `Reserved ${dealTitleLabel(d)} for ${d.reserved_buyer_name ?? 'buyer'}${tokenAmt ? ` (Token: ${tokenAmt})` : ''}`,
      });
      if (!wasReserved && tokenAmt && tokenAmt > 0) {
        s.payments.push({
          id: s.nextPaymentId++,
          car_deal_id: id,
          direction: 'IN_FROM_BUYER',
          payment_type: 'Token',
          method: input.payment_method ?? 'Cash',
          amount: tokenAmt,
          date: rDate,
          notes: input.payment_notes ?? (d.reserved_buyer_name ? `Token / Bayana from ${d.reserved_buyer_name}` : 'Token / Bayana hold'),
          cheque_number: null,
          cheque_date: null,
          cheque_status: null,
          created_by: s.currentUser?.name ?? null,
        });
      }
      saveStore(s);
      return hydrateDeal(s, d);
    },
    async cancelReservation(id: number, refundToken = false) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      Object.assign(d, {
        status: 'ACTIVE',
        reserved_date: null,
        reserved_expiry_date: null,
        reserved_token_amount: null,
        reserved_buyer_name: null,
        reserved_buyer_contact: null,
        reserved_notes: null,
      });
      if (refundToken) {
        s.payments = s.payments.filter((p) => !(p.car_deal_id === id && p.direction === 'IN_FROM_BUYER' && p.payment_type === 'Token'));
      }
      appendAudit(s, {
        entity_type: 'deal',
        entity_id: id,
        deal_id: id,
        action: 'CANCEL_RESERVE',
        summary: `Released Bayana hold on ${dealTitleLabel(d)}${refundToken ? ' (Token payment removed)' : ''}`,
      });
      saveStore(s);
      return hydrateDeal(s, d);
    },
    async markSold(id: number, sale: SaleInput, initialBuyerPayment?: InitialPaymentInput | null) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      applySaleWithTradeIn(s, d, sale, initialBuyerPayment);
      saveStore(s);
      return hydrateDeal(s, d);
    },
    async revertSale(id: number, deleteBuyerPayments = false) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      const linkedTi = d.trade_in_deal_id;
      Object.assign(d, {
        status: 'ACTIVE',
        sale_date: null,
        sale_price: null,
        purchaser_name: null,
        purchaser_father_name: null,
        purchaser_contact: null,
        purchaser_cnic: null,
        purchaser_address: null,
        buyer_due_date: null,
        trade_in_deal_id: null,
      });
      if (linkedTi) {
        const tiDeal = s.deals.find((x) => x.id === linkedTi);
        if (tiDeal) tiDeal.trade_in_for_deal_id = null;
      }
      if (deleteBuyerPayments) {
        s.payments = s.payments.filter((p) => !(p.car_deal_id === id && p.direction === 'IN_FROM_BUYER'));
      }
      appendAudit(s, {
        entity_type: 'deal',
        entity_id: id,
        deal_id: id,
        action: 'REVERT_SALE',
        summary: `Reverted sale on ${dealTitleLabel(d)} back to Available Stock`,
      });
      saveStore(s);
      return hydrateDeal(s, d);
    },
    async updateDueDates(id: number, input: DueDatesInput) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      if (input.seller_due_date !== undefined) d.seller_due_date = toStr(input.seller_due_date);
      if (input.buyer_due_date !== undefined) d.buyer_due_date = toStr(input.buyer_due_date);
      saveStore(s);
      return hydrateDeal(s, d);
    },
    async updateChecklist(id: number, checklistJson: string, tokenTaxPaidTill?: string | null) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      d.checklist_json = toStr(checklistJson);
      if (tokenTaxPaidTill !== undefined) d.token_tax_paid_till = toStr(tokenTaxPaidTill);
      saveStore(s);
      return hydrateDeal(s, d);
    },
    async updateTransfer(id: number, input: TransferInput) {
      const s = loadStore();
      const d = s.deals.find((x) => x.id === id);
      if (!d) throw new Error(`Car deal ${id} not found`);
      const prevStatus = d.transfer_status;
      const completedDate = toStr(input.transfer_completed_date);
      const handoverDate = toStr(input.file_handover_date);
      let status = input.transfer_status ?? 'PENDING';
      if (completedDate) status = 'COMPLETED';
      else if (handoverDate && status === 'PENDING') status = 'WITH_AGENT';
      Object.assign(d, {
        transfer_status: status,
        transfer_agent_name: toStr(input.transfer_agent_name),
        transfer_agent_contact: toStr(input.transfer_agent_contact),
        file_handover_date: handoverDate,
        transfer_completed_date: completedDate,
        transfer_cost: toNum(input.transfer_cost) ?? 0,
        transfer_notes: toStr(input.transfer_notes),
      });
      appendAudit(s, {
        entity_type: 'transfer',
        entity_id: id,
        deal_id: id,
        action: 'UPDATE_TRANSFER',
        summary: `Transfer updated (${prevStatus} → ${status}) on ${dealTitleLabel(d)}`,
        changes: prevStatus !== status ? { transfer_status: [prevStatus, status] } : null,
      });
      saveStore(s);
      return hydrateDeal(s, d);
    },
    async listAttachments(dealId: number) {
      const s = loadStore();
      return s.attachments.filter((a) => a.car_deal_id === dealId);
    },
    async pickAndAddAttachment(dealId: number, category: AttachmentCategory, label?: string) {
      return new Promise<DealAttachment | null>((resolve) => {
        const inp = document.createElement('input');
        inp.type = 'file';
        inp.accept = 'image/*,application/pdf';
        inp.onchange = () => {
          const f = inp.files?.[0];
          if (!f) return resolve(null);
          const reader = new FileReader();
          reader.onload = () => {
            const att = api.saveAttachmentData(dealId, category, label || category, f.name, String(reader.result));
            void att.then(resolve);
          };
          reader.readAsDataURL(f);
        };
        inp.click();
      });
    },
    pickAndSaveAttachment(dealId: number, category: AttachmentCategory, label?: string) {
      return api.pickAndAddAttachment(dealId, category, label);
    },
    async saveWebcamAttachment(dealId: number, category: AttachmentCategory, label: string, dataUrl: string) {
      const fileName = `webcam-${category.toLowerCase()}-${Date.now()}.jpg`;
      return api.saveAttachmentData(dealId, category, label || category, fileName, dataUrl);
    },
    async saveAttachmentData(dealId: number, category: AttachmentCategory, label: string, fileName: string, dataUrl: string) {
      const s = loadStore();
      const id = s.nextAttId++;
      const cleanName = fileName || `doc-${id}.jpg`;
      const pathKey = `web://deal-${dealId}/${id}-${cleanName}`;
      s.attachmentData[pathKey] = dataUrl;
      const att: DealAttachment = {
        id,
        car_deal_id: dealId,
        category,
        label: label || category,
        file_name: cleanName,
        file_path: pathKey,
        created_at: new Date().toISOString(),
      };
      s.attachments.unshift(att);
      saveStore(s);
      return att;
    },
    async readAttachmentDataUrl(filePath: string) {
      const s = loadStore();
      return s.attachmentData[filePath] ?? null;
    },
    getAttachmentDataUrl(filePath: string) {
      return api.readAttachmentDataUrl(filePath);
    },
    async deleteAttachment(id: number) {
      const s = loadStore();
      const target = s.attachments.find((a) => a.id === id);
      if (target) delete s.attachmentData[target.file_path];
      s.attachments = s.attachments.filter((a) => a.id !== id);
      saveStore(s);
    },
    async listExpenses(dealId: number) {
      return loadStore().expenses.filter((e) => e.car_deal_id === dealId);
    },
    async listAllExpenses() {
      const s = loadStore();
      const activeIds = new Set(s.deals.filter((d) => !d.deleted_at).map((d) => d.id));
      return s.expenses.filter((e) => activeIds.has(e.car_deal_id));
    },
    async addExpense(dealId: number, input) {
      const s = loadStore();
      const exp: Expense = {
        id: s.nextExpenseId++,
        car_deal_id: dealId,
        category: input.category,
        description: input.description,
        payee_name: toStr(input.payee_name),
        amount: toNum(input.amount) ?? 0,
        date: input.date,
        created_by: input.created_by ?? s.currentUser?.name ?? null,
      };
      s.expenses.unshift(exp);
      appendAudit(s, {
        entity_type: 'expense',
        entity_id: exp.id,
        deal_id: dealId,
        action: 'ADD_EXPENSE',
        summary: `Added ${exp.category} expense: ${exp.amount}${exp.payee_name ? ` (To: ${exp.payee_name})` : ''}`,
      });
      saveStore(s);
      return exp;
    },
    async updateExpense(id: number, input) {
      const s = loadStore();
      const exp = s.expenses.find((e) => e.id === id);
      if (!exp) throw new Error('Expense not found');
      const prevAmt = exp.amount;
      Object.assign(exp, {
        category: input.category,
        description: input.description,
        payee_name: toStr(input.payee_name),
        amount: toNum(input.amount) ?? 0,
        date: input.date,
      });
      appendAudit(s, {
        entity_type: 'expense',
        entity_id: id,
        deal_id: exp.car_deal_id,
        action: 'UPDATE_EXPENSE',
        summary: `Updated ${exp.category} expense (${prevAmt} → ${exp.amount})`,
        changes: prevAmt !== exp.amount ? { amount: [prevAmt, exp.amount] } : null,
      });
      saveStore(s);
      return exp;
    },
    async deleteExpense(id: number) {
      const s = loadStore();
      const target = s.expenses.find((e) => e.id === id);
      s.expenses = s.expenses.filter((e) => e.id !== id);
      if (target) {
        appendAudit(s, {
          entity_type: 'expense',
          entity_id: id,
          deal_id: target.car_deal_id,
          action: 'DELETE_EXPENSE',
          summary: `Deleted ${target.category} expense (${target.amount})`,
        });
      }
      saveStore(s);
    },
    async listPayments(dealId: number) {
      return loadStore().payments.filter((p) => p.car_deal_id === dealId);
    },
    async listAllPayments() {
      const s = loadStore();
      const activeIds = new Set(s.deals.filter((d) => !d.deleted_at).map((d) => d.id));
      return s.payments.filter((p) => activeIds.has(p.car_deal_id));
    },
    async addPayment(dealId: number, input) {
      const s = loadStore();
      const isCheque = input.method === 'Cheque';
      const pay: Payment = {
        id: s.nextPaymentId++,
        car_deal_id: dealId,
        direction: input.direction,
        payment_type: input.payment_type,
        method: input.method,
        amount: toNum(input.amount) ?? 0,
        date: input.date,
        notes: input.notes,
        cheque_number: isCheque ? toStr(input.cheque_number) : null,
        cheque_date: isCheque ? toStr(input.cheque_date) : null,
        cheque_status: isCheque ? (input.cheque_status ?? 'PENDING') : null,
        created_by: input.created_by ?? s.currentUser?.name ?? null,
      };
      s.payments.push(pay);
      appendAudit(s, {
        entity_type: 'payment',
        entity_id: pay.id,
        deal_id: dealId,
        action: 'ADD_PAYMENT',
        summary: `${pay.direction === 'IN_FROM_BUYER' ? 'Received' : 'Paid'} ${pay.amount} via ${pay.method}${pay.cheque_number ? ` (#${pay.cheque_number})` : ''}`,
      });
      saveStore(s);
      return pay;
    },
    async updatePayment(id: number, input) {
      const s = loadStore();
      const pay = s.payments.find((p) => p.id === id);
      if (!pay) throw new Error('Payment not found');
      const prevAmt = pay.amount;
      const isCheque = input.method === 'Cheque';
      Object.assign(pay, {
        direction: input.direction,
        payment_type: input.payment_type,
        method: input.method,
        amount: toNum(input.amount) ?? 0,
        date: input.date,
        notes: input.notes,
        cheque_number: isCheque ? toStr(input.cheque_number) : null,
        cheque_date: isCheque ? toStr(input.cheque_date) : null,
        cheque_status: isCheque ? (input.cheque_status ?? 'PENDING') : null,
      });
      appendAudit(s, {
        entity_type: 'payment',
        entity_id: id,
        deal_id: pay.car_deal_id,
        action: 'UPDATE_PAYMENT',
        summary: `Updated payment (${prevAmt} → ${pay.amount}, ${pay.method})`,
        changes: prevAmt !== pay.amount ? { amount: [prevAmt, pay.amount] } : null,
      });
      saveStore(s);
      return pay;
    },
    async updateChequeStatus(id: number, status: ChequeStatus) {
      const s = loadStore();
      const pay = s.payments.find((p) => p.id === id);
      if (!pay) throw new Error('Payment not found');
      const prev = pay.cheque_status ?? null;
      pay.cheque_status = status;
      appendAudit(s, {
        entity_type: 'payment',
        entity_id: id,
        deal_id: pay.car_deal_id,
        action: 'CHEQUE_STATUS',
        summary: `Cheque ${pay.cheque_number ? `#${pay.cheque_number} ` : ''}(${pay.amount}) marked ${status}`,
        changes: { cheque_status: [prev, status] },
      });
      saveStore(s);
      return pay;
    },
    async deletePayment(id: number) {
      const s = loadStore();
      const target = s.payments.find((p) => p.id === id);
      s.payments = s.payments.filter((p) => p.id !== id);
      if (target) {
        appendAudit(s, {
          entity_type: 'payment',
          entity_id: id,
          deal_id: target.car_deal_id,
          action: 'DELETE_PAYMENT',
          summary: `Deleted payment of ${target.amount} (${target.method})`,
        });
      }
      saveStore(s);
    },
    async listAuditLogs(dealId?: number, limit = 200) {
      const s = loadStore();
      const rows = dealId !== undefined ? s.auditLogs.filter((l) => l.deal_id === dealId) : s.auditLogs;
      return rows.slice(0, limit);
    },
    async hasUsers() {
      return loadStore().users.length > 0;
    },
    async listUsers() {
      return loadStore().users.map(({ pin: _p, ...u }) => u);
    },
    async createUser(input: CreateUserInput) {
      const s = loadStore();
      const isOwner = input.role === 'OWNER';
      const user: AppUser & { pin: string } = {
        id: s.nextUserId++,
        name: input.name.trim(),
        pin: input.pin.trim(),
        role: input.role,
        can_view_profit: isOwner || Boolean(input.can_view_profit),
        can_manage_payments: isOwner || input.can_manage_payments !== false,
        can_mark_sold: isOwner || input.can_mark_sold !== false,
        can_delete: isOwner || Boolean(input.can_delete),
        created_at: new Date().toISOString(),
      };
      s.users.push(user);
      saveStore(s);
      const { pin: _p, ...pub } = user;
      return pub;
    },
    async updateUser(id: number, input: UpdateUserInput) {
      const s = loadStore();
      const u = s.users.find((x) => x.id === id);
      if (!u) throw new Error('User not found');
      if (input.name !== undefined) u.name = input.name.trim();
      if (input.pin) u.pin = input.pin.trim();
      if (input.role) u.role = input.role;
      const isOwner = u.role === 'OWNER';
      u.can_view_profit = isOwner ? true : input.can_view_profit ?? u.can_view_profit;
      u.can_manage_payments = isOwner ? true : input.can_manage_payments ?? u.can_manage_payments;
      u.can_mark_sold = isOwner ? true : input.can_mark_sold ?? u.can_mark_sold;
      u.can_delete = isOwner ? true : input.can_delete ?? u.can_delete;
      saveStore(s);
      const { pin: _p, ...pub } = u;
      return pub;
    },
    async deleteUser(id: number) {
      const s = loadStore();
      s.users = s.users.filter((u) => u.id !== id);
      saveStore(s);
    },
    async authenticatePin(pin: string, userId?: number) {
      const s = loadStore();
      const found = s.users.find((u) => u.pin === pin.trim() && (userId === undefined || u.id === userId));
      if (!found) return null;
      const { pin: _p, ...pub } = found;
      s.currentUser = pub;
      saveStore(s);
      return pub;
    },
    async lockApp() {
      const s = loadStore();
      s.currentUser = null;
      saveStore(s);
    },
    async getAutoLockMinutes() {
      return loadStore().autoLockMinutes ?? 0;
    },
    async setAutoLockMinutes(minutes: number) {
      const s = loadStore();
      s.autoLockMinutes = Number.isFinite(minutes) && minutes > 0 ? Math.min(240, Math.trunc(minutes)) : 0;
      saveStore(s);
      return s.autoLockMinutes;
    },
    async getBusinessProfile() {
      return loadStore().profile;
    },
    async setBusinessProfile(profile: Partial<BusinessProfile>) {
      const s = loadStore();
      s.profile = { ...s.profile, ...profile };
      saveStore(s);
      return s.profile;
    },
    async listAutoBackups(): Promise<BackupFileInfo[]> {
      if (!Capacitor.isNativePlatform()) return [];
      try {
        const res = await Filesystem.readdir({
          path: 'CarDealsBackups',
          directory: Directory.Documents,
        });
        return res.files
          .filter((f) => f.name.endsWith('.zip'))
          .map((f) => ({
            name: f.name,
            path: `CarDealsBackups/${f.name}`,
            size: Number(f.size ?? 0),
            mtime: f.mtime ? new Date(Number(f.mtime)).toISOString() : new Date().toISOString(),
            kind: 'zip' as const,
          }))
          .sort((a, b) => b.mtime.localeCompare(a.mtime));
      } catch {
        return [];
      }
    },
    async autoBackupFolder() {
      return Capacitor.isNativePlatform()
        ? 'Documents/CarDealsBackups (Local Device Storage)'
        : 'Browser Local Storage + Portable .ZIP';
    },
    async getCloudBackupSettings(): Promise<CloudBackupSettings> {
      const cfg = await loadCloudConfig();
      const labelByProvider: Record<string, string> = {
        NONE: '',
        LOCAL_FOLDER: cfg.localFolderPath ?? '',
        GOOGLE_DRIVE: 'Google Drive (Live Cloud Sync)',
        DROPBOX: 'Dropbox (Live Cloud Sync)',
        ONEDRIVE: 'Microsoft OneDrive (Live Cloud Sync)',
      };
      return {
        provider: cfg.provider,
        cloud_backup_dir: labelByProvider[cfg.provider] ?? '',
        account_email: cfg.accountEmail ?? null,
        auto_sync_live: cfg.autoSyncLive,
        last_local_backup_at: cfg.lastLocalBackupAt,
        last_synced_at: cfg.lastCloudSyncAt,
        last_error: cfg.lastError,
      };
    },
    async pickCloudBackupFolder(): Promise<CloudBackupSettings> {
      return api.getCloudBackupSettings();
    },
    async clearCloudBackupFolder(): Promise<CloudBackupSettings> {
      await disconnectCloudAccount();
      return api.getCloudBackupSettings();
    },
    async getCloudClientIds(): Promise<Partial<Record<OAuthCloudProvider, string>>> {
      await hydrateClientIdsFromPreferences();
      return {
        GOOGLE_DRIVE: getProviderClientId('GOOGLE_DRIVE'),
        DROPBOX: getProviderClientId('DROPBOX'),
        ONEDRIVE: getProviderClientId('ONEDRIVE'),
      };
    },
    async saveCloudClientId(
      provider: OAuthCloudProvider,
      clientId: string,
    ): Promise<Partial<Record<OAuthCloudProvider, string>>> {
      await saveProviderClientId(provider, clientId);
      return api.getCloudClientIds!();
    },
    async connectCloudProvider(
      provider: OAuthCloudProvider,
      explicitClientId?: string,
    ): Promise<CloudBackupSettings> {
      if (explicitClientId && explicitClientId.trim()) {
        await saveProviderClientId(provider, explicitClientId.trim());
      }
      await startCloudOAuthFlow(provider);
      return api.getCloudBackupSettings();
    },
    async disconnectCloudProvider(): Promise<CloudBackupSettings> {
      await disconnectCloudAccount();
      return api.getCloudBackupSettings();
    },
    async pullLatestFromCloud() {
      try {
        const remote = await downloadLatestFromCloud();
        if (!remote) {
          return { pulled: false, message: 'No cloud sync file found yet. Run Sync Now from your other device first.' };
        }
        // Save a local safety snapshot before importing cloud state
        const currentStore = loadStore();
        const safety = await buildWebZipArchive(currentStore);
        await writeLocalBackupFirst(safety.blob, `pre-cloud-pull-${Date.now()}.zip`);

        const file = new File([remote.blob], remote.meta.fileName, { type: 'application/zip' });
        const restored = await api.importBrowserZipFile!(file);
        const cfg = await loadCloudConfig();
        cfg.lastCloudSyncAt = new Date().toISOString();
        cfg.lastRemoteModifiedAt = remote.meta.modifiedAt;
        cfg.lastError = null;
        await saveCloudConfig(cfg);
        return {
          pulled: true,
          restored: restored.restored,
          count: restored.count,
          message: `Synced ${restored.count} deals from cloud (${new Date(remote.meta.modifiedAt).toLocaleString()}).`,
        };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        return { pulled: false, error: message };
      }
    },
    async syncBackupNow() {
      const s = loadStore();
      const { blob, filename } = await buildWebZipArchive(s);
      s.lastWebBackupAt = new Date().toISOString();
      saveStore(s, true);
      try {
        const result = await pushLocalThenCloud(blob, filename);
        return {
          synced: true,
          localPath: result.localPath,
          cloudPath: result.syncedCloud ? `${result.config.provider}:/car-deals-live-sync.zip` : undefined,
        };
      } catch (err) {
        return {
          synced: false,
          error: err instanceof Error ? err.message : String(err),
        };
      }
    },
    async exportBrowserZipBlob() {
      const s = loadStore();
      const res = await buildWebZipArchive(s);
      s.lastWebBackupAt = new Date().toISOString();
      saveStore(s);
      return res;
    },
    async importBrowserZipFile(file: File) {
      const name = file.name.toLowerCase();
      let parsed: Partial<WebStore> | null = null;
      const restoredAttachmentData: Record<string, string> = {};

      if (name.endsWith('.json')) {
        const text = await file.text();
        parsed = JSON.parse(text) as Partial<WebStore>;
      } else if (name.endsWith('.zip')) {
        const buf = await file.arrayBuffer();
        const entries = await readBrowserZipBuffer(buf);
        const jsonBytes = entries.get('web-backup.json') ?? entries.get('sync-manifest.json');
        if (!jsonBytes) {
          if (entries.has('car-deals.db')) {
            throw new Error('This archive was created before cross-platform sync was enabled. Re-save a .zip backup on your Laptop to exchange with Mobile.');
          }
          throw new Error('Invalid backup archive: web-backup.json or sync-manifest.json was not found inside this .zip.');
        }
        parsed = JSON.parse(new TextDecoder('utf-8').decode(jsonBytes)) as Partial<WebStore>;
        const mimeByExt: Record<string, string> = {
          png: 'image/png',
          jpg: 'image/jpeg',
          jpeg: 'image/jpeg',
          webp: 'image/webp',
          pdf: 'application/pdf',
        };
        for (const att of parsed.attachments ?? []) {
          const entryName = `attachments/deal-${att.car_deal_id}/${att.id}-${att.file_name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
          const bin = entries.get(entryName);
          if (bin) {
            const ext = att.file_name.split('.').pop()?.toLowerCase() ?? 'jpg';
            restoredAttachmentData[att.file_path] = bytesToDataUrl(bin, mimeByExt[ext] ?? 'image/jpeg');
          }
        }
      } else {
        throw new Error('Please choose a .zip or .json backup file.');
      }

      if (!parsed || !Array.isArray(parsed.deals)) {
        throw new Error('Backup file does not contain valid car deal records.');
      }

      const nextStore: WebStore = {
        nextDealId: parsed.nextDealId ?? parsed.deals.length + 1,
        nextExpenseId: parsed.nextExpenseId ?? (parsed.expenses?.length ?? 0) + 1,
        nextPaymentId: parsed.nextPaymentId ?? (parsed.payments?.length ?? 0) + 1,
        nextAttId: parsed.nextAttId ?? (parsed.attachments?.length ?? 0) + 1,
        nextUserId: parsed.nextUserId ?? (parsed.users?.length ?? 0) + 1,
        nextAuditId: parsed.nextAuditId ?? (parsed.auditLogs?.length ?? 0) + 1,
        deals: parsed.deals,
        expenses: parsed.expenses ?? [],
        payments: parsed.payments ?? [],
        attachments: parsed.attachments ?? [],
        attachmentData: { ...(parsed.attachmentData ?? {}), ...restoredAttachmentData },
        auditLogs: parsed.auditLogs ?? [],
        users: parsed.users ?? [],
        profile: parsed.profile ?? { ...DEFAULT_BUSINESS_PROFILE },
        currentUser: null,
        autoLockMinutes: parsed.autoLockMinutes ?? 0,
        lastWebBackupAt: new Date().toISOString(),
      };
      saveStore(nextStore);
      return {
        restored: true,
        count: nextStore.deals.filter((d) => !d.deleted_at).length,
        sourceName: file.name,
      };
    },
    async backupOrExport(kind: 'zip' | 'db' | 'csv') {
      const s = loadStore();
      if (kind === 'zip') {
        const { blob, filename } = await buildWebZipArchive(s);
        s.lastWebBackupAt = new Date().toISOString();
        saveStore(s);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
        return { saved: true, path: filename };
      }
      const content =
        kind === 'csv'
          ? 'ID,Year,Make,Model,Variant,Registration,Status,PurchasePrice,SalePrice\n' +
            s.deals
              .filter((d) => !d.deleted_at)
              .map(
                (d) =>
                  `${d.id},${d.year ?? ''},${d.make ?? ''},${d.model ?? ''},${d.variant ?? ''},${d.registration_number ?? ''},${d.status},${d.purchase_price ?? ''},${d.sale_price ?? ''}`,
              )
              .join('\n')
          : JSON.stringify(s, null, 2);
      const blob = new Blob([content], { type: kind === 'csv' ? 'text/csv' : 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `car-deals-${new Date().toISOString().slice(0, 10)}.${kind === 'csv' ? 'csv' : 'json'}`;
      a.click();
      URL.revokeObjectURL(url);
      return { saved: true, path: a.download };
    },
    async restoreFromPath() {
      return { restored: false };
    },
    async restoreFromBackup() {
      return { restored: false };
    },
    async pickAndRestore() {
      return new Promise((resolve, reject) => {
        const inp = document.createElement('input');
        inp.type = 'file';
        inp.accept = '.zip,.json,application/zip,application/json';
        inp.onchange = () => {
          const f = inp.files?.[0];
          if (!f) return resolve({ restored: false });
          void api.importBrowserZipFile?.(f).then(resolve).catch(reject);
        };
        inp.click();
      });
    },
    async saveReceiptPdf(html: string, defaultFileName: string) {
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = defaultFileName.replace(/\.pdf$/i, '.html');
      a.click();
      URL.revokeObjectURL(url);
      return { saved: true, path: a.download };
    },
    async printReceiptHtml(html: string) {
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.srcdoc = html;
      document.body.appendChild(iframe);
      iframe.onload = () => {
        iframe.contentWindow?.print();
        setTimeout(() => iframe.remove(), 1000);
      };
    },
    async showInFolder() {
      /* Desktop-only */
    },
    async openExternalUrl(url: string) {
      window.open(url, '_blank', 'noopener,noreferrer');
    },
  };

  window.api = api;
}
