export interface PreparedAttachmentFile {
  fileName: string;
  dataUrl: string;
  originalBytes: number;
  finalBytes: number;
  compressed: boolean;
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error(`Failed to read ${file.name}`));
    reader.readAsDataURL(file);
  });
}

function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Could not decode image'));
    img.src = src;
  });
}

function estimateDataUrlBytes(dataUrl: string): number {
  const comma = dataUrl.indexOf(',');
  if (comma < 0) return dataUrl.length;
  return Math.floor((dataUrl.length - comma - 1) * 0.75);
}

/**
 * Compresses large camera/phone photos client-side (resizing to max 1600px, JPEG 0.80)
 * so document uploads & .zip backups stay small and fast. PDFs and tiny images pass through.
 */
export async function prepareAttachmentFile(
  file: File,
  maxDimension = 1600,
  jpegQuality = 0.8,
): Promise<PreparedAttachmentFile> {
  const rawDataUrl = await readFileAsDataUrl(file);
  const originalBytes = file.size || estimateDataUrlBytes(rawDataUrl);

  const isCompressibleImage = /^image\/(jpeg|jpg|png|webp|heic|heif|bmp)$/i.test(file.type) ||
    /\.(jpe?g|png|webp|bmp)$/i.test(file.name);

  if (!isCompressibleImage) {
    return {
      fileName: file.name,
      dataUrl: rawDataUrl,
      originalBytes,
      finalBytes: originalBytes,
      compressed: false,
    };
  }

  try {
    const img = await loadImageElement(rawDataUrl);
    const { width, height } = img;

    // Skip re-encoding if already small enough and under 160 KB
    if (width <= maxDimension && height <= maxDimension && originalBytes <= 160 * 1024) {
      return {
        fileName: file.name,
        dataUrl: rawDataUrl,
        originalBytes,
        finalBytes: originalBytes,
        compressed: false,
      };
    }

    const scale = Math.min(1, maxDimension / Math.max(width, height));
    const targetW = Math.max(1, Math.round(width * scale));
    const targetH = Math.max(1, Math.round(height * scale));

    const canvas = document.createElement('canvas');
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      return {
        fileName: file.name,
        dataUrl: rawDataUrl,
        originalBytes,
        finalBytes: originalBytes,
        compressed: false,
      };
    }

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, targetW, targetH);
    ctx.drawImage(img, 0, 0, targetW, targetH);

    const compressedUrl = canvas.toDataURL('image/jpeg', jpegQuality);
    const compressedBytes = estimateDataUrlBytes(compressedUrl);

    // Keep whichever is smaller
    if (compressedBytes >= originalBytes && width <= maxDimension && height <= maxDimension) {
      return {
        fileName: file.name,
        dataUrl: rawDataUrl,
        originalBytes,
        finalBytes: originalBytes,
        compressed: false,
      };
    }

    const base = file.name.replace(/\.[^.]+$/, '');
    return {
      fileName: `${base}.jpg`,
      dataUrl: compressedUrl,
      originalBytes,
      finalBytes: compressedBytes,
      compressed: true,
    };
  } catch {
    return {
      fileName: file.name,
      dataUrl: rawDataUrl,
      originalBytes,
      finalBytes: originalBytes,
      compressed: false,
    };
  }
}
