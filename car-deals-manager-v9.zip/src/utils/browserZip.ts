const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) !== 0 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

export interface BrowserZipEntry {
  name: string;
  data: Uint8Array;
  mtime?: Date;
}

function toDosTimeDate(d: Date): { dosTime: number; dosDate: number } {
  const year = Math.max(1980, d.getFullYear());
  const dosTime =
    ((d.getHours() & 0x1f) << 11) |
    ((d.getMinutes() & 0x3f) << 5) |
    ((d.getSeconds() >> 1) & 0x1f);
  const dosDate =
    (((year - 1980) & 0x7f) << 9) |
    (((d.getMonth() + 1) & 0x0f) << 5) |
    (d.getDate() & 0x1f);
  return { dosTime, dosDate };
}

async function deflateRawIfSupported(data: Uint8Array): Promise<{ payload: Uint8Array; method: number }> {
  if (typeof CompressionStream === 'undefined') {
    return { payload: data, method: 0 };
  }
  try {
    const cs = new CompressionStream('deflate-raw');
    const writer = cs.writable.getWriter();
    const copy = new Uint8Array(data);
    void writer.write(copy);
    void writer.close();
    const buf = await new Response(cs.readable).arrayBuffer();
    const compressed = new Uint8Array(buf);
    if (compressed.length < data.length) {
      return { payload: compressed, method: 8 };
    }
  } catch {
    /* fallback to store */
  }
  return { payload: data, method: 0 };
}

async function inflateRawBytes(payload: Uint8Array): Promise<Uint8Array> {
  if (typeof DecompressionStream === 'undefined') {
    throw new Error('This browser cannot decompress deflated ZIP entries.');
  }
  const ds = new DecompressionStream('deflate-raw');
  const writer = ds.writable.getWriter();
  const copy = new Uint8Array(payload);
  void writer.write(copy);
  void writer.close();
  const buf = await new Response(ds.readable).arrayBuffer();
  return new Uint8Array(buf);
}

function concatBytes(chunks: Uint8Array[]): Uint8Array {
  const total = chunks.reduce((s, c) => s + c.length, 0);
  const out = new Uint8Array(total);
  let pos = 0;
  for (const c of chunks) {
    out.set(c, pos);
    pos += c.length;
  }
  return out;
}

export async function buildBrowserZipBlob(entries: BrowserZipEntry[]): Promise<Blob> {
  const encoder = new TextEncoder();
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  for (const entry of entries) {
    const cleanName = entry.name.replace(/\\/g, '/').replace(/^\/+/, '');
    const nameBytes = encoder.encode(cleanName);
    const uncompressed = entry.data;
    const { payload, method } = await deflateRawIfSupported(uncompressed);
    const crc = crc32(uncompressed);
    const { dosTime, dosDate } = toDosTimeDate(entry.mtime ?? new Date());

    const localBuf = new ArrayBuffer(30);
    const lv = new DataView(localBuf);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0x0800, true);
    lv.setUint16(8, method, true);
    lv.setUint16(10, dosTime, true);
    lv.setUint16(12, dosDate, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, payload.length, true);
    lv.setUint32(22, uncompressed.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);

    localParts.push(new Uint8Array(localBuf), nameBytes, payload);

    const centralBuf = new ArrayBuffer(46);
    const cv = new DataView(centralBuf);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, method, true);
    cv.setUint16(12, dosTime, true);
    cv.setUint16(14, dosDate, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, payload.length, true);
    cv.setUint32(24, uncompressed.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);

    centralParts.push(new Uint8Array(centralBuf), nameBytes);
    offset += 30 + nameBytes.length + payload.length;
  }

  const centralDir = concatBytes(centralParts);
  const eocdBuf = new ArrayBuffer(22);
  const ev = new DataView(eocdBuf);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, centralDir.length, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const bytes = concatBytes([...localParts, centralDir, new Uint8Array(eocdBuf)]);
  return new Blob([bytes.slice().buffer], { type: 'application/zip' });
}

export async function readBrowserZipBuffer(buf: ArrayBuffer): Promise<Map<string, Uint8Array>> {
  const bytes = new Uint8Array(buf);
  const view = new DataView(buf);
  const decoder = new TextDecoder('utf-8');

  let eocdOffset = -1;
  const minOffset = Math.max(0, bytes.length - 65557);
  for (let i = bytes.length - 22; i >= minOffset; i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }
  if (eocdOffset < 0) throw new Error('Invalid or corrupted ZIP backup file');

  const totalEntries = view.getUint16(eocdOffset + 10, true);
  const centralSize = view.getUint32(eocdOffset + 12, true);
  const centralOffset = view.getUint32(eocdOffset + 16, true);
  if (centralOffset + centralSize > eocdOffset) {
    throw new Error('Corrupted ZIP central directory');
  }

  const out = new Map<string, Uint8Array>();
  let ptr = centralOffset;
  for (let idx = 0; idx < totalEntries; idx++) {
    if (view.getUint32(ptr, true) !== 0x02014b50) {
      throw new Error('Malformed ZIP central directory');
    }
    const method = view.getUint16(ptr + 10, true);
    const expectedCrc = view.getUint32(ptr + 16, true);
    const compressedSize = view.getUint32(ptr + 20, true);
    const nameLen = view.getUint16(ptr + 28, true);
    const extraLen = view.getUint16(ptr + 30, true);
    const commentLen = view.getUint16(ptr + 32, true);
    const localOffset = view.getUint32(ptr + 42, true);

    const rawName = decoder.decode(bytes.subarray(ptr + 46, ptr + 46 + nameLen));
    ptr += 46 + nameLen + extraLen + commentLen;

    const cleanName = rawName.replace(/\\/g, '/');
    if (cleanName.includes('..') || cleanName.startsWith('/')) {
      throw new Error(`Unsafe path inside backup archive: ${rawName}`);
    }
    if (cleanName.endsWith('/')) continue;

    if (view.getUint32(localOffset, true) !== 0x04034b50) {
      throw new Error(`Malformed local header for ${rawName}`);
    }
    const localNameLen = view.getUint16(localOffset + 26, true);
    const localExtraLen = view.getUint16(localOffset + 28, true);
    const dataStart = localOffset + 30 + localNameLen + localExtraLen;
    const payload = bytes.subarray(dataStart, dataStart + compressedSize);

    let data: Uint8Array;
    if (method === 0) data = new Uint8Array(payload);
    else if (method === 8) data = await inflateRawBytes(payload);
    else throw new Error(`Unsupported ZIP compression method (${method})`);

    if (crc32(data) !== expectedCrc) {
      throw new Error(`Checksum mismatch in ZIP entry: ${rawName}`);
    }
    out.set(cleanName, data);
  }
  return out;
}
