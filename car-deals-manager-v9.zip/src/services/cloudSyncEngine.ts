import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Preferences } from '@capacitor/preferences';
import type { CloudProviderId } from '../types';

export interface CloudProviderConfig {
  provider: CloudProviderId;
  accountEmail?: string;
  accessToken?: string;
  refreshToken?: string;
  expiresAt?: number;
  localFolderPath?: string;
  autoSyncLive: boolean;
  lastLocalBackupAt: string | null;
  lastCloudSyncAt: string | null;
  lastRemoteModifiedAt: string | null;
  lastDeviceId: string;
  lastError: string | null;
}

export interface RemoteBackupMeta {
  fileId: string;
  fileName: string;
  modifiedAt: string;
  size: number;
}

const CONFIG_KEY = 'carbiz_cloud_sync_config_v2';
const CLIENT_IDS_KEY = 'carbiz_cloud_client_ids_v1';
const DEVICE_ID_KEY = 'carbiz_device_id_v1';
const REMOTE_FILE_NAME = 'car-deals-live-sync.zip';
const LOCAL_BACKUP_SUBDIR = 'CarDealsBackups';
export const ELECTRON_OAUTH_REDIRECT_URI = 'http://127.0.0.1:42813/oauth-callback';
export const MOBILE_OAUTH_REDIRECT_URI = 'cardeals://oauth-callback';

export type OAuthCloudProvider = 'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE';

const OAUTH_ENDPOINTS = {
  GOOGLE_DRIVE: {
    envClientId: (import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined) ?? '',
    authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    scope: 'https://www.googleapis.com/auth/drive.file email',
  },
  DROPBOX: {
    envClientId: (import.meta.env.VITE_DROPBOX_CLIENT_ID as string | undefined) ?? '',
    authUrl: 'https://www.dropbox.com/oauth2/authorize',
    tokenUrl: 'https://api.dropboxapi.com/oauth2/token',
    scope: 'files.content.write files.content.read account_info.read',
  },
  ONEDRIVE: {
    envClientId: (import.meta.env.VITE_ONEDRIVE_CLIENT_ID as string | undefined) ?? '',
    authUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    tokenUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    scope: 'Files.ReadWrite.AppFolder User.Read offline_access',
  },
} as const;

function readSavedClientIds(): Partial<Record<OAuthCloudProvider, string>> {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(CLIENT_IDS_KEY) : null;
    return raw ? (JSON.parse(raw) as Partial<Record<OAuthCloudProvider, string>>) : {};
  } catch {
    return {};
  }
}

export function getProviderClientId(provider: OAuthCloudProvider): string {
  const saved = readSavedClientIds()[provider]?.trim();
  if (saved) return saved;
  return OAUTH_ENDPOINTS[provider].envClientId.trim();
}

export async function saveProviderClientId(provider: OAuthCloudProvider, clientId: string): Promise<void> {
  const cleaned = clientId.trim();
  const current = readSavedClientIds();
  if (cleaned) current[provider] = cleaned;
  else delete current[provider];
  const serialized = JSON.stringify(current);
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(CLIENT_IDS_KEY, serialized);
  }
  if (Capacitor.isNativePlatform()) {
    await Preferences.set({ key: CLIENT_IDS_KEY, value: serialized }).catch(() => {});
  }
}

export async function hydrateClientIdsFromPreferences(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    const { value } = await Preferences.get({ key: CLIENT_IDS_KEY });
    if (value && typeof localStorage !== 'undefined') {
      localStorage.setItem(CLIENT_IDS_KEY, value);
    }
  } catch {
    /* ignore */
  }
}

export function getOAuthRedirectUri(): string {
  if (typeof window === 'undefined') return MOBILE_OAUTH_REDIRECT_URI;
  if (window.api?.isElectron) return ELECTRON_OAUTH_REDIRECT_URI;
  if (Capacitor.isNativePlatform()) return MOBILE_OAUTH_REDIRECT_URI;
  return `${window.location.origin}/oauth-callback`;
}

export function isProviderConfigured(provider: OAuthCloudProvider): boolean {
  return Boolean(getProviderClientId(provider));
}

export async function getOrCreateDeviceId(): Promise<string> {
  if (Capacitor.isNativePlatform()) {
    const { value } = await Preferences.get({ key: DEVICE_ID_KEY });
    if (value) return value;
    const id = `mobile-${crypto.randomUUID()}`;
    await Preferences.set({ key: DEVICE_ID_KEY, value: id });
    return id;
  }
  let id = localStorage.getItem(DEVICE_ID_KEY);
  if (!id) {
    id = `${window.api?.isElectron ? 'laptop' : 'web'}-${crypto.randomUUID()}`;
    localStorage.setItem(DEVICE_ID_KEY, id);
  }
  return id;
}

export async function loadCloudConfig(): Promise<CloudProviderConfig> {
  const deviceId = await getOrCreateDeviceId();
  const fallback: CloudProviderConfig = {
    provider: 'NONE',
    autoSyncLive: true,
    lastLocalBackupAt: null,
    lastCloudSyncAt: null,
    lastRemoteModifiedAt: null,
    lastDeviceId: deviceId,
    lastError: null,
  };
  try {
    const raw = Capacitor.isNativePlatform()
      ? (await Preferences.get({ key: CONFIG_KEY })).value
      : localStorage.getItem(CONFIG_KEY);
    if (!raw) return fallback;
    return { ...fallback, ...JSON.parse(raw), lastDeviceId: deviceId };
  } catch {
    return fallback;
  }
}

export async function saveCloudConfig(cfg: CloudProviderConfig): Promise<void> {
  const serialized = JSON.stringify(cfg);
  if (Capacitor.isNativePlatform()) {
    await Preferences.set({ key: CONFIG_KEY, value: serialized });
  } else {
    localStorage.setItem(CONFIG_KEY, serialized);
  }
}

function base64UrlEncode(bytes: Uint8Array): string {
  let str = '';
  for (let i = 0; i < bytes.length; i++) str += String.fromCharCode(bytes[i]);
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function createPkcePair(): Promise<{ verifier: string; challenge: string }> {
  const random = new Uint8Array(32);
  crypto.getRandomValues(random);
  const verifier = base64UrlEncode(random);
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
  const challenge = base64UrlEncode(new Uint8Array(digest));
  return { verifier, challenge };
}

export async function startCloudOAuthFlow(
  provider: 'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE',
): Promise<void> {
  const meta = OAUTH_ENDPOINTS[provider];
  const clientId = getProviderClientId(provider);
  if (!clientId) {
    const label =
      provider === 'ONEDRIVE'
        ? 'OneDrive Application (Client) ID'
        : provider === 'DROPBOX'
        ? 'Dropbox App Key (Client ID)'
        : 'Google Drive Client ID';
    throw new Error(`Paste your ${label} in the setup box below first, then click Connect.`);
  }
  const { verifier, challenge } = await createPkcePair();
  const state = crypto.randomUUID();
  sessionStorage.setItem('carbiz_oauth_pending', JSON.stringify({ provider, verifier, state }));

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: getOAuthRedirectUri(),
    response_type: 'code',
    scope: meta.scope,
    code_challenge: challenge,
    code_challenge_method: 'S256',
    state,
  });

  if (provider === 'GOOGLE_DRIVE') {
    params.set('access_type', 'offline');
    params.set('prompt', 'consent');
  } else if (provider === 'DROPBOX') {
    params.set('token_access_type', 'offline');
  }

  const authUrl = `${meta.authUrl}?${params.toString()}`;
  if (Capacitor.isNativePlatform()) {
    await Browser.open({ url: authUrl });
  } else if (window.api?.openExternalUrl) {
    await window.api.openExternalUrl(authUrl);
  } else {
    window.open(authUrl, '_blank', 'noopener,noreferrer');
  }
}

export async function completeCloudOAuthCallback(callbackUrl: string): Promise<CloudProviderConfig | null> {
  const url = new URL(callbackUrl);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const pendingRaw = sessionStorage.getItem('carbiz_oauth_pending');
  if (!code || !pendingRaw) return null;

  const pending = JSON.parse(pendingRaw) as {
    provider: 'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE';
    verifier: string;
    state: string;
  };
  if (state !== pending.state) throw new Error('OAuth security state mismatch.');

  const meta = OAUTH_ENDPOINTS[pending.provider];
  const body = new URLSearchParams({
    client_id: getProviderClientId(pending.provider),
    grant_type: 'authorization_code',
    code,
    redirect_uri: getOAuthRedirectUri(),
    code_verifier: pending.verifier,
  });

  const tokenRes = await fetch(meta.tokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });
  if (!tokenRes.ok) {
    throw new Error(`Cloud authorization failed (${tokenRes.status}): ${await tokenRes.text()}`);
  }
  const tokens = await tokenRes.json();
  let accountEmail: string | undefined;
  try {
    if (pending.provider === 'ONEDRIVE') {
      const meRes = await fetch('https://graph.microsoft.com/v1.0/me', {
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });
      if (meRes.ok) {
        const me = await meRes.json();
        accountEmail = me.mail || me.userPrincipalName;
      }
    } else if (pending.provider === 'GOOGLE_DRIVE') {
      const meRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });
      if (meRes.ok) {
        const me = await meRes.json();
        accountEmail = me.email;
      }
    } else if (pending.provider === 'DROPBOX') {
      const meRes = await fetch('https://api.dropboxapi.com/2/users/get_current_account', {
        method: 'POST',
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });
      if (meRes.ok) {
        const me = await meRes.json();
        accountEmail = me.email;
      }
    }
  } catch {
    /* optional profile lookup */
  }
  const cfg = await loadCloudConfig();
  const updated: CloudProviderConfig = {
    ...cfg,
    provider: pending.provider,
    accountEmail: accountEmail ?? cfg.accountEmail,
    accessToken: tokens.access_token,
    refreshToken: tokens.refresh_token ?? cfg.refreshToken,
    expiresAt: Date.now() + (Number(tokens.expires_in ?? 3600) - 60) * 1000,
    lastError: null,
  };
  await saveCloudConfig(updated);
  sessionStorage.removeItem('carbiz_oauth_pending');
  if (Capacitor.isNativePlatform()) {
    await Browser.close().catch(() => {});
  }
  return updated;
}

export async function disconnectCloudAccount(): Promise<CloudProviderConfig> {
  const cfg = await loadCloudConfig();
  const cleared: CloudProviderConfig = {
    ...cfg,
    provider: 'NONE',
    accountEmail: undefined,
    accessToken: undefined,
    refreshToken: undefined,
    expiresAt: undefined,
    lastError: null,
  };
  await saveCloudConfig(cleared);
  return cleared;
}

async function ensureFreshAccessToken(cfg: CloudProviderConfig): Promise<CloudProviderConfig> {
  if (
    cfg.provider === 'NONE' ||
    cfg.provider === 'LOCAL_FOLDER' ||
    !cfg.accessToken ||
    (cfg.expiresAt && Date.now() < cfg.expiresAt)
  ) {
    return cfg;
  }
  if (!cfg.refreshToken) return cfg;

  const meta = OAUTH_ENDPOINTS[cfg.provider];
  const body = new URLSearchParams({
    client_id: getProviderClientId(cfg.provider),
    grant_type: 'refresh_token',
    refresh_token: cfg.refreshToken,
  });
  const res = await fetch(meta.tokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });
  if (!res.ok) throw new Error('Cloud session expired. Please reconnect your cloud account.');
  const data = await res.json();
  const refreshed: CloudProviderConfig = {
    ...cfg,
    accessToken: data.access_token,
    refreshToken: data.refresh_token ?? cfg.refreshToken,
    expiresAt: Date.now() + (Number(data.expires_in ?? 3600) - 60) * 1000,
  };
  await saveCloudConfig(refreshed);
  return refreshed;
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const res = String(reader.result ?? '');
      resolve(res.includes(',') ? res.split(',')[1] : res);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

/** Step 1: Always persist a local backup archive on device first before touching the network. */
export async function writeLocalBackupFirst(
  zipBlob: Blob,
  stampedFileName: string,
): Promise<{ localPath: string }> {
  if (Capacitor.isNativePlatform()) {
    await Filesystem.mkdir({
      path: LOCAL_BACKUP_SUBDIR,
      directory: Directory.Documents,
      recursive: true,
    }).catch(() => {});

    const base64Data = await blobToBase64(zipBlob);
    const stampedPath = `${LOCAL_BACKUP_SUBDIR}/${stampedFileName}`;
    const res = await Filesystem.writeFile({
      path: stampedPath,
      data: base64Data,
      directory: Directory.Documents,
    });
    // Also update rolling latest snapshot on local device storage
    await Filesystem.writeFile({
      path: `${LOCAL_BACKUP_SUBDIR}/${REMOTE_FILE_NAME}`,
      data: base64Data,
      directory: Directory.Documents,
    });
    return { localPath: res.uri };
  }

  return { localPath: `Documents/CarDealsBackups/${stampedFileName}` };
}

async function uploadToGoogleDrive(token: string, zipBlob: Blob): Promise<RemoteBackupMeta> {
  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
      `name='${REMOTE_FILE_NAME}' and trashed=false`,
    )}&fields=files(id,name,modifiedTime,size)`,
    { headers: { Authorization: `Bearer ${token}` } },
  );
  const searchJson = await searchRes.json();
  const existing = searchJson.files?.[0];

  const boundary = 'carbiz_multipart_boundary';
  const metadata = JSON.stringify({ name: REMOTE_FILE_NAME, mimeType: 'application/zip' });
  const zipBytes = new Uint8Array(await zipBlob.arrayBuffer());
  const head = new TextEncoder().encode(
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n--${boundary}\r\nContent-Type: application/zip\r\n\r\n`,
  );
  const tail = new TextEncoder().encode(`\r\n--${boundary}--`);
  const body = new Uint8Array(head.length + zipBytes.length + tail.length);
  body.set(head, 0);
  body.set(zipBytes, head.length);
  body.set(tail, head.length + zipBytes.length);

  const uploadUrl = existing
    ? `https://www.googleapis.com/upload/drive/v3/files/${existing.id}?uploadType=multipart&fields=id,name,modifiedTime,size`
    : `https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,modifiedTime,size`;

  const upRes = await fetch(uploadUrl, {
    method: existing ? 'PATCH' : 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': `multipart/related; boundary=${boundary}`,
    },
    body,
  });
  if (!upRes.ok) throw new Error(`Google Drive upload failed: ${await upRes.text()}`);
  const file = await upRes.json();
  return {
    fileId: file.id,
    fileName: file.name,
    modifiedAt: file.modifiedTime,
    size: Number(file.size ?? zipBlob.size),
  };
}

async function uploadToDropbox(token: string, zipBlob: Blob): Promise<RemoteBackupMeta> {
  const upRes = await fetch('https://content.dropboxapi.com/2/files/upload', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/octet-stream',
      'Dropbox-API-Arg': JSON.stringify({
        path: `/${REMOTE_FILE_NAME}`,
        mode: 'overwrite',
        mute: true,
      }),
    },
    body: zipBlob,
  });
  if (!upRes.ok) throw new Error(`Dropbox upload failed: ${await upRes.text()}`);
  const file = await upRes.json();
  return {
    fileId: file.id,
    fileName: file.name,
    modifiedAt: file.server_modified,
    size: Number(file.size ?? zipBlob.size),
  };
}

async function uploadToOneDrive(token: string, zipBlob: Blob): Promise<RemoteBackupMeta> {
  const upRes = await fetch(
    `https://graph.microsoft.com/v1.0/me/drive/special/approot:/${REMOTE_FILE_NAME}:/content`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/zip',
      },
      body: zipBlob,
    },
  );
  if (!upRes.ok) throw new Error(`OneDrive upload failed: ${await upRes.text()}`);
  const file = await upRes.json();
  return {
    fileId: file.id,
    fileName: file.name,
    modifiedAt: file.lastModifiedDateTime,
    size: Number(file.size ?? zipBlob.size),
  };
}

/** Step 1 (Local Snapshot) -> Step 2 (Live Cloud Upload) */
export async function pushLocalThenCloud(
  zipBlob: Blob,
  stampedFileName: string,
): Promise<{ localPath: string; syncedCloud: boolean; config: CloudProviderConfig }> {
  const { localPath } = await writeLocalBackupFirst(zipBlob, stampedFileName);
  let cfg = await loadCloudConfig();
  const now = new Date().toISOString();
  cfg.lastLocalBackupAt = now;

  if (cfg.provider === 'NONE' || cfg.provider === 'LOCAL_FOLDER') {
    await saveCloudConfig(cfg);
    return { localPath, syncedCloud: false, config: cfg };
  }

  try {
    cfg = await ensureFreshAccessToken(cfg);
    if (!cfg.accessToken) throw new Error('Cloud account not authenticated.');

    let meta: RemoteBackupMeta;
    if (cfg.provider === 'GOOGLE_DRIVE') {
      meta = await uploadToGoogleDrive(cfg.accessToken, zipBlob);
    } else if (cfg.provider === 'DROPBOX') {
      meta = await uploadToDropbox(cfg.accessToken, zipBlob);
    } else {
      meta = await uploadToOneDrive(cfg.accessToken, zipBlob);
    }

    cfg.lastCloudSyncAt = now;
    cfg.lastRemoteModifiedAt = meta.modifiedAt;
    cfg.lastError = null;
    await saveCloudConfig(cfg);
    return { localPath, syncedCloud: true, config: cfg };
  } catch (err) {
    cfg.lastError = err instanceof Error ? err.message : String(err);
    await saveCloudConfig(cfg);
    throw err;
  }
}

export async function downloadLatestFromCloud(): Promise<{ blob: Blob; meta: RemoteBackupMeta } | null> {
  let cfg = await loadCloudConfig();
  if (cfg.provider === 'NONE' || cfg.provider === 'LOCAL_FOLDER') return null;
  cfg = await ensureFreshAccessToken(cfg);
  if (!cfg.accessToken) return null;

  if (cfg.provider === 'GOOGLE_DRIVE') {
    const searchRes = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
        `name='${REMOTE_FILE_NAME}' and trashed=false`,
      )}&fields=files(id,name,modifiedTime,size)`,
      { headers: { Authorization: `Bearer ${cfg.accessToken}` } },
    );
    const list = await searchRes.json();
    const file = list.files?.[0];
    if (!file) return null;
    const dlRes = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, {
      headers: { Authorization: `Bearer ${cfg.accessToken}` },
    });
    if (!dlRes.ok) throw new Error('Failed to download sync snapshot from Google Drive.');
    return {
      blob: await dlRes.blob(),
      meta: { fileId: file.id, fileName: file.name, modifiedAt: file.modifiedTime, size: Number(file.size ?? 0) },
    };
  }

  if (cfg.provider === 'DROPBOX') {
    const dlRes = await fetch('https://content.dropboxapi.com/2/files/download', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${cfg.accessToken}`,
        'Dropbox-API-Arg': JSON.stringify({ path: `/${REMOTE_FILE_NAME}` }),
      },
    });
    if (dlRes.status === 409) return null;
    if (!dlRes.ok) throw new Error('Failed to download sync snapshot from Dropbox.');
    const metaHeader = JSON.parse(dlRes.headers.get('dropbox-api-result') ?? '{}');
    return {
      blob: await dlRes.blob(),
      meta: {
        fileId: metaHeader.id ?? 'dropbox',
        fileName: REMOTE_FILE_NAME,
        modifiedAt: metaHeader.server_modified ?? new Date().toISOString(),
        size: Number(metaHeader.size ?? 0),
      },
    };
  }

  if (cfg.provider === 'ONEDRIVE') {
    const dlRes = await fetch(
      `https://graph.microsoft.com/v1.0/me/drive/special/approot:/${REMOTE_FILE_NAME}:/content`,
      { headers: { Authorization: `Bearer ${cfg.accessToken}` } },
    );
    if (dlRes.status === 404) return null;
    if (!dlRes.ok) throw new Error('Failed to download sync snapshot from OneDrive.');
    return {
      blob: await dlRes.blob(),
      meta: {
        fileId: 'onedrive',
        fileName: REMOTE_FILE_NAME,
        modifiedAt: new Date().toISOString(),
        size: 0,
      },
    };
  }

  return null;
}
