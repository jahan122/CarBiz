import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) !== 0 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

export interface ZipInputEntry {
  name: string;
  data: Buffer;
  mtime?: Date;
}

function toDosTimeDate(d: Date): { dosTime: number; dosDate: number } {
  const year = Math.max(1980, d.getFullYear());
  const dosTime =
    ((d.getHours() & 0x1f) << 11) |
    ((d.getMinutes() & 0x3f) << 5) |
    ((d.getSeconds() >> 1) & 0x1f);
  const dosDate =
    (((year - 1980) & 0x7f) << 9) |
    (((d.getMonth() + 1) & 0x0f) << 5) |
    (d.getDate() & 0x1f);
  return { dosTime, dosDate };
}

/** Creates a standard PKZIP archive buffer from in-memory entries (zero external dependencies). */
export function buildZipBuffer(entries: ZipInputEntry[]): Buffer {
  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const entry of entries) {
    const cleanName = entry.name.replace(/\\/g, '/').replace(/^\/+/, '');
    const nameBuf = Buffer.from(cleanName, 'utf8');
    const uncompressed = entry.data;
    const compressed = zlib.deflateRawSync(uncompressed, { level: 6 });
    const useDeflate = compressed.length < uncompressed.length;
    const payload = useDeflate ? compressed : uncompressed;
    const method = useDeflate ? 8 : 0;
    const crc = crc32(uncompressed);
    const { dosTime, dosDate } = toDosTimeDate(entry.mtime ?? new Date());

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4); // version needed
    localHeader.writeUInt16LE(0x0800, 6); // UTF-8 filename flag
    localHeader.writeUInt16LE(method, 8);
    localHeader.writeUInt16LE(dosTime, 10);
    localHeader.writeUInt16LE(dosDate, 12);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(payload.length, 18);
    localHeader.writeUInt32LE(uncompressed.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28);

    localParts.push(localHeader, nameBuf, payload);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(20, 4);
    centralHeader.writeUInt16LE(20, 6);
    centralHeader.writeUInt16LE(0x0800, 8);
    centralHeader.writeUInt16LE(method, 10);
    centralHeader.writeUInt16LE(dosTime, 12);
    centralHeader.writeUInt16LE(dosDate, 14);
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(payload.length, 20);
    centralHeader.writeUInt32LE(uncompressed.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(offset, 42);

    centralParts.push(centralHeader, nameBuf);
    offset += localHeader.length + nameBuf.length + payload.length;
  }

  const centralDir = Buffer.concat(centralParts);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralDir.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localParts, centralDir, eocd]);
}

export function collectDirectoryEntries(dirPath: string, zipPrefix: string): ZipInputEntry[] {
  if (!fs.existsSync(dirPath)) return [];
  const results: ZipInputEntry[] = [];
  const walk = (currentDir: string, relBase: string) => {
    const items = fs.readdirSync(currentDir, { withFileTypes: true });
    for (const item of items) {
      const fullPath = path.join(currentDir, item.name);
      const rel = relBase ? `${relBase}/${item.name}` : item.name;
      if (item.isDirectory()) {
        walk(fullPath, rel);
      } else if (item.isFile()) {
        const stat = fs.statSync(fullPath);
        results.push({
          name: `${zipPrefix}/${rel}`,
          data: fs.readFileSync(fullPath),
          mtime: stat.mtime,
        });
      }
    }
  };
  walk(dirPath, '');
  return results;
}

/** Extracts a ZIP buffer into memory entries, verifying CRC32 and rejecting unsafe paths. */
export function readZipBuffer(zipBuf: Buffer): Map<string, Buffer> {
  // Locate End of Central Directory (signature 0x06054b50)
  let eocdOffset = -1;
  const minOffset = Math.max(0, zipBuf.length - 65557);
  for (let i = zipBuf.length - 22; i >= minOffset; i--) {
    if (zipBuf.readUInt32LE(i) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }
  if (eocdOffset < 0) throw new Error('Invalid or corrupted ZIP backup file');

  const totalEntries = zipBuf.readUInt16LE(eocdOffset + 10);
  const centralSize = zipBuf.readUInt32LE(eocdOffset + 12);
  const centralOffset = zipBuf.readUInt32LE(eocdOffset + 16);

  if (centralOffset + centralSize > eocdOffset) {
    throw new Error('Corrupted ZIP central directory');
  }

  const out = new Map<string, Buffer>();
  let ptr = centralOffset;

  for (let idx = 0; idx < totalEntries; idx++) {
    if (zipBuf.readUInt32LE(ptr) !== 0x02014b50) {
      throw new Error('Malformed ZIP central directory entry');
    }
    const method = zipBuf.readUInt16LE(ptr + 10);
    const expectedCrc = zipBuf.readUInt32LE(ptr + 16);
    const compressedSize = zipBuf.readUInt32LE(ptr + 20);
    const nameLen = zipBuf.readUInt16LE(ptr + 28);
    const extraLen = zipBuf.readUInt16LE(ptr + 30);
    const commentLen = zipBuf.readUInt16LE(ptr + 32);
    const localOffset = zipBuf.readUInt32LE(ptr + 42);

    const rawName = zipBuf.subarray(ptr + 46, ptr + 46 + nameLen).toString('utf8');
    ptr += 46 + nameLen + extraLen + commentLen;

    const normName = path.posix.normalize(rawName.replace(/\\/g, '/'));
    if (normName.startsWith('..') || path.posix.isAbsolute(normName)) {
      throw new Error(`Unsafe path inside backup archive: ${rawName}`);
    }
    if (normName.endsWith('/')) continue;

    if (zipBuf.readUInt32LE(localOffset) !== 0x04034b50) {
      throw new Error(`Malformed local header for ${rawName}`);
    }
    const localNameLen = zipBuf.readUInt16LE(localOffset + 26);
    const localExtraLen = zipBuf.readUInt16LE(localOffset + 28);
    const dataStart = localOffset + 30 + localNameLen + localExtraLen;
    const payload = zipBuf.subarray(dataStart, dataStart + compressedSize);

    let data: Buffer;
    if (method === 0) {
      data = Buffer.from(payload);
    } else if (method === 8) {
      data = zlib.inflateRawSync(payload);
    } else {
      throw new Error(`Unsupported compression method (${method}) in ZIP backup`);
    }

    if (crc32(data) !== expectedCrc) {
      throw new Error(`Checksum mismatch in ZIP backup entry: ${rawName}`);
    }
    out.set(normName, data);
  }

  return out;
}
