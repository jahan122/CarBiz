import { contextBridge, ipcRenderer } from 'electron';
import type {
  AttachmentCategory,
  BusinessProfile,
  ChequeStatus,
  CreateUserInput,
  DueDatesInput,
  ExpenseInput,
  InitialPaymentInput,
  NewDealInput,
  PaymentInput,
  ReserveInput,
  SaleInput,
  TransferInput,
  UpdateDealInput,
  UpdateUserInput,
} from './db';

contextBridge.exposeInMainWorld('api', {
  isElectron: true,
  listDeals: () => ipcRenderer.invoke('deals:list'),
  listDeletedDeals: () => ipcRenderer.invoke('deals:listDeleted'),
  getDeal: (id: number) => ipcRenderer.invoke('deals:get', id),
  createDeal: (
    input: NewDealInput,
    sale?: SaleInput | null,
    initialPayments?: {
      sellerPayment?: InitialPaymentInput | null;
      buyerPayment?: InitialPaymentInput | null;
    } | null,
  ) => ipcRenderer.invoke('deals:create', input, sale, initialPayments),
  updateDeal: (id: number, input: UpdateDealInput) => ipcRenderer.invoke('deals:update', id, input),
  softDeleteDeal: (id: number) => ipcRenderer.invoke('deals:softDelete', id),
  restoreDeal: (id: number) => ipcRenderer.invoke('deals:restore', id),
  deleteDeal: (id: number) => ipcRenderer.invoke('deals:delete', id),
  emptyRecycleBin: () => ipcRenderer.invoke('deals:emptyRecycleBin'),
  reserveDeal: (id: number, input: ReserveInput) => ipcRenderer.invoke('deals:reserve', id, input),
  cancelReservation: (id: number, refundToken?: boolean) => ipcRenderer.invoke('deals:cancelReservation', id, refundToken),
  markSold: (id: number, sale: SaleInput, initialBuyerPayment?: InitialPaymentInput | null) =>
    ipcRenderer.invoke('deals:markSold', id, sale, initialBuyerPayment),
  revertSale: (id: number, deleteBuyerPayments?: boolean) => ipcRenderer.invoke('deals:revertSale', id, deleteBuyerPayments),
  updateDueDates: (id: number, input: DueDatesInput) => ipcRenderer.invoke('deals:updateDueDates', id, input),
  updateChecklist: (id: number, checklistJson: string, tokenTaxPaidTill?: string | null) =>
    ipcRenderer.invoke('deals:updateChecklist', id, checklistJson, tokenTaxPaidTill),
  updateTransfer: (id: number, input: TransferInput) => ipcRenderer.invoke('transfer:update', id, input),
  listAttachments: (dealId: number) => ipcRenderer.invoke('attachments:list', dealId),
  pickAndAddAttachment: (dealId: number, category: AttachmentCategory, label?: string) =>
    ipcRenderer.invoke('attachments:pickAndAdd', dealId, category, label),
  pickAndSaveAttachment: (dealId: number, category: AttachmentCategory, label?: string) =>
    ipcRenderer.invoke('attachments:pickAndAdd', dealId, category, label),
  saveWebcamAttachment: (dealId: number, category: AttachmentCategory, label: string, dataUrl: string) =>
    ipcRenderer.invoke('attachments:saveWebcam', dealId, category, label, dataUrl),
  saveAttachmentData: (
    dealId: number,
    category: AttachmentCategory,
    label: string,
    fileName: string,
    dataUrl: string,
  ) => ipcRenderer.invoke('attachments:saveData', dealId, category, label, fileName, dataUrl),
  readAttachmentDataUrl: (filePath: string) => ipcRenderer.invoke('attachments:readDataUrl', filePath),
  getAttachmentDataUrl: (filePath: string) => ipcRenderer.invoke('attachments:readDataUrl', filePath),
  deleteAttachment: (id: number) => ipcRenderer.invoke('attachments:delete', id),
  listExpenses: (dealId: number) => ipcRenderer.invoke('expenses:list', dealId),
  listAllExpenses: () => ipcRenderer.invoke('expenses:listAll'),
  addExpense: (dealId: number, input: ExpenseInput) => ipcRenderer.invoke('expenses:add', dealId, input),
  updateExpense: (id: number, input: ExpenseInput) => ipcRenderer.invoke('expenses:update', id, input),
  deleteExpense: (id: number) => ipcRenderer.invoke('expenses:delete', id),
  listPayments: (dealId: number) => ipcRenderer.invoke('payments:list', dealId),
  listAllPayments: () => ipcRenderer.invoke('payments:listAll'),
  addPayment: (dealId: number, input: PaymentInput) => ipcRenderer.invoke('payments:add', dealId, input),
  updatePayment: (id: number, input: PaymentInput) => ipcRenderer.invoke('payments:update', id, input),
  updateChequeStatus: (id: number, status: ChequeStatus) => ipcRenderer.invoke('payments:updateChequeStatus', id, status),
  deletePayment: (id: number) => ipcRenderer.invoke('payments:delete', id),
  listAuditLogs: (dealId?: number, limit?: number) => ipcRenderer.invoke('audit:list', dealId, limit),
  hasUsers: () => ipcRenderer.invoke('users:hasUsers'),
  listUsers: () => ipcRenderer.invoke('users:list'),
  createUser: (input: CreateUserInput) => ipcRenderer.invoke('users:create', input),
  updateUser: (id: number, input: UpdateUserInput) => ipcRenderer.invoke('users:update', id, input),
  deleteUser: (id: number) => ipcRenderer.invoke('users:delete', id),
  authenticatePin: (pin: string, userId?: number) => ipcRenderer.invoke('users:authenticate', pin, userId),
  lockApp: () => ipcRenderer.invoke('users:lock'),
  getAutoLockMinutes: () => ipcRenderer.invoke('settings:getAutoLockMinutes'),
  setAutoLockMinutes: (minutes: number) => ipcRenderer.invoke('settings:setAutoLockMinutes', minutes),
  getBusinessProfile: () => ipcRenderer.invoke('settings:getBusinessProfile'),
  setBusinessProfile: (profile: Partial<BusinessProfile>) => ipcRenderer.invoke('settings:setBusinessProfile', profile),
  listAutoBackups: () => ipcRenderer.invoke('data:listAutoBackups'),
  autoBackupFolder: () => ipcRenderer.invoke('data:autoBackupFolder'),
  getCloudBackupSettings: () => ipcRenderer.invoke('settings:getCloudBackupSettings'),
  getCloudClientIds: () => ipcRenderer.invoke('settings:getCloudClientIds'),
  saveCloudClientId: (provider: 'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE', clientId: string) =>
    ipcRenderer.invoke('settings:saveCloudClientId', provider, clientId),
  connectCloudProvider: (provider: 'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE', clientId?: string) =>
    ipcRenderer.invoke('settings:connectCloudProvider', provider, clientId),
  disconnectCloudProvider: () => ipcRenderer.invoke('settings:disconnectCloudProvider'),
  pullLatestFromCloud: () => ipcRenderer.invoke('data:pullCloudLatest'),
  onCloudOAuthCompleted: (callback: (payload: { provider: string; accountEmail: string | null }) => void) => {
    const listener = (_event: unknown, payload: { provider: string; accountEmail: string | null }) => callback(payload);
    ipcRenderer.on('cloud:oauthCompleted', listener);
    return () => ipcRenderer.removeListener('cloud:oauthCompleted', listener);
  },
  pickCloudBackupFolder: () => ipcRenderer.invoke('settings:pickCloudBackupFolder'),
  clearCloudBackupFolder: () => ipcRenderer.invoke('settings:clearCloudBackupFolder'),
  syncBackupNow: () => ipcRenderer.invoke('data:syncCloudNow'),
  backupOrExport: (kind: 'zip' | 'db' | 'csv') => ipcRenderer.invoke('data:export', kind),
  restoreFromPath: (backupPath: string) => ipcRenderer.invoke('data:restoreFromPath', backupPath),
  restoreFromBackup: (backupPath?: string) => ipcRenderer.invoke('data:restoreFromBackup', backupPath),
  pickAndRestore: () => ipcRenderer.invoke('data:pickAndRestore'),
  saveReceiptPdf: (html: string, defaultFileName: string) => ipcRenderer.invoke('receipt:savePdf', html, defaultFileName),
  printReceiptHtml: (html: string) => ipcRenderer.invoke('receipt:printHtml', html),
  showInFolder: (filePath: string) => ipcRenderer.invoke('shell:showInFolder', filePath),
  openExternalUrl: (url: string) => ipcRenderer.invoke('shell:openExternal', url),
});