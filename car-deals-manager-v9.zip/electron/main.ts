import { app, BrowserWindow, dialog, ipcMain, Menu, session, shell } from 'electron';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  CarDealsDb,
  type AppUser,
  type AttachmentCategory,
  type BusinessProfile,
  type ChequeStatus,
  type CreateUserInput,
  type DueDatesInput,
  type ExpenseInput,
  type InitialPaymentInput,
  type NewDealInput,
  type PaymentInput,
  type ReserveInput,
  type SaleInput,
  type TransferInput,
  type UpdateDealInput,
  type UpdateUserInput,
} from './db';
import { buildZipBuffer, collectDirectoryEntries, readZipBuffer } from './zip';
import {
  downloadZipFromOAuthCloud,
  getOAuthState,
  getSavedClientIds,
  saveClientId,
  setOAuthState,
  startElectronOAuth,
  uploadZipToOAuthCloud,
  type OAuthProvider,
} from './cloud-oauth';

const isDev = !app.isPackaged && Boolean(process.env.VITE_DEV_SERVER_URL);
let db: CarDealsDb;
let mainWindow: BrowserWindow | null = null;
let activeUser: AppUser | null = null;

function attachmentsDir(): string {
  const dir = path.join(app.getPath('userData'), 'attachments');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function backupsDir(): string {
  const dir = path.join(app.getPath('documents'), 'Car Deals Manager Backups');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function legacyBackupsDir(): string {
  return path.join(app.getPath('userData'), 'backups');
}

function requirePermission(check: 'AUTH' | 'OWNER' | 'PAYMENTS' | 'MARK_SOLD' | 'DELETE'): void {
  if (!db.hasUsers()) return; // PIN lock not enabled yet
  if (!activeUser) {
    throw new Error('Application is locked. Please unlock with your PIN.');
  }
  if (activeUser.role === 'OWNER') return;
  if (check === 'OWNER') throw new Error('Only the Owner account can perform this action.');
  if (check === 'PAYMENTS' && !activeUser.can_manage_payments) {
    throw new Error('Your account does not have permission to manage payments.');
  }
  if (check === 'MARK_SOLD' && !activeUser.can_mark_sold) {
    throw new Error('Your account does not have permission to reserve or sell vehicles.');
  }
  if (check === 'DELETE' && !activeUser.can_delete) {
    throw new Error('Your account does not have permission to delete records.');
  }
}

function currentActorName(): string | null {
  return activeUser?.name ?? null;
}

function resolveAttachmentPath(storedPath: string): string | null {
  if (storedPath && fs.existsSync(storedPath)) return storedPath;
  if (!storedPath) return null;
  const parts = storedPath.replace(/\\/g, '/').split('/');
  const idx = parts.lastIndexOf('attachments');
  if (idx >= 0 && idx + 2 < parts.length) {
    const candidate = path.join(attachmentsDir(), ...parts.slice(idx + 1));
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

function buildPortableSyncManifest(database: CarDealsDb): Buffer {
  const activeDeals = database.listDeals();
  const deletedDeals = database.listDeletedDeals();
  const allDeals = [...activeDeals, ...deletedDeals].map(
    ({ total_expenses: _te, paid_to_seller: _ps, received_from_buyer: _rb, attachment_count: _ac, ...raw }) => raw,
  );
  const expenses = database.listAllExpenses();
  const payments = database.listAllPayments();
  const auditLogs = database.listAuditLogs(undefined, 1000);
  const profile = database.getBusinessProfile();
  const attachments = allDeals.flatMap((d) => database.listAttachments(d.id));
  const payload = {
    sourcePlatform: 'desktop',
    exportedAt: new Date().toISOString(),
    nextDealId: allDeals.reduce((m, d) => Math.max(m, d.id + 1), 1),
    nextExpenseId: expenses.reduce((m, e) => Math.max(m, e.id + 1), 1),
    nextPaymentId: payments.reduce((m, p) => Math.max(m, p.id + 1), 1),
    nextAttId: attachments.reduce((m, a) => Math.max(m, a.id + 1), 1),
    nextAuditId: auditLogs.reduce((m, l) => Math.max(m, l.id + 1), 1),
    deals: allDeals,
    expenses,
    payments,
    attachments,
    attachmentData: {},
    auditLogs,
    users: [],
    profile,
    autoLockMinutes: database.getAutoLockMinutes(),
  };
  return Buffer.from(JSON.stringify(payload, null, 2), 'utf8');
}

async function createFullZipBackup(database: CarDealsDb, destZipPath: string): Promise<void> {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'carbiz-zip-'));
  try {
    const tmpDb = path.join(tmpDir, 'car-deals.db');
    await database.backupTo(tmpDb);
    const entries = [
      {
        name: 'car-deals.db',
        data: fs.readFileSync(tmpDb),
        mtime: new Date(),
      },
      {
        name: 'sync-manifest.json',
        data: buildPortableSyncManifest(database),
        mtime: new Date(),
      },
      ...collectDirectoryEntries(attachmentsDir(), 'attachments'),
    ];
    const zipBuffer = buildZipBuffer(entries);
    fs.mkdirSync(path.dirname(destZipPath), { recursive: true });
    fs.writeFileSync(destZipPath, zipBuffer);
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

function syncZipToCloudDir(database: CarDealsDb, localZipPath: string): { synced: boolean; cloudPath?: string; error?: string } {
  const settings = database.getCloudBackupSettings();
  const cloudDir = settings.cloud_backup_dir.trim();
  if (!cloudDir) return { synced: false };
  try {
    fs.mkdirSync(cloudDir, { recursive: true });
    const destPath = path.join(cloudDir, path.basename(localZipPath));
    fs.copyFileSync(localZipPath, destPath);
    fs.copyFileSync(localZipPath, path.join(cloudDir, 'car-deals-live-sync.zip'));
    const cloudFiles = fs
      .readdirSync(cloudDir)
      .filter((f) => f.startsWith('auto-backup-') && f.endsWith('.zip'))
      .sort();
    while (cloudFiles.length > 30) {
      const oldest = cloudFiles.shift();
      if (oldest) fs.unlinkSync(path.join(cloudDir, oldest));
    }
    database.setCloudBackupSettings({ last_synced_at: new Date().toISOString(), last_error: '' });
    return { synced: true, cloudPath: destPath };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    database.setCloudBackupSettings({ last_error: message });
    return { synced: false, error: message };
  }
}

async function runAutoBackup(database: CarDealsDb, forceOverwriteToday = false): Promise<{ localPath?: string; cloudPath?: string; synced?: boolean; error?: string }> {
  try {
    const dir = backupsDir();
    const d = new Date();
    const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const target = path.join(dir, `auto-backup-${stamp}.zip`);
    if (forceOverwriteToday || !fs.existsSync(target)) {
      await createFullZipBackup(database, target);
    }
    const files = fs
      .readdirSync(dir)
      .filter((f) => f.startsWith('auto-backup-') && (f.endsWith('.zip') || f.endsWith('.db')))
      .sort();
    while (files.length > 30) {
      const oldest = files.shift();
      if (oldest) fs.unlinkSync(path.join(dir, oldest));
    }
    if (getOAuthState(database)) {
      const oauthRes = await uploadZipToOAuthCloud(database, target);
      return { localPath: target, ...oauthRes };
    }
    const cloudResult = syncZipToCloudDir(database, target);
    return { localPath: target, ...cloudResult };
  } catch (err) {
    return { synced: false, error: err instanceof Error ? err.message : String(err) };
  }
}

async function performRestore(
  backupPath: string,
): Promise<{ restored: boolean; count: number; sourceName: string }> {
  if (!fs.existsSync(backupPath)) throw new Error('Backup file not found');
  const currentPath = db.filePath;
  const preRestore = path.join(backupsDir(), `pre-restore-${Date.now()}.zip`);
  await createFullZipBackup(db, preRestore);

  if (backupPath.toLowerCase().endsWith('.zip')) {
    const entries = readZipBuffer(fs.readFileSync(backupPath));
    const dbEntry = entries.get('car-deals.db');
    const jsonEntry = entries.get('sync-manifest.json') ?? entries.get('web-backup.json');
    if (!dbEntry && jsonEntry) {
      const parsed = JSON.parse(jsonEntry.toString('utf8')) as {
        deals?: Record<string, unknown>[];
        expenses?: Record<string, unknown>[];
        payments?: Record<string, unknown>[];
        profile?: Partial<BusinessProfile>;
      };
      if (!Array.isArray(parsed.deals)) {
        throw new Error('Mobile sync archive is missing valid deal records.');
      }
      const attRoot = attachmentsDir();
      for (const [entryName, data] of entries.entries()) {
        if (!entryName.startsWith('attachments/')) continue;
        const rel = entryName.slice('attachments/'.length);
        if (!rel) continue;
        const destFile = path.resolve(attRoot, rel);
        if (!destFile.startsWith(path.resolve(attRoot) + path.sep)) continue;
        fs.mkdirSync(path.dirname(destFile), { recursive: true });
        fs.writeFileSync(destFile, data);
      }
      db.importPortableManifest(parsed, attRoot);
      const count = db.listDeals().length;
      return { restored: true, count, sourceName: path.basename(backupPath) };
    }
    if (!dbEntry) throw new Error('Backup archive does not contain car-deals.db or sync-manifest.json');

    db.close();
    fs.writeFileSync(currentPath, dbEntry);

    const attRoot = attachmentsDir();
    for (const [entryName, data] of entries.entries()) {
      if (!entryName.startsWith('attachments/')) continue;
      const rel = entryName.slice('attachments/'.length);
      if (!rel) continue;
      const destFile = path.resolve(attRoot, rel);
      if (!destFile.startsWith(path.resolve(attRoot) + path.sep)) continue;
      fs.mkdirSync(path.dirname(destFile), { recursive: true });
      fs.writeFileSync(destFile, data);
    }

    db = new CarDealsDb(currentPath);
    db.remapAttachmentPaths(attRoot);
  } else {
    db.close();
    fs.copyFileSync(backupPath, currentPath);
    db = new CarDealsDb(currentPath);
  }

  if (db.hasUsers()) {
    const users = db.listUsers();
    activeUser = users.find((u) => u.role === 'OWNER') ?? users[0] ?? null;
  } else {
    activeUser = null;
  }
  const count = db.listDeals().length;
  return { restored: true, count, sourceName: path.basename(backupPath) };
}

function createWindow(): void {
  Menu.setApplicationMenu(null);

  const preloadPath = path.join(__dirname, 'preload.js');

  mainWindow = new BrowserWindow({
    width: 1380,
    height: 860,
    minWidth: 1024,
    minHeight: 660,
    backgroundColor: '#f8fafc',
    title: 'Car Deals Manager',
    show: false,
    webPreferences: {
      preload: preloadPath,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.once('ready-to-show', () => mainWindow?.show());
  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  mainWindow.webContents.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL) => {
    mainWindow?.show();
    void dialog.showErrorBox(
      'Failed to Load Application UI',
      `URL: ${validatedURL}\nError (${errorCode}): ${errorDescription}`,
    );
  });

  if (isDev && process.env.VITE_DEV_SERVER_URL) {
    void mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else {
    const indexHtml = path.join(__dirname, '..', 'dist', 'index.html');
    void mainWindow.loadFile(indexHtml);
  }
}

function registerIpc(): void {
  // Deals
  ipcMain.handle('deals:list', () => {
    requirePermission('AUTH');
    return db.listDeals();
  });
  ipcMain.handle('deals:listDeleted', () => {
    requirePermission('AUTH');
    return db.listDeletedDeals();
  });
  ipcMain.handle('deals:get', (_e, id: number) => {
    requirePermission('AUTH');
    return db.getDealById(id);
  });
  ipcMain.handle(
    'deals:create',
    (
      _e,
      input: NewDealInput,
      sale?: SaleInput | null,
      initialPayments?: {
        sellerPayment?: InitialPaymentInput | null;
        buyerPayment?: InitialPaymentInput | null;
      } | null,
    ) => {
      requirePermission('AUTH');
      if (sale) requirePermission('MARK_SOLD');
      if (initialPayments?.sellerPayment || initialPayments?.buyerPayment) {
        requirePermission('PAYMENTS');
      }
      const actor = currentActorName();
      const enrichedInput: NewDealInput = { ...input, created_by: input.created_by ?? actor };
      const enrichedPayments = initialPayments
        ? {
            sellerPayment: initialPayments.sellerPayment
              ? { ...initialPayments.sellerPayment, created_by: initialPayments.sellerPayment.created_by ?? actor }
              : null,
            buyerPayment: initialPayments.buyerPayment
              ? { ...initialPayments.buyerPayment, created_by: initialPayments.buyerPayment.created_by ?? actor }
              : null,
          }
        : null;
      return db.createDeal(enrichedInput, sale, enrichedPayments);
    },
  );
  ipcMain.handle('deals:update', (_e, id: number, input: UpdateDealInput) => {
    requirePermission('AUTH');
    return db.updateDeal(id, input, currentActorName());
  });
  ipcMain.handle('deals:softDelete', (_e, id: number) => {
    requirePermission('DELETE');
    db.softDeleteDeal(id, currentActorName());
  });
  ipcMain.handle('deals:restore', (_e, id: number) => {
    requirePermission('DELETE');
    return db.restoreDeal(id, currentActorName());
  });
  ipcMain.handle('deals:delete', (_e, id: number) => {
    requirePermission('DELETE');
    db.deleteDeal(id, currentActorName());
  });
  ipcMain.handle('deals:emptyRecycleBin', () => {
    requirePermission('DELETE');
    db.emptyRecycleBin(currentActorName());
  });
  ipcMain.handle('deals:reserve', (_e, id: number, input: ReserveInput) => {
    requirePermission('MARK_SOLD');
    return db.reserveDeal(id, { ...input, created_by: input.created_by ?? currentActorName() });
  });
  ipcMain.handle('deals:cancelReservation', (_e, id: number, refundToken?: boolean) => {
    requirePermission('MARK_SOLD');
    return db.cancelReservation(id, Boolean(refundToken), currentActorName());
  });
  ipcMain.handle('deals:markSold', (_e, id: number, sale: SaleInput, initialBuyerPayment?: InitialPaymentInput | null) => {
    requirePermission('MARK_SOLD');
    const actor = currentActorName();
    const payment = initialBuyerPayment
      ? { ...initialBuyerPayment, created_by: initialBuyerPayment.created_by ?? actor }
      : null;
    return db.markSold(id, { ...sale, created_by: sale.created_by ?? actor }, payment, actor);
  });
  ipcMain.handle('deals:revertSale', (_e, id: number, deleteBuyerPayments?: boolean) => {
    requirePermission('MARK_SOLD');
    return db.revertSale(id, Boolean(deleteBuyerPayments), currentActorName());
  });
  ipcMain.handle('deals:updateDueDates', (_e, id: number, input: DueDatesInput) => {
    requirePermission('PAYMENTS');
    return db.updateDueDates(id, input);
  });
  ipcMain.handle('deals:updateChecklist', (_e, id: number, checklistJson: string, tokenTaxPaidTill?: string | null) => {
    requirePermission('AUTH');
    return db.updateChecklist(id, checklistJson, tokenTaxPaidTill);
  });

  // File Handover & Transfer
  ipcMain.handle('transfer:update', (_e, id: number, input: TransferInput) => {
    requirePermission('AUTH');
    return db.updateTransfer(id, input, currentActorName());
  });

  // Attachments (Disk + Webcam + In-App Preview)
  ipcMain.handle('attachments:list', (_e, dealId: number) => {
    requirePermission('AUTH');
    return db.listAttachments(dealId);
  });
  ipcMain.handle('attachments:pickAndAdd', async (_e, dealId: number, category: AttachmentCategory, label?: string) => {
    requirePermission('AUTH');
    if (!mainWindow) return null;
    const res = await dialog.showOpenDialog(mainWindow, {
      title: 'Select Document or Photo',
      properties: ['openFile'],
      filters: [
        { name: 'Images & Documents', extensions: ['png', 'jpg', 'jpeg', 'webp', 'pdf'] },
        { name: 'All Files', extensions: ['*'] },
      ],
    });
    if (res.canceled || res.filePaths.length === 0) return null;
    const srcPath = res.filePaths[0];
    const ext = path.extname(srcPath);
    const baseName = path.basename(srcPath);
    const dealFolder = path.join(attachmentsDir(), `deal-${dealId}`);
    fs.mkdirSync(dealFolder, { recursive: true });
    const destName = `${Date.now()}-${category.toLowerCase()}${ext}`;
    const destPath = path.join(dealFolder, destName);
    fs.copyFileSync(srcPath, destPath);
    return db.addAttachment(dealId, {
      category,
      label: label || category,
      file_name: baseName,
      file_path: destPath,
    });
  });

  ipcMain.handle(
    'attachments:saveWebcam',
    (_e, dealId: number, category: AttachmentCategory, label: string, dataUrl: string) => {
      requirePermission('AUTH');
      const match = /^data:image\/(png|jpeg|jpg|webp);base64,(.+)$/i.exec(dataUrl);
      if (!match) throw new Error('Invalid image capture data');
      const ext = match[1].toLowerCase() === 'jpeg' ? 'jpg' : match[1].toLowerCase();
      const buffer = Buffer.from(match[2], 'base64');
      const dealFolder = path.join(attachmentsDir(), `deal-${dealId}`);
      fs.mkdirSync(dealFolder, { recursive: true });
      const fileName = `webcam-${category.toLowerCase()}-${Date.now()}.${ext}`;
      const destPath = path.join(dealFolder, fileName);
      fs.writeFileSync(destPath, buffer);
      return db.addAttachment(dealId, {
        category,
        label: label || category,
        file_name: fileName,
        file_path: destPath,
      });
    },
  );

  ipcMain.handle(
    'attachments:saveData',
    (_e, dealId: number, category: AttachmentCategory, label: string, fileName: string, dataUrl: string) => {
      requirePermission('AUTH');
      const match = /^data:(image\/(?:png|jpeg|jpg|webp)|application\/pdf);base64,(.+)$/i.exec(dataUrl);
      if (!match) throw new Error('Unsupported attachment format. Only PNG, JPG, WEBP, and PDF files are supported.');
      const mime = match[1].toLowerCase();
      const ext =
        mime === 'application/pdf'
          ? 'pdf'
          : mime === 'image/png'
          ? 'png'
          : mime === 'image/webp'
          ? 'webp'
          : 'jpg';
      const buffer = Buffer.from(match[2], 'base64');
      const dealFolder = path.join(attachmentsDir(), `deal-${dealId}`);
      fs.mkdirSync(dealFolder, { recursive: true });
      const cleanBase = path.basename(fileName || `doc.${ext}`).replace(/[^a-zA-Z0-9._-]/g, '_');
      const storedName = `${Date.now()}-${category.toLowerCase()}-${cleanBase.endsWith(`.${ext}`) ? cleanBase : `${cleanBase}.${ext}`}`;
      const destPath = path.join(dealFolder, storedName);
      fs.writeFileSync(destPath, buffer);
      return db.addAttachment(dealId, {
        category,
        label: label || category,
        file_name: fileName || storedName,
        file_path: destPath,
      });
    },
  );

  ipcMain.handle('attachments:readDataUrl', (_e, filePath: string) => {
    requirePermission('AUTH');
    const resolved = resolveAttachmentPath(filePath);
    if (!resolved) return null;
    const ext = path.extname(resolved).toLowerCase();
    const mimeMap: Record<string, string> = {
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.webp': 'image/webp',
      '.pdf': 'application/pdf',
    };
    const mime = mimeMap[ext];
    if (!mime) return null;
    const b64 = fs.readFileSync(resolved).toString('base64');
    return `data:${mime};base64,${b64}`;
  });

  ipcMain.handle('attachments:delete', (_e, id: number) => {
    requirePermission('AUTH');
    const removed = db.deleteAttachment(id);
    if (removed) {
      const resolved = resolveAttachmentPath(removed.file_path);
      if (resolved && fs.existsSync(resolved)) {
        try {
          fs.unlinkSync(resolved);
        } catch {
          /* ignore */
        }
      }
    }
  });

  // Expenses
  ipcMain.handle('expenses:list', (_e, dealId: number) => {
    requirePermission('AUTH');
    return db.listExpenses(dealId);
  });
  ipcMain.handle('expenses:listAll', () => {
    requirePermission('AUTH');
    return db.listAllExpenses();
  });
  ipcMain.handle('expenses:add', (_e, dealId: number, input: ExpenseInput) => {
    requirePermission('AUTH');
    return db.addExpense(dealId, { ...input, created_by: input.created_by ?? currentActorName() });
  });
  ipcMain.handle('expenses:update', (_e, id: number, input: ExpenseInput) => {
    requirePermission('AUTH');
    return db.updateExpense(id, input, currentActorName());
  });
  ipcMain.handle('expenses:delete', (_e, id: number) => {
    requirePermission('AUTH');
    db.deleteExpense(id, currentActorName());
  });

  // Payments & Cheque Clearance
  ipcMain.handle('payments:list', (_e, dealId: number) => {
    requirePermission('AUTH');
    return db.listPayments(dealId);
  });
  ipcMain.handle('payments:listAll', () => {
    requirePermission('AUTH');
    return db.listAllPayments();
  });
  ipcMain.handle('payments:add', (_e, dealId: number, input: PaymentInput) => {
    requirePermission('PAYMENTS');
    return db.addPayment(dealId, { ...input, created_by: input.created_by ?? currentActorName() });
  });
  ipcMain.handle('payments:update', (_e, id: number, input: PaymentInput) => {
    requirePermission('PAYMENTS');
    return db.updatePayment(id, input, currentActorName());
  });
  ipcMain.handle('payments:updateChequeStatus', (_e, id: number, status: ChequeStatus) => {
    requirePermission('PAYMENTS');
    return db.updateChequeStatus(id, status, currentActorName());
  });
  ipcMain.handle('payments:delete', (_e, id: number) => {
    requirePermission('PAYMENTS');
    db.deletePayment(id, currentActorName());
  });

  // Audit Log
  ipcMain.handle('audit:list', (_e, dealId?: number, limit?: number) => {
    requirePermission('AUTH');
    return db.listAuditLogs(dealId, limit);
  });

  // Multi-User Role-Based PIN Lock
  ipcMain.handle('users:hasUsers', () => db.hasUsers());
  ipcMain.handle('users:list', () => db.listUsers());
  ipcMain.handle('users:create', (_e, input: CreateUserInput) => {
    if (db.hasUsers()) requirePermission('OWNER');
    return db.createUser(input);
  });
  ipcMain.handle('users:update', (_e, id: number, input: UpdateUserInput) => {
    requirePermission('OWNER');
    const updated = db.updateUser(id, input);
    if (activeUser && activeUser.id === id) activeUser = updated;
    return updated;
  });
  ipcMain.handle('users:delete', (_e, id: number) => {
    requirePermission('OWNER');
    db.deleteUser(id);
    if (activeUser && activeUser.id === id) activeUser = null;
  });
  ipcMain.handle('users:authenticate', (_e, pin: string, userId?: number) => {
    const user = db.authenticatePin(pin, userId);
    if (user) activeUser = user;
    return user;
  });
  ipcMain.handle('users:lock', () => {
    activeUser = null;
  });

  // Business Profile, Auto-Lock & Cloud Backup Folder Settings
  ipcMain.handle('settings:getBusinessProfile', () => db.getBusinessProfile());
  ipcMain.handle('settings:setBusinessProfile', (_e, profile: Partial<BusinessProfile>) => {
    requirePermission('OWNER');
    return db.setBusinessProfile(profile);
  });
  ipcMain.handle('settings:getAutoLockMinutes', () => db.getAutoLockMinutes());
  ipcMain.handle('settings:setAutoLockMinutes', (_e, minutes: number) => {
    requirePermission('OWNER');
    return db.setAutoLockMinutes(minutes);
  });
  const buildEffectiveCloudSettings = () => {
    const base = db.getCloudBackupSettings();
    const oauth = getOAuthState(db);
    if (oauth) {
      const label =
        oauth.provider === 'ONEDRIVE'
          ? 'Microsoft OneDrive (Direct Live Sync)'
          : oauth.provider === 'DROPBOX'
          ? 'Dropbox (Direct Live Sync)'
          : 'Google Drive (Direct Live Sync)';
      return {
        ...base,
        provider: oauth.provider,
        cloud_backup_dir: oauth.accountEmail ? `${label} — ${oauth.accountEmail}` : label,
        account_email: oauth.accountEmail ?? null,
      };
    }
    return {
      ...base,
      provider: base.cloud_backup_dir ? ('LOCAL_FOLDER' as const) : ('NONE' as const),
    };
  };

  ipcMain.handle('settings:getCloudBackupSettings', () => {
    requirePermission('AUTH');
    return buildEffectiveCloudSettings();
  });
  ipcMain.handle('settings:getCloudClientIds', () => {
    requirePermission('AUTH');
    return getSavedClientIds(db);
  });
  ipcMain.handle('settings:saveCloudClientId', (_e, provider: OAuthProvider, clientId: string) => {
    requirePermission('OWNER');
    saveClientId(db, provider, clientId);
    return getSavedClientIds(db);
  });
  ipcMain.handle('settings:connectCloudProvider', async (_e, provider: OAuthProvider, explicitClientId?: string) => {
    requirePermission('OWNER');
    await startElectronOAuth(db, provider, explicitClientId, (connectedState) => {
      mainWindow?.webContents.send('cloud:oauthCompleted', {
        provider: connectedState.provider,
        accountEmail: connectedState.accountEmail ?? null,
      });
    });
    return buildEffectiveCloudSettings();
  });
  ipcMain.handle('settings:disconnectCloudProvider', () => {
    requirePermission('OWNER');
    setOAuthState(db, null);
    db.setCloudBackupSettings({ cloud_backup_dir: '', last_error: '' });
    return buildEffectiveCloudSettings();
  });
  ipcMain.handle('settings:pickCloudBackupFolder', async () => {
    requirePermission('OWNER');
    if (!mainWindow) return buildEffectiveCloudSettings();
    const res = await dialog.showOpenDialog(mainWindow, {
      title: 'Select Cloud Sync Folder (OneDrive / Google Drive / Dropbox)',
      properties: ['openDirectory', 'createDirectory'],
    });
    if (res.canceled || res.filePaths.length === 0) return buildEffectiveCloudSettings();
    setOAuthState(db, null);
    db.setCloudBackupSettings({ cloud_backup_dir: res.filePaths[0], last_error: '' });
    await runAutoBackup(db, true);
    return buildEffectiveCloudSettings();
  });
  ipcMain.handle('settings:clearCloudBackupFolder', () => {
    requirePermission('OWNER');
    setOAuthState(db, null);
    db.setCloudBackupSettings({ cloud_backup_dir: '', last_error: '' });
    return buildEffectiveCloudSettings();
  });
  ipcMain.handle('data:pullCloudLatest', async () => {
    requirePermission('OWNER');
    try {
      const tmpZip = await downloadZipFromOAuthCloud(db);
      if (!tmpZip) {
        return {
          pulled: false,
          message: 'No cloud sync file found yet. Click Sync Now from your other device first.',
        };
      }
      try {
        const res = await performRestore(tmpZip);
        db.setCloudBackupSettings({ last_synced_at: new Date().toISOString(), last_error: '' });
        return {
          pulled: true,
          restored: true,
          count: res.count,
          message: `Synced ${res.count} car records from cloud!`,
        };
      } finally {
        try { fs.unlinkSync(tmpZip); } catch { /* ignore */ }
      }
    } catch (err) {
      return {
        pulled: false,
        error: err instanceof Error ? err.message : String(err),
      };
    }
  });
  ipcMain.handle('data:syncCloudNow', async () => {
    requirePermission('AUTH');
    const result = await runAutoBackup(db, true);
    return {
      synced: Boolean(result.synced),
      localPath: result.localPath,
      cloudPath: result.cloudPath,
      error: result.error,
    };
  });

  // Backup & Restore
  ipcMain.handle('data:autoBackupFolder', () => backupsDir());
  ipcMain.handle('data:listAutoBackups', () => {
    requirePermission('OWNER');
    const dirs = [backupsDir(), legacyBackupsDir()];
    const seen = new Set<string>();
    const out: { name: string; path: string; size: number; mtime: string; kind: 'zip' | 'db' }[] = [];

    for (const dir of dirs) {
      if (!fs.existsSync(dir)) continue;
      for (const name of fs.readdirSync(dir)) {
        if (!name.endsWith('.zip') && !name.endsWith('.db')) continue;
        const full = path.join(dir, name);
        if (seen.has(full)) continue;
        seen.add(full);
        const stat = fs.statSync(full);
        out.push({
          name,
          path: full,
          size: stat.size,
          mtime: stat.mtime.toISOString(),
          kind: name.endsWith('.zip') ? 'zip' : 'db',
        });
      }
    }

    return out.sort((a, b) => b.mtime.localeCompare(a.mtime));
  });

  ipcMain.handle('data:export', async (_e, kind: 'zip' | 'db' | 'csv') => {
    requirePermission('AUTH');
    if (!mainWindow) return { saved: false };
    const date = new Date().toISOString().slice(0, 10);
    const defaultName =
      kind === 'zip'
        ? `car-deals-full-backup-${date}.zip`
        : kind === 'db'
        ? `car-deals-backup-${date}.db`
        : `car-deals-${date}.csv`;
    const filter =
      kind === 'zip'
        ? { name: 'Full Backup Archive (Database + Attachments)', extensions: ['zip'] }
        : kind === 'db'
        ? { name: 'SQLite Database', extensions: ['db'] }
        : { name: 'CSV Spreadsheet', extensions: ['csv'] };

    const res = await dialog.showSaveDialog(mainWindow, {
      title:
        kind === 'zip'
          ? 'Save Full Backup (Database + Scanned Documents)'
          : kind === 'db'
          ? 'Backup Car Deals Database'
          : 'Export Car Deals to CSV',
      defaultPath: path.join(app.getPath('documents'), defaultName),
      filters: [filter],
    });
    if (res.canceled || !res.filePath) return { saved: false };
    if (kind === 'zip') {
      await createFullZipBackup(db, res.filePath);
    } else if (kind === 'db') {
      await db.backupTo(res.filePath);
    } else {
      fs.writeFileSync(res.filePath, db.exportCsv(), 'utf8');
    }
    return { saved: true, path: res.filePath };
  });

  ipcMain.handle('data:restoreFromPath', async (_e, backupPath: string) => {
    requirePermission('OWNER');
    return performRestore(backupPath);
  });

  ipcMain.handle('data:restoreFromBackup', async (_e, backupPath?: string) => {
    requirePermission('OWNER');
    if (backupPath) {
      return performRestore(backupPath);
    }
    if (!mainWindow) return { restored: false };
    const res = await dialog.showOpenDialog(mainWindow, {
      title: 'Select Backup File (.zip or .db) to Restore',
      properties: ['openFile'],
      filters: [{ name: 'Car Deals Backups', extensions: ['zip', 'db'] }],
    });
    if (res.canceled || res.filePaths.length === 0) return { restored: false };
    return performRestore(res.filePaths[0]);
  });

  ipcMain.handle('data:pickAndRestore', async () => {
    requirePermission('OWNER');
    if (!mainWindow) return { restored: false };
    const res = await dialog.showOpenDialog(mainWindow, {
      title: 'Select Backup File (.zip or .db) to Restore',
      properties: ['openFile'],
      filters: [{ name: 'Car Deals Backups', extensions: ['zip', 'db'] }],
    });
    if (res.canceled || res.filePaths.length === 0) return { restored: false };
    return performRestore(res.filePaths[0]);
  });

  // Printing / Save Receipt PDF
  ipcMain.handle('receipt:savePdf', async (_e, html: string, defaultFileName: string) => {
    requirePermission('AUTH');
    if (!mainWindow) return { saved: false };
    const res = await dialog.showSaveDialog(mainWindow, {
      title: 'Save Receipt as PDF',
      defaultPath: path.join(app.getPath('documents'), defaultFileName),
      filters: [{ name: 'PDF Document', extensions: ['pdf'] }],
    });
    if (res.canceled || !res.filePath) return { saved: false };

    const win = new BrowserWindow({ show: false, webPreferences: { sandbox: true } });
    try {
      await win.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);
      const pdfBuffer = await win.webContents.printToPDF({
        printBackground: true,
        pageSize: 'A4',
        margins: { top: 0.4, bottom: 0.4, left: 0.4, right: 0.4 },
      });
      fs.writeFileSync(res.filePath, pdfBuffer);
      return { saved: true, path: res.filePath };
    } finally {
      win.close();
    }
  });

  ipcMain.handle('receipt:printHtml', async (_e, html: string) => {
    requirePermission('AUTH');
    const win = new BrowserWindow({ show: false, webPreferences: { sandbox: true } });
    try {
      await win.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);
      await new Promise<void>((resolve) => {
        win.webContents.print({ silent: false, printBackground: true }, () => resolve());
      });
    } finally {
      win.close();
    }
  });

  ipcMain.handle('shell:showInFolder', (_e, filePath: string) => {
    const resolved = resolveAttachmentPath(filePath) ?? filePath;
    if (fs.existsSync(resolved)) {
      shell.showItemInFolder(resolved);
    }
  });

  ipcMain.handle('shell:openExternal', async (_e, url: string) => {
    if (/^https?:\/\//i.test(url)) {
      await shell.openExternal(url);
    }
  });
}

app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    if (permission === 'media') {
      callback(true);
      return;
    }
    callback(false);
  });

  db = new CarDealsDb(path.join(app.getPath('userData'), 'car-deals.db'));
  void runAutoBackup(db, false);
  registerIpc();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

let quittingAfterBackup = false;
app.on('before-quit', (e) => {
  if (quittingAfterBackup) {
    try { db?.close(); } catch { /* ignore */ }
    return;
  }
  if (db) {
    e.preventDefault();
    quittingAfterBackup = true;
    void runAutoBackup(db, true).finally(() => {
      try { db?.close(); } catch { /* ignore */ }
      app.quit();
    });
  }
});