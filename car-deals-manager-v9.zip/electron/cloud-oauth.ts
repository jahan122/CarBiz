import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { shell } from 'electron';
import type { CarDealsDb } from './db';

export type OAuthProvider = 'GOOGLE_DRIVE' | 'DROPBOX' | 'ONEDRIVE';

export interface StoredOAuthState {
  provider: OAuthProvider;
  clientId: string;
  accountEmail?: string;
  accessToken: string;
  refreshToken?: string;
  expiresAt: number;
}

export const ELECTRON_REDIRECT_URI = 'http://127.0.0.1:42813/oauth-callback';
const REMOTE_FILE_NAME = 'car-deals-live-sync.zip';

const ENDPOINTS: Record<
  OAuthProvider,
  { authUrl: string; tokenUrl: string; scope: string }
> = {
  GOOGLE_DRIVE: {
    authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    scope: 'https://www.googleapis.com/auth/drive.file email',
  },
  DROPBOX: {
    authUrl: 'https://www.dropbox.com/oauth2/authorize',
    tokenUrl: 'https://api.dropboxapi.com/oauth2/token',
    scope: 'files.content.write files.content.read account_info.read',
  },
  ONEDRIVE: {
    authUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    tokenUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    scope: 'Files.ReadWrite.AppFolder User.Read offline_access',
  },
};

function base64Url(buf: Buffer): string {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function getSavedClientIds(db: CarDealsDb): Partial<Record<OAuthProvider, string>> {
  try {
    const raw = db.getSetting('cloud_oauth_client_ids');
    return raw ? (JSON.parse(raw) as Partial<Record<OAuthProvider, string>>) : {};
  } catch {
    return {};
  }
}

export function saveClientId(db: CarDealsDb, provider: OAuthProvider, clientId: string): void {
  const map = getSavedClientIds(db);
  const trimmed = clientId.trim();
  if (trimmed) map[provider] = trimmed;
  else delete map[provider];
  db.setSetting('cloud_oauth_client_ids', JSON.stringify(map));
}

export function getOAuthState(db: CarDealsDb): StoredOAuthState | null {
  try {
    const raw = db.getSetting('cloud_oauth_state');
    return raw ? (JSON.parse(raw) as StoredOAuthState) : null;
  } catch {
    return null;
  }
}

export function setOAuthState(db: CarDealsDb, state: StoredOAuthState | null): void {
  db.setSetting('cloud_oauth_state', state ? JSON.stringify(state) : '');
}

let activeServer: http.Server | null = null;

export async function startElectronOAuth(
  db: CarDealsDb,
  provider: OAuthProvider,
  explicitClientId?: string,
  onConnected?: (state: StoredOAuthState) => void,
): Promise<void> {
  if (explicitClientId && explicitClientId.trim()) {
    saveClientId(db, provider, explicitClientId.trim());
  }
  const clientId = (explicitClientId?.trim() || getSavedClientIds(db)[provider] || '').trim();
  if (!clientId) {
    const label =
      provider === 'ONEDRIVE'
        ? 'OneDrive Application (Client) ID'
        : provider === 'DROPBOX'
        ? 'Dropbox App Key (Client ID)'
        : 'Google Drive Client ID';
    throw new Error(`Please paste your ${label} in the setup field first.`);
  }

  if (activeServer) {
    try { activeServer.close(); } catch { /* ignore */ }
    activeServer = null;
  }

  const verifier = base64Url(crypto.randomBytes(32));
  const challenge = base64Url(crypto.createHash('sha256').update(verifier).digest());
  const stateToken = crypto.randomUUID();
  const meta = ENDPOINTS[provider];

  await new Promise<void>((resolve, reject) => {
    const server = http.createServer(async (req, res) => {
      try {
        if (!req.url || !req.url.startsWith('/oauth-callback')) {
          res.writeHead(404);
          res.end('Not found');
          return;
        }
        const url = new URL(req.url, ELECTRON_REDIRECT_URI);
        const code = url.searchParams.get('code');
        const returnedState = url.searchParams.get('state');
        const errParam = url.searchParams.get('error_description') || url.searchParams.get('error');

        if (errParam) {
          res.writeHead(400, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(`<h2>Sign-in cancelled or failed</h2><p>${errParam}</p><p>You can close this tab.</p>`);
          server.close();
          activeServer = null;
          return;
        }

        if (!code || returnedState !== stateToken) {
          res.writeHead(400, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end('<h2>Invalid authorization callback</h2><p>Please try again from Car Deals Manager.</p>');
          server.close();
          activeServer = null;
          return;
        }

        const body = new URLSearchParams({
          client_id: clientId,
          grant_type: 'authorization_code',
          code,
          redirect_uri: ELECTRON_REDIRECT_URI,
          code_verifier: verifier,
        });

        const tokenRes = await fetch(meta.tokenUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: body.toString(),
        });
        if (!tokenRes.ok) {
          const errText = await tokenRes.text();
          db.setCloudBackupSettings({ last_error: `Auth failed (${tokenRes.status}): ${errText}` });
          res.writeHead(500, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(`<h2>Authorization failed</h2><pre>${errText}</pre>`);
          server.close();
          activeServer = null;
          return;
        }

        const tokens = (await tokenRes.json()) as {
          access_token: string;
          refresh_token?: string;
          expires_in?: number;
        };

        let accountEmail: string | undefined;
        try {
          if (provider === 'ONEDRIVE') {
            const meRes = await fetch('https://graph.microsoft.com/v1.0/me', {
              headers: { Authorization: `Bearer ${tokens.access_token}` },
            });
            if (meRes.ok) {
              const me = (await meRes.json()) as { mail?: string; userPrincipalName?: string };
              accountEmail = me.mail || me.userPrincipalName;
            }
          } else if (provider === 'GOOGLE_DRIVE') {
            const meRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
              headers: { Authorization: `Bearer ${tokens.access_token}` },
            });
            if (meRes.ok) {
              const me = (await meRes.json()) as { email?: string };
              accountEmail = me.email;
            }
          } else if (provider === 'DROPBOX') {
            const meRes = await fetch('https://api.dropboxapi.com/2/users/get_current_account', {
              method: 'POST',
              headers: { Authorization: `Bearer ${tokens.access_token}` },
            });
            if (meRes.ok) {
              const me = (await meRes.json()) as { email?: string };
              accountEmail = me.email;
            }
          }
        } catch {
          /* optional profile lookup */
        }

        const oauthState: StoredOAuthState = {
          provider,
          clientId,
          accountEmail,
          accessToken: tokens.access_token,
          refreshToken: tokens.refresh_token,
          expiresAt: Date.now() + (Number(tokens.expires_in ?? 3600) - 60) * 1000,
        };
        setOAuthState(db, oauthState);
        db.setCloudBackupSettings({
          cloud_backup_dir: '',
          last_error: '',
        });

        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(`
          <html><body style="font-family:system-ui,sans-serif;text-align:center;padding:48px;background:#f8fafc;color:#0f172a;">
            <div style="max-width:420px;margin:auto;background:#fff;padding:32px;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.08);">
              <h2 style="color:#059669;margin-top:0;">Connected to ${provider.replace('_', ' ')}!</h2>
              <p>${accountEmail ? `Signed in as <strong>${accountEmail}</strong>.` : 'Your cloud account is now linked.'}</p>
              <p style="color:#64748b;font-size:14px;">You can close this browser tab and return to <strong>Car Deals Manager</strong>.</p>
            </div>
          </body></html>
        `);

        onConnected?.(oauthState);
        setTimeout(() => {
          try { server.close(); } catch { /* ignore */ }
          activeServer = null;
        }, 500);
      } catch {
        try { server.close(); } catch { /* ignore */ }
        activeServer = null;
      }
    });

    server.on('error', (err) => {
      reject(new Error(`Could not start local sign-in listener on port 42813: ${err.message}`));
    });

    server.listen(42813, '127.0.0.1', () => {
      activeServer = server;
      const params = new URLSearchParams({
        client_id: clientId,
        redirect_uri: ELECTRON_REDIRECT_URI,
        response_type: 'code',
        scope: meta.scope,
        code_challenge: challenge,
        code_challenge_method: 'S256',
        state: stateToken,
      });
      if (provider === 'GOOGLE_DRIVE') {
        params.set('access_type', 'offline');
        params.set('prompt', 'consent');
      } else if (provider === 'DROPBOX') {
        params.set('token_access_type', 'offline');
      }
      void shell.openExternal(`${meta.authUrl}?${params.toString()}`);
      resolve();
    });
  });
}

async function ensureFreshToken(db: CarDealsDb, state: StoredOAuthState): Promise<StoredOAuthState> {
  if (Date.now() < state.expiresAt || !state.refreshToken) return state;
  const meta = ENDPOINTS[state.provider];
  const body = new URLSearchParams({
    client_id: state.clientId,
    grant_type: 'refresh_token',
    refresh_token: state.refreshToken,
  });
  const res = await fetch(meta.tokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });
  if (!res.ok) {
    throw new Error('Cloud session expired. Please click Connect again to re-authorize.');
  }
  const tokens = (await res.json()) as {
    access_token: string;
    refresh_token?: string;
    expires_in?: number;
  };
  const refreshed: StoredOAuthState = {
    ...state,
    accessToken: tokens.access_token,
    refreshToken: tokens.refresh_token ?? state.refreshToken,
    expiresAt: Date.now() + (Number(tokens.expires_in ?? 3600) - 60) * 1000,
  };
  setOAuthState(db, refreshed);
  return refreshed;
}

export async function uploadZipToOAuthCloud(
  db: CarDealsDb,
  localZipPath: string,
): Promise<{ synced: boolean; cloudPath?: string; error?: string }> {
  let state = getOAuthState(db);
  if (!state) return { synced: false };

  try {
    state = await ensureFreshToken(db, state);
    const zipBuffer = fs.readFileSync(localZipPath);

    if (state.provider === 'ONEDRIVE') {
      const upRes = await fetch(
        `https://graph.microsoft.com/v1.0/me/drive/special/approot:/${REMOTE_FILE_NAME}:/content`,
        {
          method: 'PUT',
          headers: {
            Authorization: `Bearer ${state.accessToken}`,
            'Content-Type': 'application/zip',
          },
          body: zipBuffer,
        },
      );
      if (!upRes.ok) throw new Error(`OneDrive upload failed: ${await upRes.text()}`);
    } else if (state.provider === 'DROPBOX') {
      const upRes = await fetch('https://content.dropboxapi.com/2/files/upload', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${state.accessToken}`,
          'Content-Type': 'application/octet-stream',
          'Dropbox-API-Arg': JSON.stringify({
            path: `/${REMOTE_FILE_NAME}`,
            mode: 'overwrite',
            mute: true,
          }),
        },
        body: zipBuffer,
      });
      if (!upRes.ok) throw new Error(`Dropbox upload failed: ${await upRes.text()}`);
    } else if (state.provider === 'GOOGLE_DRIVE') {
      const searchRes = await fetch(
        `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
          `name='${REMOTE_FILE_NAME}' and trashed=false`,
        )}&fields=files(id)`,
        { headers: { Authorization: `Bearer ${state.accessToken}` } },
      );
      const searchJson = (await searchRes.json()) as { files?: { id: string }[] };
      const existing = searchJson.files?.[0];
      const boundary = 'carbiz_electron_boundary';
      const metadata = JSON.stringify({ name: REMOTE_FILE_NAME, mimeType: 'application/zip' });
      const head = Buffer.from(
        `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n--${boundary}\r\nContent-Type: application/zip\r\n\r\n`,
      );
      const tail = Buffer.from(`\r\n--${boundary}--`);
      const body = Buffer.concat([head, zipBuffer, tail]);
      const uploadUrl = existing
        ? `https://www.googleapis.com/upload/drive/v3/files/${existing.id}?uploadType=multipart`
        : 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
      const upRes = await fetch(uploadUrl, {
        method: existing ? 'PATCH' : 'POST',
        headers: {
          Authorization: `Bearer ${state.accessToken}`,
          'Content-Type': `multipart/related; boundary=${boundary}`,
        },
        body,
      });
      if (!upRes.ok) throw new Error(`Google Drive upload failed: ${await upRes.text()}`);
    }

    const providerLabel =
      state.provider === 'ONEDRIVE'
        ? 'OneDrive'
        : state.provider === 'DROPBOX'
        ? 'Dropbox'
        : 'Google Drive';
    const label = `${providerLabel}${state.accountEmail ? ` (${state.accountEmail})` : ''}:/${REMOTE_FILE_NAME}`;
    db.setCloudBackupSettings({ last_synced_at: new Date().toISOString(), last_error: '' });
    return { synced: true, cloudPath: label };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    db.setCloudBackupSettings({ last_error: message });
    return { synced: false, error: message };
  }
}

export async function downloadZipFromOAuthCloud(db: CarDealsDb): Promise<string | null> {
  let state = getOAuthState(db);
  if (!state) return null;
  state = await ensureFreshToken(db, state);

  let arrayBuf: ArrayBuffer | null = null;
  if (state.provider === 'ONEDRIVE') {
    const dlRes = await fetch(
      `https://graph.microsoft.com/v1.0/me/drive/special/approot:/${REMOTE_FILE_NAME}:/content`,
      { headers: { Authorization: `Bearer ${state.accessToken}` } },
    );
    if (dlRes.status === 404) return null;
    if (!dlRes.ok) throw new Error(`OneDrive download failed: ${await dlRes.text()}`);
    arrayBuf = await dlRes.arrayBuffer();
  } else if (state.provider === 'DROPBOX') {
    const dlRes = await fetch('https://content.dropboxapi.com/2/files/download', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${state.accessToken}`,
        'Dropbox-API-Arg': JSON.stringify({ path: `/${REMOTE_FILE_NAME}` }),
      },
    });
    if (dlRes.status === 409) return null;
    if (!dlRes.ok) throw new Error(`Dropbox download failed: ${await dlRes.text()}`);
    arrayBuf = await dlRes.arrayBuffer();
  } else if (state.provider === 'GOOGLE_DRIVE') {
    const searchRes = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
        `name='${REMOTE_FILE_NAME}' and trashed=false`,
      )}&fields=files(id)`,
      { headers: { Authorization: `Bearer ${state.accessToken}` } },
    );
    const list = (await searchRes.json()) as { files?: { id: string }[] };
    const file = list.files?.[0];
    if (!file) return null;
    const dlRes = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, {
      headers: { Authorization: `Bearer ${state.accessToken}` },
    });
    if (!dlRes.ok) throw new Error(`Google Drive download failed: ${await dlRes.text()}`);
    arrayBuf = await dlRes.arrayBuffer();
  }

  if (!arrayBuf) return null;
  const tmpFile = path.join(os.tmpdir(), `carbiz-cloud-pull-${Date.now()}.zip`);
  fs.writeFileSync(tmpFile, Buffer.from(arrayBuf));
  return tmpFile;
}
