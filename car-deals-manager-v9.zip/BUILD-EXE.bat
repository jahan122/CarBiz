@echo off
title Car Deals Manager - Build Windows Installer
cd /d "%~dp0"
if not exist "node_modules" (
  call npm install --no-audit --no-fund
  if errorlevel 1 ( echo npm install failed & pause & exit /b 1 )
)
call npm run dist
if errorlevel 1 ( echo Build failed & pause & exit /b 1 )
echo.
echo Done. Your installer is in the "release" folder.
pause
