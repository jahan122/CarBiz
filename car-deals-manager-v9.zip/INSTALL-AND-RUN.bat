@echo off
title Car Deals Manager - Install and Run
cd /d "%~dp0"
if not exist "node_modules" (
  echo ==== Installing dependencies (first time takes 1-2 minutes) ====
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo npm install failed. Copy the text above and send it for help.
    pause
    exit /b 1
  )
)
echo ==== Building and Starting Car Deals Manager ====
call npm start
if errorlevel 1 (
  echo.
  echo Launch failed. Copy the error above and send it for help.
  pause
  exit /b 1
)
